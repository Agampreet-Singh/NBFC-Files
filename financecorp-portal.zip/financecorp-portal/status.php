<?php
require __DIR__ . '/db.php';
require __DIR__ . '/layout.php';
$ref = trim($_GET['ref'] ?? '');
$row = null;
if ($ref) {
    $stmt = db()->prepare("SELECT * FROM applications WHERE reference_no = ?");
    $stmt->execute([$ref]);
    $row = $stmt->fetch();
}
render_head('Track Application');
?>
<form class="panel" method="get" action="/status.php">
  <h2>Track your application</h2>
  <label>Reference number<input name="ref" value="<?= h($ref) ?>" placeholder="FC26XXXXXX"></label>
  <button class="btn" type="submit">Check status</button>
</form>
<?php if ($ref && $row): ?>
  <div class="panel">
    <h3>Application <?= h($row['reference_no']) ?></h3>
    <div class="summary">
      <div><span>Applicant</span><b><?= h($row['full_name']) ?></b></div>
      <div><span>Loan amount</span><b>&#8377;<?= number_format((float)$row['loan_amount']) ?></b></div>
      <div><span>Status</span><b class="badge <?= strtolower(h($row['status'])) ?>"><?= h($row['status']) ?></b></div>
      <div><span>Disbursal account</span><b><?= h($row['beneficiary_account']) ?> (<?= h($row['beneficiary_ifsc']) ?>)</b></div>
    </div>
  </div>
<?php elseif ($ref): ?>
  <div class="panel"><p>No application found for that reference number.</p></div>
<?php endif;
render_foot();
