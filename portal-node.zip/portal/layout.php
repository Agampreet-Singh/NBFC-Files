<?php
require_once __DIR__ . '/config.php';

function step_labels() {
    return [1=>'Mobile',2=>'Personal',3=>'PAN',4=>'Address',5=>'Employment',6=>'Credit',
            7=>'Offer',8=>'Statement',9=>'Bank',10=>'Final Offer',11=>'KYC',12=>'Selfie',
            13=>'Company',14=>'e-Mandate'];
}
function LAST_STEP() { return 14; }

/* Phases group the journey into the big boxes shown at the top. */
function phases() {
    return [
        ['Personal Info', [2,3,4]],
        ['Eligibility',   [5,6,7]],
        ['Banking',       [8,9,10]],
        ['KYC',           [11,12]],
        ['Finalize',      [13,14]],
    ];
}

/* Context shown in the left panel for each step: [title, description, [bullets]]. */
function step_info($step) {
    $m = [
        2  => ['Personal Details', 'Tell us a little about yourself so we can set up your profile.', ['Matches your official records', 'Takes under a minute']],
        3  => ['PAN Verification', 'We verify your PAN instantly and securely with NSDL.', ['Instant verification', 'Bank-grade encryption']],
        4  => ['Address Details', 'Where do you currently reside?', ['Used for correspondence', 'Affects serviceability']],
        5  => ['Employment Type', 'How do you primarily earn your income?', ['Helps assess eligibility']],
        6  => ['Credit Check', 'We fetch your credit profile to pre-qualify you.', ['Soft check — no score impact', 'Based on your PAN']],
        7  => ['Your Indicative Offer', 'Here is what you pre-qualify for.', ['Indicative only', 'Final terms after verification']],
        8  => ['Bank Statement', 'Share your statement so we can assess repayment capacity.', ['Secure Account Aggregator', 'Or upload a PDF']],
        9  => ['Your Bank Account', 'Confirm the account linked to your mobile number.', ['Used for disbursal & EMIs']],
        10 => ['Final Offer', 'Your final, locked-in loan terms.', ['Reviewed & approved', 'Accept to continue']],
        11 => ['Aadhaar KYC', 'Complete e-KYC via DigiLocker.', ['RBI-compliant', 'OTP based']],
        12 => ['Selfie Verification', 'A quick photo to confirm it is really you.', ['Liveness & identity check']],
        13 => ['Employment & Company Details', 'Tell us about where you work.', ['Employer details', 'Income assessment']],
        14 => ['Bank Account & e-Mandate', 'Set up auto-debit for your monthly EMIs.', ['e-NACH mandate', 'e-Sign loan agreement']],
    ];
    return $m[$step] ?? ['FinanceCorp', '', []];
}

function render_stepper($step) {
    $labels = step_labels();
    echo '<div class="stepper"><div class="stepper-track">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
        $mark = $n < $step ? '&#10003;' : $n;
        echo '<div class="stp ' . $cls . '"><span class="node">' . $mark . '</span><em>' . h($l) . '</em></div>';
        if ($n < count($labels)) echo '<span class="seg ' . ($n < $step ? 'done' : '') . '"></span>';
    }
    echo '</div></div>';
}

/* ===== Phase stepper: full-width boxes with arrows (the big progress banner) ===== */
function render_phase_stepper($step) {
    $phases = phases();
    $labels = step_labels();
    $last   = LAST_STEP();
    $pct    = max(0, min(100, round((($step - 2) / ($last - 2)) * 100)));
    echo '<div class="phase-card"><div class="phase-row">';
    foreach ($phases as $i => $ph) {
        [$name, $steps] = $ph;
        $isCurr = in_array($step, $steps, true);
        $isDone = max($steps) < $step;
        $cls = $isDone ? 'done' : ($isCurr ? 'curr' : 'todo');
        echo '<div class="phase ' . $cls . '"><span class="ph-no">' . ($i + 1) . '</span><span class="ph-name">' . h($name) . '</span></div>';
        if ($i < count($phases) - 1) echo '<span class="phase-arrow">&rarr;</span>';
    }
    echo '</div><div class="prog-bar"><span style="width:' . $pct . '%"></span></div>';
    echo '<div class="prog-count">Step ' . (int)($step - 1) . ' of ' . ($last - 1) . ' &middot; ' . h($labels[$step] ?? '') . '</div>';
    echo '</div>';
}

/* ===== Post-login app shell (full-screen, header + welcome) ===== */
function app_doc_open($title) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body class="app">';
}
function app_topbar($name = '', $toast = true) {
    echo '<header class="appbar"><div class="ab-in">';
    echo '<div class="ab-logo"><span class="logo">F</span><span class="ab-name">FinanceCorp</span></div>';
    echo '<div class="ab-right">';
    if ($name !== '') echo '<span class="ab-welcome">Welcome <b>' . h($name) . '</b></span>';
    echo '<a class="ab-logout" href="/logout.php">&#8614; Logout</a></div>';
    echo '</div></header>';
    if ($toast) echo '<div class="toast"><span class="toast-ic">&#10003;</span> Welcome to FinanceCorp</div>';
}
function ahead($title = '', $step = 0, $name = '') {
    app_doc_open($title);
    app_topbar($name, $step === 0 || $step === 2);   // welcome toast on first entry only
    echo '<main class="appmain"><div class="wrap">';
    if ($step > 0) {
        render_phase_stepper($step);
        [$t, $d, $bul] = step_info($step);
        echo '<div class="cols"><aside class="side">';
        echo '<div class="side-step">STEP ' . (int)($step - 1) . '</div>';
        echo '<h2 class="side-title">' . h($t) . '</h2>';
        if ($d !== '') echo '<p class="side-desc">' . h($d) . '</p>';
        if ($bul) { echo '<ul class="side-bul">'; foreach ($bul as $b) echo '<li>' . h($b) . '</li>'; echo '</ul>'; }
        echo '<div class="side-secure">&#128274; 256-bit secure &middot; RBI-registered NBFC</div>';
        echo '</aside><div class="appcard">';
    } else {
        echo '<div class="cols single"><div class="appcard">';
    }
}
function afoot() { echo '</div></div></div></main></body></html>'; }

/* ===== Pre-login split-screen shell (login / OTP) ===== */
function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body>';
    echo '<div class="split">';
    // LEFT brand panel
    echo '<aside class="brandpanel"><div class="bp-in">';
    echo '<div class="bp-logo"><span class="logo">F</span><div class="bp-name"><b>FinanceCorp</b><small>Instant Personal Loan</small></div></div>';
    echo '<h1>Quick, easy loans up to <span class="hl">&#8377;5,00,000</span></h1>';
    echo '<ul class="bp-ticks"><li>Easy personal loan for all purposes</li><li>Collateral-free loans</li><li>Seamless login process</li><li>Simple repayment</li></ul>';
    echo '<div class="bp-cards"><div class="bp-card">&#9201; Calculate your EMI within minutes</div><div class="bp-card">&#128176; Low interest rates &amp; minimal fees</div><div class="bp-card">&#128241; 24x7 access to the loan app</div></div>';
    echo '</div></aside>';
    // RIGHT content pane
    echo '<section class="pane"><div class="pane-scroll">';
    if ($step > 0) render_stepper($step);
    echo '<div class="pane-inner">';
}

function pfoot() { echo '</div></div></section></div></body></html>'; }

/** SVG illustration for the status modal (folder + face + badge). */
function status_illustration($type) {
    $badge = $type === 'reject' ? '#dc2626' : '#d97706';
    $mark  = $type === 'reject'
        ? '<path d="M93 42l14 14M107 42l-14 14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>'
        : '<path d="M100 40v11M100 57v.5" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>';
    return '<svg viewBox="0 0 200 150" width="186" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<ellipse cx="100" cy="128" rx="78" ry="9" fill="#e8efea"/>'
        . '<rect x="104" y="30" width="46" height="58" rx="5" fill="#eef3f0"/>'
        . '<rect x="112" y="42" width="30" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="52" width="24" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="62" width="28" height="4" rx="2" fill="#d7e3dc"/>'
        . '<path d="M44 108V70a8 8 0 018-8h26l9 10h40a8 8 0 018 8v28a8 8 0 01-8 8H52a8 8 0 01-8-8z" fill="#06402b"/>'
        . '<path d="M60 86l10 10M70 86l-10 10M60 110l10 10M70 110l-10 10" stroke="#06402b" stroke-width="0" />'
        . '<text x="74" y="92" font-family="monospace" font-size="15" fill="#bfe8d4" font-weight="700">&gt;&lt;</text>'
        . '<path d="M72 104q8 -6 16 0" stroke="#bfe8d4" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
        . '<circle cx="100" cy="49" r="16" fill="#fff"/><circle cx="100" cy="49" r="13" fill="' . $badge . '"/>' . $mark
        . '</svg>';
}

/** Full-page modal result (reject / already-applied), styled over the app shell. Ends the request. */
function result_screen($type, $title, $reason = '', $sub = '', $showStatus = true) {
    $name = $_SESSION['pan_name'] ?? '';
    app_doc_open('Application Status');
    app_topbar($name);
    echo '<main class="appmain dimmed"><div class="wrap"><div class="appcard ghostcard"></div></div></main>';
    echo '<div class="backdrop"><div class="modal ' . ($type === 'reject' ? 'is-reject' : 'is-info') . '">';
    echo '<div class="modal-ill">' . status_illustration($type) . '</div>';
    echo '<h2 class="modal-title">' . h($title) . '</h2>';
    if ($reason !== '') echo '<p class="modal-text">' . h($reason) . '</p>';
    if ($sub !== '')    echo '<p class="modal-text sub">' . h($sub) . '</p>';
    echo '<div class="modal-actions">';
    if ($showStatus) echo '<a class="btn ghost" href="/status.php">Check status</a>';
    echo '<a class="btn" href="/login.php">Ok</a>';
    echo '</div></div></div></body></html>';
    exit;
}
function card_open($h){ /* title now lives in the side panel */ }
function card_lead($t){ echo '<p class="appcard-lead">' . h($t) . '</p>'; }
function card_close(){}
