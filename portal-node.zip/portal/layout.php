<?php
require_once __DIR__ . '/config.php';
function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css"></head><body>';
    echo '<header class="nav"><div class="wrap"><a class="brand" href="/index.php"><span class="logo">F</span>FinanceCorp</a>';
    echo '<span class="tag">Instant Personal Loan</span></div></header><main class="wrap">';
    if ($step > 0) {
        $steps = steps(); $pct = round($step / count($steps) * 100);
        echo '<div class="progress"><div class="progress-top"><b>Step ' . $step . ' of ' . count($steps) . '</b><span>' . h($steps[$step]) . '</span></div>';
        echo '<div class="pbar"><i style="width:' . $pct . '%"></i></div></div>';
    }
}
function pfoot() {
    echo '</main><footer class="foot"><div class="wrap">FinanceCorp Capital Pvt Ltd &middot; RBI-registered NBFC (fictional). <strong>Training environment.</strong></div></footer></body></html>';
}
function card_open($h){ echo '<div class="card"><h2>' . h($h) . '</h2>'; }
function card_close(){ echo '</div>'; }
