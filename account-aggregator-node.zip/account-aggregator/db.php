<?php
// Account Aggregator — small consent log (SQLite). LAB only.
function aadb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/aa.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS consents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            consent_handle TEXT, mobile TEXT, bank TEXT, status TEXT,
            created_at TEXT DEFAULT (datetime('now')))");
    }
    return $pdo;
}
