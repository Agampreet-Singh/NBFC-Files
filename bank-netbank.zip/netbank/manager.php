<?php
session_start();
require __DIR__ . '/layout.php';
[$bname] = bank_meta();
$BANK = bank_code();
$pdo = pdo_bank();
if (isset($_GET['logout'])) { unset($_SESSION['mgr_' . $BANK]); header('Location: /index.php'); exit; }
if (empty($_SESSION['mgr_' . $BANK])) { header('Location: /index.php#login'); exit; }
$sec = $_GET['sec'] ?? '';
$view = $_GET['acc'] ?? '';

app_head($view ? 'accounts' : $sec, $bname, 'manager');

/* single account view */
if ($view) {
    $st = $pdo->prepare("SELECT * FROM accounts WHERE account_no=? AND bank_code=?"); $st->execute([$view, $BANK]);
    $a = $st->fetch(PDO::FETCH_ASSOC);
    if ($a) {
        $tx = $pdo->prepare("SELECT * FROM transactions WHERE account_no=? ORDER BY id DESC LIMIT 100"); $tx->execute([$view]);
        $rows = $tx->fetchAll(PDO::FETCH_ASSOC);
        echo '<p><a class="link" href="/manager.php?sec=accounts">&larr; All accounts</a></p>';
        echo '<div class="acct-hero"><div class="lab">' . h($a['holder_name']) . ($a['is_mule'] ? ' · <span class="pill flag">flagged</span>' : '') . '</div><div class="amt">' . inr($a['balance']) . '</div>';
        echo '<div class="meta"><div><b>Account</b>' . h($a['account_no']) . '</div><div><b>IFSC</b>' . h($a['ifsc']) . '</div><div><b>Mobile</b>' . h($a['mobile']) . '</div><div><b>PAN</b>' . h($a['pan']) . '</div></div></div>';
        echo '<div class="panel"><div class="ph"><h3>Transactions</h3><a class="dlbtn" href="/statement.php?acc=' . h($a['account_no']) . '">' . icon('doc') . ' Download Statement</a></div><table><tr><th>Date</th><th>Description</th><th class="r">Debit</th><th class="r">Credit</th><th class="r">Balance</th></tr>';
        foreach ($rows as $t) echo '<tr><td>' . h($t['txn_date']) . '</td><td>' . h($t['description']) . '</td><td class="r dr">' . ($t['dr_cr'] === 'DR' ? number_format($t['amount'], 2) : '') . '</td><td class="r cr">' . ($t['dr_cr'] === 'CR' ? number_format($t['amount'], 2) : '') . '</td><td class="r">' . number_format($t['balance_after'], 2) . '</td></tr>';
        echo '</table></div>';
    }
    app_foot(); exit;
}

/* payouts section */
if ($sec === 'payouts') {
    echo '<div class="panel"><div class="ph"><h3>Incoming Payouts</h3></div>';
    $has = $pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='payouts'")->fetch();
    $pr = [];
    if ($has) { $po = $pdo->prepare("SELECT p.* FROM payouts p JOIN accounts a ON p.beneficiary_account=a.account_no WHERE a.bank_code=? ORDER BY p.id DESC LIMIT 50"); try { $po->execute([$BANK]); $pr = $po->fetchAll(PDO::FETCH_ASSOC); } catch (Exception $e) {} }
    echo '<table><tr><th>Date</th><th>Beneficiary A/C</th><th class="r">Amount</th><th>Source IP</th><th>UTR</th><th>Status</th></tr>';
    foreach ($pr as $p) echo '<tr><td>' . h($p['created_at'] ?? '') . '</td><td>' . h($p['beneficiary_account']) . '</td><td class="r">' . inr($p['amount']) . '</td><td>' . h($p['source_ip'] ?? '') . '</td><td>' . h($p['utr'] ?? '') . '</td><td><span class="pill ok">' . h($p['status'] ?? '') . '</span></td></tr>';
    if (!$pr) echo '<tr><td colspan="6" class="hint">No payouts recorded yet.</td></tr>';
    echo '</table></div>';
    app_foot(); exit;
}

/* overview + accounts list */
$st = $pdo->prepare("SELECT * FROM accounts WHERE bank_code=? ORDER BY holder_name"); $st->execute([$BANK]);
$accts = $st->fetchAll(PDO::FETCH_ASSOC);
$tot = 0; $mules = 0; foreach ($accts as $x) { $tot += $x['balance']; $mules += (int)$x['is_mule']; }

if ($sec !== 'accounts') {
    echo '<div class="qrow">';
    echo '<div class="qcard"><div class="qic">' . icon('user') . '</div><div><div class="qv">' . count($accts) . '</div><div class="ql">Accounts</div></div></div>';
    echo '<div class="qcard"><div class="qic">' . icon('cash') . '</div><div><div class="qv">' . inr($tot) . '</div><div class="ql">Total Deposits</div></div></div>';
    echo '<div class="qcard"><div class="qic">' . icon('shield') . '</div><div><div class="qv">' . $mules . '</div><div class="ql">Flagged Accounts</div></div></div>';
    echo '</div>';
}
echo '<div class="panel"><div class="ph"><h3>' . h($bname) . ' — Accounts</h3></div>';
echo '<table><tr><th>Holder</th><th>Account</th><th>Mobile</th><th class="r">Balance</th><th></th></tr>';
foreach ($accts as $x) echo '<tr><td>' . h($x['holder_name']) . ($x['is_mule'] ? ' <span class="pill flag">flagged</span>' : '') . '</td><td>' . h($x['account_no']) . '</td><td>' . h($x['mobile']) . '</td><td class="r">' . inr($x['balance']) . '</td><td class="r"><a class="link" href="/manager.php?acc=' . h($x['account_no']) . '">View</a></td></tr>';
echo '</table></div>';
app_foot();
