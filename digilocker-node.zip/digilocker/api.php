<?php
// DigiLocker / Aadhaar e-KYC API. Called by the LOS node (and the portal flow).
//   ?action=ekyc-send    POST aadhaar          -> sends OTP to the Aadhaar-linked mobile
//   ?action=ekyc-verify  POST aadhaar, otp     -> verifies OTP, returns KYC data
//   ?action=verify       POST aadhaar          -> quick existence/format check (no OTP)
// LAB / isolated range only.

require __DIR__ . '/db.php';
require __DIR__ . '/config.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';
$pdo = adb();

function find_aadhaar($pdo, $a) {
    $st = $pdo->prepare("SELECT * FROM aadhaar_records WHERE aadhaar = ?");
    $st->execute([$a]);
    return $st->fetch();
}

if ($action === 'ekyc-send') {
    $a = preg_replace('/\D/', '', $_POST['aadhaar'] ?? '');
    if (strlen($a) !== 12) { echo json_encode(['status' => 'error', 'reason' => 'invalid_format']); exit; }
    $rec = find_aadhaar($pdo, $a);
    if (!$rec || $rec['status'] !== 'ACTIVE') { echo json_encode(['status' => 'error', 'reason' => 'not_found']); exit; }
    $r = tele_post('send', ['mobile' => $rec['mobile'], 'service' => OTP_SERVICE]);
    if ($r && ($r['status'] ?? '') === 'sent') {
        echo json_encode(['status' => 'sent', 'mobile_hint' => mask_mobile($rec['mobile'])]);
    } else {
        echo json_encode(['status' => 'error', 'reason' => 'otp_service_unreachable']);
    }
    exit;
}

if ($action === 'ekyc-verify') {
    $a   = preg_replace('/\D/', '', $_POST['aadhaar'] ?? '');
    $otp = preg_replace('/\D/', '', $_POST['otp'] ?? '');
    $rec = find_aadhaar($pdo, $a);
    if (!$rec) { echo json_encode(['valid' => false, 'reason' => 'not_found']); exit; }
    $r = tele_post('verify', ['mobile' => $rec['mobile'], 'otp' => $otp]);
    if ($r && !empty($r['valid'])) {
        echo json_encode([
            'valid'     => true,
            'aadhaar'   => 'XXXXXXXX' . substr($rec['aadhaar'], -4),   // masked, real one not echoed
            'full_name' => $rec['full_name'],
            'dob'       => $rec['dob'],
            'gender'    => $rec['gender'],
            'address'   => $rec['address'],
            'pan'       => $rec['pan'],
        ]);
    } else {
        echo json_encode(['valid' => false, 'reason' => 'otp_invalid']);
    }
    exit;
}

if ($action === 'verify') {
    $a = preg_replace('/\D/', '', $_POST['aadhaar'] ?? '');
    if (strlen($a) !== 12) { echo json_encode(['valid' => false, 'reason' => 'invalid_format']); exit; }
    $rec = find_aadhaar($pdo, $a);
    echo json_encode($rec && $rec['status'] === 'ACTIVE'
        ? ['valid' => true, 'full_name' => $rec['full_name'], 'dob' => $rec['dob']]
        : ['valid' => false, 'reason' => 'not_found']);
    exit;
}

echo json_encode(['status' => 'ok', 'service' => 'digilocker-aadhaar-ekyc']);
