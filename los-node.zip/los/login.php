<?php
require __DIR__ . '/config.php';
session_start();
$USER = 'losadmin'; $PASS = 'changeme';
if (isset($_GET['logout'])) { session_destroy(); header('Location: /login.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['u'] ?? '') === $USER && ($_POST['p'] ?? '') === $PASS) {
        $_SESSION['los_user'] = $USER; header('Location: /index.php'); exit;
    }
    $err = 'Invalid credentials';
}
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Sign in — FinanceCorp LOS</title>
<link rel="stylesheet" href="/assets/style.css"></head>
<body class="login-body"><div class="login-card">
<div class="logo center"><span class="mark">LOS</span><div><b>FinanceCorp</b><small>Loan Origination System</small></div></div>
<?php if ($err) echo '<p class="err">' . h($err) . '</p>'; ?>
<form method="post">
  <label>Username<input name="u" required autofocus></label>
  <label>Password<input type="password" name="p" required></label>
  <button class="btn" type="submit">Sign in</button>
</form>
<p class="muted center">Credit-Ops console &middot; authorised staff only</p>
</div></body></html>
