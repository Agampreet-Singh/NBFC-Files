<?php
// config.php — portal-side config for talking to the Telecom OTP gateway.
// Set TELECOM_URL to your Telecom Service node (default = its lab IP).
// You can also override with an env var: SetEnv TELECOM_URL http://10.26.0.5 (Apache).

define('TELECOM_URL', getenv('TELECOM_URL') ?: 'http://10.26.0.5');

/** POST to the Telecom gateway and return decoded JSON (or null on failure). */
function tele_post($action, $data) {
    $url = TELECOM_URL . '/api.php?action=' . urlencode($action);
    $opts = ['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content'       => http_build_query($data),
        'timeout'       => 5,
        'ignore_errors' => true,
    ]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}
