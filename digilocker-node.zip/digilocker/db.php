<?php
// DigiLocker / Aadhaar node DB (SQLite) — Aadhaar e-KYC registry. LAB only.
// Records are consistent with the NSDL node (same people, same mobile + PAN).

function adb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/aadhaar.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS aadhaar_records(
            aadhaar TEXT PRIMARY KEY,   -- 12 digits
            full_name TEXT,
            dob TEXT,
            gender TEXT,
            address TEXT,
            mobile TEXT,
            pan TEXT,
            status TEXT DEFAULT 'ACTIVE'
        )");
        seed($pdo);
    }
    return $pdo;
}

function seed($pdo) {
    if ((int)$pdo->query("SELECT COUNT(*) c FROM aadhaar_records")->fetch()['c'] > 0) return;
    $rows = [
        ['234512345678', 'Rajesh Kumar', '1988-05-12', 'M', '12 MG Road, New Delhi 110001',     '9812345678', 'ABCDE1234F'],
        ['345623456789', 'Priya Sharma', '1992-09-03', 'F', '45 FC Road, Pune 411004',           '9820011122', 'PQRSX5678L'],
        ['456734567890', 'Amit Verma',   '1985-01-25', 'M', '7 Park Street, Kolkata 700016',     '9833044455', 'LMNOP9012Q'],
        ['567845678901', 'Sneha Patel',  '1990-11-18', 'F', '88 CG Road, Ahmedabad 380009',      '9844055566', 'FGHIJ3456M'],
        ['678956789012', 'Vikram Singh', '1983-07-30', 'M', '22 Mall Road, Jaipur 302001',       '9855066677', 'TUVWX7890R'],
    ];
    $st = $pdo->prepare("INSERT INTO aadhaar_records(aadhaar, full_name, dob, gender, address, mobile, pan) VALUES(?,?,?,?,?,?,?)");
    foreach ($rows as $r) { $st->execute($r); }
}
