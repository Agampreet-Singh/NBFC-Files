<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$f = $_GET['status'] ?? '';
$valid = ['PENDING','APPROVED','DISBURSED','REJECTED','DRAFT'];
if ($f && in_array($f, $valid)) {
    $st = $pdo->prepare("SELECT * FROM applications WHERE status=? ORDER BY id DESC"); $st->execute([$f]); $rows = $st->fetchAll();
} else { $rows = $pdo->query("SELECT * FROM applications ORDER BY id DESC")->fetchAll(); }
shell_head('apps', 'Applications');
?>
<div class="filters">
  <a class="chip <?= !$f?'on':'' ?>" href="/applications.php">All</a>
  <?php foreach (['PENDING','APPROVED','DISBURSED','REJECTED'] as $s): ?>
    <a class="chip <?= $f===$s?'on':'' ?>" href="/applications.php?status=<?= $s ?>"><?= $s ?></a>
  <?php endforeach; ?>
</div>
<div class="panel">
  <table class="tbl">
    <tr><th>Reference</th><th>Applicant</th><th>Mobile</th><th>PAN</th><th>Score</th><th>Requested</th><th>Final offer</th><th>Status</th></tr>
    <?php foreach ($rows as $a): ?>
    <tr onclick="location='/application.php?ref=<?= h($a['reference_no']) ?>'">
      <td><?= h($a['reference_no']) ?></td>
      <td><?= h($a['full_name']) ?></td>
      <td><?= h($a['mobile']) ?></td>
      <td><?= h($a['pan']) ?></td>
      <td><?= $a['credit_score'] ?: '-' ?></td>
      <td>&#8377;<?= number_format((float)$a['requested_amount']) ?></td>
      <td><?= $a['final_offer'] !== null ? '&#8377;'.number_format((float)$a['final_offer']) : '-' ?></td>
      <td><?= badge($a['status']) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="8" class="muted">No applications.</td></tr><?php endif; ?>
  </table>
</div>
<?php shell_foot();
