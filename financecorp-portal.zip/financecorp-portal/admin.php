<?php
// admin.php — Credit-Ops console (approve loans, view disbursal queue).
// NOTE: In the full topology this belongs on the LOS node, not the portal.
// It is bundled here so the lab has APPROVED-but-not-disbursed loans to target.
// Trivial auth on purpose (lab). Change/relocate as you wire LOS separately.

session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/layout.php';

$USER = 'creditops';
$PASS = 'changeme';   // lab credential

if (isset($_GET['logout'])) { unset($_SESSION['admin']); header('Location: /admin.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (($_POST['u'] ?? '') === $USER && ($_POST['p'] ?? '') === $PASS) {
        $_SESSION['admin'] = true;
    } else { $err = 'Invalid credentials'; }
}

if (!empty($_SESSION['admin']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
    $stmt = db()->prepare("UPDATE applications SET status='APPROVED' WHERE id=? AND status='PENDING'");
    $stmt->execute([(int)$_POST['approve']]);
    header('Location: /admin.php'); exit;
}

render_head('Credit Ops');

if (empty($_SESSION['admin'])): ?>
  <form class="panel" method="post" style="max-width:420px">
    <h2>Credit Ops login</h2>
    <?php if (!empty($err)) echo '<p class="hint" style="color:#c0392b">' . h($err) . '</p>'; ?>
    <label>Username<input name="u" required></label>
    <label>Password<input type="password" name="p" required></label>
    <button class="btn" name="login" value="1" type="submit">Sign in</button>
  </form>
<?php else:
  $rows = db()->query("SELECT * FROM applications ORDER BY id DESC")->fetchAll(); ?>
  <div class="panel">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <h2>Loan applications</h2><a class="muted" href="/admin.php?logout=1">Logout</a>
    </div>
    <table class="tbl">
      <tr><th>Ref</th><th>Applicant</th><th>Amount</th><th>Beneficiary A/C</th><th>Status</th><th></th></tr>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= h($r['reference_no']) ?></td>
        <td><?= h($r['full_name']) ?></td>
        <td>&#8377;<?= number_format((float)$r['loan_amount']) ?></td>
        <td><?= h($r['beneficiary_account']) ?></td>
        <td><span class="badge <?= strtolower(h($r['status'])) ?>"><?= h($r['status']) ?></span></td>
        <td>
          <?php if ($r['status'] === 'PENDING'): ?>
            <form method="post" style="margin:0"><button class="btn small" name="approve" value="<?= (int)$r['id'] ?>">Approve</button></form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
<?php endif;
render_foot();
