<?php
require_once __DIR__ . '/config.php';

function step_labels() {
    return [1=>'Mobile',2=>'PAN',3=>'Address',4=>'Industry',5=>'Credit',6=>'Offer',
            7=>'Statement',8=>'Bank',9=>'Final Offer',10=>'KYC',11=>'Selfie',12=>'Work',13=>'e-Mandate'];
}

function render_stepper($step) {
    $labels = step_labels();
    echo '<div class="stepper"><div class="stepper-track">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
        $mark = $n < $step ? '&#10003;' : $n;
        echo '<div class="stp ' . $cls . '"><span class="node">' . $mark . '</span><em>' . h($l) . '</em></div>';
        if ($n < count($labels)) echo '<span class="seg ' . ($n < $step ? 'done' : '') . '"></span>';
    }
    echo '</div></div>';
}

function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css"></head><body>';
    echo '<div class="split">';
    // LEFT brand panel
    echo '<aside class="brandpanel"><div class="bp-in">';
    echo '<div class="bp-logo"><span class="logo">F</span><div class="bp-name"><b>FinanceCorp</b><small>Instant Personal Loan</small></div></div>';
    echo '<h1>Quick, easy loans up to <span class="hl">&#8377;5,00,000</span></h1>';
    echo '<ul class="bp-ticks"><li>Easy personal loan for all purposes</li><li>Collateral-free loans</li><li>Seamless login process</li><li>Simple repayment</li></ul>';
    echo '<div class="bp-cards"><div class="bp-card">&#9201; Calculate your EMI within minutes</div><div class="bp-card">&#128176; Low interest rates &amp; minimal fees</div><div class="bp-card">&#128241; 24x7 access to the loan app</div></div>';
    echo '</div></aside>';
    // RIGHT content pane
    echo '<section class="pane"><div class="pane-scroll">';
    if ($step > 0) render_stepper($step);
    echo '<div class="pane-inner">';
}

function pfoot() { echo '</div></div></section></div></body></html>'; }

/** Full-page terminal screen (reject / already-applied). $type = 'reject' | 'info'. Ends the request. */
function result_screen($type, $title, $reason = '', $sub = '', $showStatus = true) {
    phead('Application Status', 0);
    $mark = $type === 'reject' ? '&#10005;' : '&#33;';
    echo '<div class="result-box ' . ($type === 'reject' ? 'is-reject' : 'is-info') . '">';
    echo '<div class="result-mark">' . $mark . '</div>';
    echo '<h2 class="result-title">' . h($title) . '</h2>';
    if ($reason !== '') echo '<p class="result-reason">' . h($reason) . '</p>';
    if ($sub !== '')    echo '<p class="muted result-sub">' . h($sub) . '</p>';
    echo '<div class="result-actions">';
    if ($showStatus) echo '<a class="btn ghost" href="/status.php">Check application status</a>';
    echo '<a class="btn" href="/login.php">Back to home</a>';
    echo '</div></div>';
    pfoot(); exit;
}
function card_open($h){ echo '<h2 class="pane-h">' . h($h) . '</h2>'; }
function card_close(){}
