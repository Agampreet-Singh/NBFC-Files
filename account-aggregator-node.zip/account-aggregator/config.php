<?php
// config.php — Account Aggregator (fetches from Bank Server, OTP consent via Telecom).
define('BANK_URL',    getenv('BANK_URL')    ?: 'http://10.22.0.2');
define('TELECOM_URL', getenv('TELECOM_URL') ?: 'http://10.26.0.5');
define('OTP_SERVICE', 'AA Consent');

function http_post($base, $action, $data) {
    $url = rtrim($base, '/') . '/api.php?action=' . urlencode($action);
    $opts = ['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content'       => http_build_query($data),
        'timeout'       => 6,
        'ignore_errors' => true,
    ]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}

function mask_acct($no) {
    return strlen($no) > 4 ? str_repeat('X', strlen($no) - 4) . substr($no, -4) : $no;
}
