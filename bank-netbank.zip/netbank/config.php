<?php
// Per-bank NetBanking portal. One codebase, served on a different port per bank
// (Apache sets BANK_CODE per vhost). All banks share the master bank DB.

define('BANK_DB', getenv('BANK_DB') ?: '/var/www/html/data/bank.db');
define('TELECOM_URL', getenv('TELECOM_URL') ?: 'http://10.26.0.5');

function bank_code() {
    $c = $_SERVER['BANK_CODE'] ?? getenv('BANK_CODE') ?? 'HDFC';
    return strtoupper(trim($c));
}
function bank_meta($code = null) {
    $code = $code ?: bank_code();
    $m = [
        'HDFC' => ['HDFC Bank',              '#004C8F', 'NetBanking'],
        'PUNB' => ['Punjab National Bank',   '#7A1F2B', 'PNB ONE'],
        'BARB' => ['Bank of Baroda',         '#F15A22', 'bob World'],
        'SBIN' => ['State Bank of India',    '#22409A', 'OnlineSBI'],
        'ICIC' => ['ICICI Bank',             '#AE292E', 'iMobile'],
        'UTIB' => ['Axis Bank',              '#97144D', 'Axis Internet Banking'],
        'KKBK' => ['Kotak Mahindra Bank',    '#C4122E', 'Kotak Netbanking'],
    ];
    return $m[$code] ?? [$code . ' Bank', '#06402b', 'NetBanking'];
}
function pdo_bank() {
    static $p = null;
    if ($p === null) { $p = new PDO('sqlite:' . BANK_DB); $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); }
    return $p;
}
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }
function inr($n) { return '&#8377;' . number_format((float)$n, 2); }

function tele_post($action, $data) {
    $url = TELECOM_URL . '/api.php?action=' . urlencode($action);
    $opts = ['http' => ['method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data), 'timeout' => 5, 'ignore_errors' => true]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}

// Manager credentials (per lab). Same scheme for every bank.
define('MANAGER_USER', 'manager');
define('MANAGER_PASS', 'bank@123');
