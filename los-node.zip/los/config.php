<?php
// LOS config — central orchestrator. Talks to every service node.
define('NSDL_URL',       getenv('NSDL_URL')       ?: 'http://10.23.0.2');
define('DIGILOCKER_URL', getenv('DIGILOCKER_URL') ?: 'http://10.23.0.3');
define('BANK_URL',       getenv('BANK_URL')       ?: 'http://10.22.0.2');
define('AA_URL',         getenv('AA_URL')         ?: 'http://10.24.0.2');
define('TELECOM_URL',    getenv('TELECOM_URL')    ?: 'http://10.26.0.5');

function svc_list() {
    return [
        ['key' => 'NSDL',       'name' => 'NSDL PAN Verification', 'url' => NSDL_URL],
        ['key' => 'DIGILOCKER', 'name' => 'DigiLocker / Aadhaar',  'url' => DIGILOCKER_URL],
        ['key' => 'BANK',       'name' => 'Bank Core Server',      'url' => BANK_URL],
        ['key' => 'AA',         'name' => 'Account Aggregator',    'url' => AA_URL],
        ['key' => 'TELECOM',    'name' => 'Telecom OTP Gateway',   'url' => TELECOM_URL],
    ];
}

function http_post($base, $action, $data) {
    $url = rtrim($base, '/') . '/api.php?action=' . urlencode($action);
    $opts = ['http' => ['method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data), 'timeout' => 6, 'ignore_errors' => true]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}

/** Is a service node reachable on port 80? */
function svc_up($url) {
    $host = parse_url($url, PHP_URL_HOST);
    $port = parse_url($url, PHP_URL_PORT) ?: 80;
    $fp = @fsockopen($host, $port, $e, $s, 1.5);
    if ($fp) { fclose($fp); return true; }
    return false;
}

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }

// --- underwriting thresholds ---
define('MIN_SCORE', 650);   // score at or below this -> reject (intent to pay)
define('MAX_FOIR', 0.60);   // (existing EMI + new EMI) / income above this -> reject (capability)

/** Send a plain SMS notification to the applicant via Telecom. */
function notify_sms($mobile, $text) {
    if (!$mobile) return null;
    return http_post(TELECOM_URL, 'notify', ['mobile' => $mobile, 'text' => $text, 'service' => 'FinanceCorp']);
}
