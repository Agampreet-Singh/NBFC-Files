<?php
// layout.php — professional government-services style portal (fictional PAN authority).
function nhead($title = 'PAN Services') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . htmlspecialchars($title) . ' — e-PAN Portal</title>';
    echo '<link rel="stylesheet" href="/assets/style.css"></head><body>';
    echo '<div class="topstrip"><div class="wrap">Revenue Services Department &middot; e-PAN Online Services</div></div>';
    echo '<header class="gov-nav"><div class="wrap">';
    echo '<a class="emblem" href="/index.php"><span class="seal">&#9733;</span><span class="ttl"><b>e-PAN Portal</b><small>Permanent Account Number Services</small></span></a>';
    echo '<nav><a href="/index.php">Home</a><a href="/apply.php">Apply for PAN</a></nav>';
    echo '</div></header><main class="wrap">';
}
function nfoot() {
    echo '</main><footer class="gov-foot"><div class="wrap">';
    echo 'e-PAN Online Services &middot; Revenue Services Department. For assistance contact your service centre.';
    echo '</div></footer></body></html>';
}
