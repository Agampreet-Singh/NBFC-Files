# FinanceCorp Loan Portal — Lab Target (FinanceCorp Portal node)

A **fictional** NBFC loan portal for the **Silent Disbursal** cyber-range scenario.
For deployment on the `FinanceCorp Portal` node **only, inside the isolated range**.
Not a real financial institution; not for any public/internet deployment.

## What it is
A realistic 3-stage online loan application, matching your flow:

1. **Personal Details** — name, DOB, contact, employment, income, loan amount
2. **Banking & KYC** — PAN/Aadhaar, bank account (disbursal account), **document upload**
3. **Repayment & e-Sign** — tenure/EMI, agree + e-sign, submit

Applications are stored as `PENDING`. The Credit-Ops console (`/admin.php`) approves them to
`APPROVED` — these APPROVED-but-not-disbursed loans are what the red team targets later.

## Stack
PHP + Apache + SQLite (no DB server needed). Data file auto-creates at `data/financecorp.db`.

## Deploy (Ubuntu node)
```
sudo apt update && sudo apt install -y apache2 php libapache2-mod-php php-sqlite3
sudo cp -r financecorp-portal/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html
sudo rm -f /var/www/html/index.html
sudo systemctl restart apache2
```
Portal: `http://<portal-node>/`  ·  Credit-Ops: `http://<portal-node>/admin.php` (creditops / changeme)

## >>> Intentional weakness (the red-team entry point) <<<
In `apply.php`, Stage 2 (`step=2`) handles the uploads with **no validation**:
- no file-type / extension / MIME / content check
- original (attacker-controlled) filename kept
- files written **inside the web root** at `/uploads/`, directly reachable over HTTP

This is the deliberate **unrestricted file upload (CWE-434)** vulnerability. It is clearly
commented in the code. This maps to the real campaign's documented initial-access technique
(CERT-In CIAD-2026-0046) and to the scenario's **Delivery -> Exploitation** phase.

To tune difficulty, add validation in that block:
- Easy (default): no checks
- Medium: extension blacklist (bypassable)
- Hard: content/MIME check (needs a bypass)

## Attack-chain mapping
- **Recon:** enumerate the portal, find the Stage 2 upload
- **Delivery:** apply as a fake borrower, upload a malicious file at Stage 2
- **Exploitation:** reach the uploaded file under `/uploads/` and gain a foothold
- **Later phases:** pivot to LOS (loan DB / beneficiary), then Disburse, then Bank

## What is NOT included (by design)
No exploit code, web shell, or payload. The portal is only the **vulnerable target**.
Trainees build the exploitation themselves within the range.

## Topology note
Credit-Ops/approval and the loan datastore conceptually live on the **LOS node**.
They are bundled here so the portal works standalone. When you wire LOS separately,
move `admin.php` + the DB to the LOS node and have the portal submit applications to it.
