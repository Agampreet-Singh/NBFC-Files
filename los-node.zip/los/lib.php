<?php
// lib.php — auth + professional product shell for the LOS console.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function require_login() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['los_user'])) { header('Location: /login.php'); exit; }
}

function badge($status) {
    $m = ['DRAFT'=>'draft','PENDING'=>'pending','APPROVED'=>'approved','DISBURSED'=>'disbursed','REJECTED'=>'rejected'];
    $c = $m[$status] ?? 'draft';
    return '<span class="badge ' . $c . '">' . h($status) . '</span>';
}

function shell_head($active, $title = 'LOS') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp LOS</title>';
    echo '<link rel="stylesheet" href="/assets/style.css"></head><body><div class="app">';
    // sidebar
    $nav = [
        'dashboard' => ['/index.php', '&#9632;', 'Dashboard'],
        'apps'      => ['/applications.php', '&#9776;', 'Applications'],
        'disbursal' => ['/disbursal.php', '&#8599;', 'Disbursal Queue'],
        'services'  => ['/services.php', '&#9881;', 'Services'],
    ];
    echo '<aside class="side"><div class="logo"><span class="mark">LOS</span><div><b>FinanceCorp</b><small>Loan Origination</small></div></div><nav>';
    foreach ($nav as $k => $v) {
        $cls = $k === $active ? 'on' : '';
        echo '<a class="' . $cls . '" href="' . $v[0] . '"><span class="ic">' . $v[1] . '</span>' . $v[2] . '</a>';
    }
    echo '</nav><div class="side-foot">v1.0 &middot; Lab</div></aside>';
    // main + topbar
    echo '<div class="main"><header class="top"><h1>' . h($title) . '</h1>';
    echo '<div class="who">' . h($_SESSION['los_user'] ?? '') . ' &middot; <a href="/login.php?logout=1">Logout</a></div></header><div class="content">';
}

function shell_foot() { echo '</div></div></div></body></html>'; }
