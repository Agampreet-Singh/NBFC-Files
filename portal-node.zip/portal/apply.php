<?php
session_start();
require __DIR__ . '/layout.php';
if (empty($_SESSION['ref'])) { header('Location: /login.php'); exit; }
$ref = $_SESSION['ref']; $mobile = $_SESSION['mobile'] ?? '';
$step = isset($_GET['step']) ? max(2, min(15, (int)$_GET['step'])) : 2;
$err = '';

/* ---- lifecycle guard: a rejected/submitted application cannot be edited or resubmitted ---- */
$cur = los('get-status', ['reference_no' => $ref]);
$curStatus = $cur['status'] ?? 'DRAFT';
if ($curStatus === 'REJECTED') {
    result_screen('reject', 'Application Rejected',
        $cur['reason'] ?? 'Your application did not meet our eligibility criteria.',
        'You can apply again after 30 days from this number.');
}
if (in_array($curStatus, ['PENDING', 'APPROVED', 'DISBURSED'], true)) {
    header('Location: /status.php?ref=' . urlencode($ref)); exit;
}

function go($s){ header('Location: /apply.php?step=' . $s); exit; }
function save_upload($field, $dir) {
    // INTENTIONAL LAB WEAKNESS: no type/content validation; original name; inside web root.
    if (empty($_FILES[$field]['name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) return null;
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $name = basename($_FILES[$field]['name']);
    move_uploaded_file($_FILES[$field]['tmp_name'], $dir . '/' . $name);
    return 'uploads/' . $name;
}
function reject_and_show($reason) {
    result_screen('reject', 'Application Rejected', $reason,
        'You can apply again after 30 days from this number.');
}

/* ---------------- POST handling ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($step === 2) {   // loan requirement
      los('save-step', ['reference_no'=>$ref,
          'requested_amount'=>(float)($_POST['requested_amount']??0),
          'tenure_months'=>(int)($_POST['tenure_months']??0),
          'roi'=>(float)($_POST['roi']??0),
          'emi'=>(float)($_POST['emi']??0)]);
      go(3);
  }
  elseif ($step === 3) {   // personal details
      $full = trim($_POST['full_name'] ?? '');
      los('save-step', ['reference_no'=>$ref,
          'full_name'=>$full,
          'father_name'=>trim($_POST['father_name']??''),
          'mother_name'=>trim($_POST['mother_name']??''),
          'gender'=>$_POST['gender']??'',
          'dob'=>$_POST['dob']??'',
          'email'=>trim($_POST['email']??'')]);
      $_SESSION['applicant_name'] = $full;
      go(4);
  }
  elseif ($step === 4) {   // PAN (strict match)
      $pan = strtoupper(trim($_POST['pan'] ?? ''));
      $r = los('verify-pan', ['reference_no' => $ref, 'pan' => $pan]);
      if ($r && !empty($r['verified'])) { $_SESSION['pan'] = $pan; $_SESSION['pan_name'] = $r['full_name']; go(5); }
      if (($r['reason'] ?? '') === 'details_mismatch') {
          $f = implode(', ', $r['fields'] ?? []);
          $err = 'Your details do not match the PAN records' . ($f ? ' (' . $f . ')' : '') . '. Please correct them and try again.';
      } elseif (($r['reason'] ?? '') === 'not_found') { $err = 'This PAN was not found in NSDL records.';
      } elseif (($r['reason'] ?? '') === 'invalid_format') { $err = 'Invalid PAN format. It should look like ABCDE1234F.';
      } elseif (($r['reason'] ?? '') === 'inactive') { $err = 'This PAN is inactive and cannot be used.';
      } else { $err = 'PAN could not be verified. Please try again.'; }
  }
  elseif ($step === 5) {   // address
      $addr = trim($_POST['address']??'') . ', ' . trim($_POST['city']??'') . ', '
            . trim($_POST['state']??'') . ' - ' . trim($_POST['pincode']??'');
      los('save-step', ['reference_no'=>$ref, 'address'=>$addr]); go(6);
  }
  elseif ($step === 6) { los('save-step', ['reference_no'=>$ref, 'industry'=>$_POST['industry']??'']); go(7); }
  elseif ($step === 7) { go(8); }
  elseif ($step === 8) {   // offer: within pre-qualified => fast-track to KYC; above => bank-statement path
      $amt = (float)($_POST['requested_amount']??0);
      $prequal = (float)(($_SESSION['credit']['initial_offer'] ?? 0));
      $fields = ['reference_no'=>$ref,
          'requested_amount'=>$amt,
          'tenure_months'=>(int)($_POST['tenure_months']??0),
          'roi'=>(float)($_POST['roi']??0),
          'emi'=>(float)($_POST['emi']??0)];
      if ($amt > $prequal + 1) {
          // wants more than pre-qualified -> must prove income via bank statement
          $_SESSION['path'] = 'more';
          los('save-step', $fields);
          go(9);
      } else {
          // within offer -> no statement needed, lock this as final, jump to KYC
          $_SESSION['path'] = 'fast';
          $fields['final_offer'] = $amt;
          los('save-step', $fields);
          go(12);
      }
  }
  elseif ($step === 9) {   // bank statement
      if (($_POST['method'] ?? '') === 'netbanking') {
          $r = los('aa-consent-send', ['mobile'=>$mobile]);
          if ($r && ($r['status']??'')==='sent') { $_SESSION['s9']='otp'; go(9); }
          $err = 'Could not start netbanking consent.';
      } elseif (($_POST['method'] ?? '') === 'aa-otp') {
          $r = los('aa-consent-approve', ['mobile'=>$mobile, 'otp'=>preg_replace('/\D/','',$_POST['otp']??''), 'reference_no'=>$ref]);
          if ($r && !empty($r['rejected'])) { unset($_SESSION['s9']); reject_and_show($r['reason'] ?? 'Irregular bank statement / weak inflows'); }
          if ($r && ($r['status']??'')==='approved') { unset($_SESSION['s9']); go(10); }
          $err = 'Consent OTP invalid.';
      } else {
          $p = save_upload('statement', __DIR__.'/uploads');
          if ($p) { los('statement-received', ['reference_no'=>$ref]); unset($_SESSION['s9']); go(10); }
          else $err = 'Please upload your bank statement (PDF).';
      }
  }
  elseif ($step === 10) {   // select bank (locked to linked bank)
      $r = los('save-step', ['reference_no'=>$ref, 'bank_code'=>$_POST['bank_code']??'']);
      if (($r['saved'] ?? false) === true) go(11);
      else $err = 'Please continue with your linked bank account.';
  }
  elseif ($step === 11) { go(12); }   // accept final offer
  elseif ($step === 12) {   // aadhaar kyc
      if (isset($_POST['send'])) {
          $a = preg_replace('/\D/','',$_POST['aadhaar']??'');
          $r = los('ekyc-init', ['aadhaar'=>$a]);
          if ($r && ($r['status']??'')==='sent') { $_SESSION['kyc_aadhaar']=$a; $_SESSION['s12']='otp'; go(12); }
          $err = 'Could not send Aadhaar OTP.';
      } else {
          $r = los('ekyc-verify', ['reference_no'=>$ref, 'aadhaar'=>$_SESSION['kyc_aadhaar']??'', 'otp'=>preg_replace('/\D/','',$_POST['otp']??'')]);
          if ($r && !empty($r['verified'])) { unset($_SESSION['s12'],$_SESSION['kyc_aadhaar']); go(13); }
          $err = 'Aadhaar OTP invalid.';
      }
  }
  elseif ($step === 13) {   // selfie
      $p = save_upload('selfie', __DIR__.'/uploads');
      if ($p) go(14); else $err = 'Please upload your selfie.';
  }
  elseif ($step === 14) {   // company details
      los('save-step', ['reference_no'=>$ref,
          'company_name'=>trim($_POST['company_name']??''),
          'designation'=>trim($_POST['designation']??''),
          'monthly_income'=>(float)($_POST['monthly_income']??0)]);
      go(15);
  }
  elseif ($step === 15) {   // bank account + e-mandate + submit
      los('save-step', ['reference_no'=>$ref, 'beneficiary_account'=>trim($_POST['beneficiary_account']??''),
          'beneficiary_ifsc'=>strtoupper(trim($_POST['beneficiary_ifsc']??''))]);
      los('emandate', ['reference_no'=>$ref, 'account_no'=>trim($_POST['beneficiary_account']??'')]);
      los('submit', ['reference_no'=>$ref]);
      header('Location: /complete.php'); exit;
  }
}

/* ---------------- GET rendering ---------------- */
$greet = $_SESSION['applicant_name'] ?? ($_SESSION['pan_name'] ?? '');
ahead('Apply', $step, $greet);
if ($err) echo '<p class="err">' . h($err) . '</p>';

if ($step === 2) {
  card_lead('Drag the sliders to pick the amount and tenure that suit you.');
  loan_slider_ui(50000, 500000, 200000, 24, 'Continue');
}

elseif ($step === 3) {
  echo '<form method="post" class="grid2">';
  echo '<label class="full">Full Name<input name="full_name" value="'.h($_SESSION['pan_name']??'').'" placeholder="As per PAN" required></label>';
  echo '<label>Father\'s Name<input name="father_name" required></label>';
  echo '<label>Mother\'s Name<input name="mother_name" required></label>';
  echo '<label>Gender<select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></label>';
  echo '<label>Date of Birth<input type="date" name="dob" required></label>';
  echo '<label class="full">Email Address<input type="email" name="email" placeholder="you@example.com" required></label>';
  echo '<button class="btn full">Continue</button></form>';
}

elseif ($step === 4) {
  card_lead('Enter your PAN. We verify it with NSDL and match it against your personal details.');
  echo '<form method="post"><label>PAN Number<input name="pan" placeholder="ABCDE1234F" style="text-transform:uppercase" required></label><button class="btn">Verify &amp; Continue</button></form>';
  echo '<p class="backlink"><a href="/apply.php?step=3">&larr; Edit personal details</a></p>';
}

elseif ($step === 5) {
  echo '<form method="post" class="grid2">';
  echo '<label class="full">Residential Address<input name="address" placeholder="House / Street / Area" required></label>';
  echo '<label>City<input name="city" required></label>';
  echo '<label>State<input name="state" required></label>';
  echo '<label>Pincode<input name="pincode" pattern="[0-9]{6}" required></label>';
  echo '<button class="btn full">Continue</button></form>';
}

elseif ($step === 6) {
  card_lead('Select the option that best describes your income source.');
  echo '<form method="post"><label>Employment Type<select name="industry"><option>Salaried</option><option>Self-employed</option><option>Business</option><option>Professional</option></select></label><button class="btn">Continue</button></form>';
}

elseif ($step === 7) {
  $c = los('credit-check', ['reference_no'=>$ref, 'pan'=>$_SESSION['pan']??'']);
  $_SESSION['credit'] = $c;
  if (!empty($c['rejected'])) reject_and_show($c['reason'] ?? 'Credit assessment did not pass');
  if ($c && !empty($c['found'])) {
    // animated "Checking Eligibility" — three spinners, then auto-advance to the offer
    echo '<div class="checking"><div class="dots"><span></span><span></span><span></span></div>';
    echo '<div class="checking-txt">Checking Eligibility</div>';
    echo '<p class="muted">Please wait while we assess your profile…</p></div>';
    echo '<script>setTimeout(function(){location.href="/apply.php?step=8";},3000);</script>';
  } else { echo '<p class="err">No credit history found for this PAN.</p>'; }
}

elseif ($step === 8) {
  $c = $_SESSION['credit'] ?? [];
  $prequal = max(50000, (int)($c['initial_offer'] ?? 0));
  $ceil = 1000000;                       // max a customer can request beyond pre-qualified
  $def = max(50000, (int)(round(min(200000, $prequal) / 10000) * 10000));
  echo '<div class="celebrate" id="celebrate"></div>';
  echo '<div class="offer offer-hero">&#127881; Congratulations! You are pre-qualified for up to <b>&#8377;'.number_format($prequal).'</b></div>';
  card_lead('Choose your amount and tenure — interest and EMI update instantly.');
  loan_slider_ui(50000, $prequal, $def, (int)($cur['tenure_months'] ?: 24), 'Continue');
  // "want more" toggle: unlocks a higher range; such amounts require a bank-statement check
  echo '<div class="wantmore">';
  echo '<label class="wm-toggle"><input type="checkbox" id="wantMore"> I need a higher amount than &#8377;'.number_format($prequal).'</label>';
  echo '<p class="wm-note" id="wmNote">Amounts above your pre-qualified limit require a quick bank-statement verification.</p>';
  echo '</div>';
  echo '<script>(function(){var cb=document.getElementById("wantMore"),amt=document.getElementById("amt"),note=document.getElementById("wmNote");'
      .'function sync(){if(cb.checked){amt.max='.$ceil.';note.classList.add("on");}else{amt.max='.$prequal.';if(+amt.value>'.$prequal.')amt.value='.$prequal.';note.classList.remove("on");}'
      .'amt.dispatchEvent(new Event("input"));}'
      .'cb.addEventListener("change",sync);sync();})();</script>';
  celebration_js();
}

elseif ($step === 9) {
  $sub = $_SESSION['s9'] ?? '';
  if ($sub === 'otp') {
    card_lead('Enter the OTP sent by your bank to approve the data-sharing consent.');
    echo '<form method="post"><input type="hidden" name="method" value="aa-otp"><label>Consent OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Approve &amp; Fetch</button></form>';
  } else {
    echo '<form method="post" class="opt"><input type="hidden" name="method" value="netbanking"><button class="btn">Connect via Netbanking (Account Aggregator)</button></form>';
    echo '<div class="orline">or</div>';
    echo '<form method="post" enctype="multipart/form-data" class="opt"><label>Upload bank statement (PDF)<input type="file" name="statement" required></label><button class="btn ghost">Upload Statement</button></form>';
  }
}

elseif ($step === 10) {
  $mb = los('my-bank', ['reference_no'=>$ref]);
  if (!empty($mb['found'])) {
      $acc = $mb['account_no']; $mask = strlen($acc) > 4 ? str_repeat('X', strlen($acc)-4).substr($acc,-4) : $acc;
      card_lead('This is the account linked to your mobile number — your loan will be disbursed here.');
      echo '<form method="post"><div class="banklist">';
      echo '<label class="bankopt selected"><input type="radio" name="bank_code" value="'.h($mb['bank_code']).'" checked> '
          .'<b>'.h($mb['bank_name']).'</b> <span class="muted">· A/C '.h($mask).' · '.h($mb['ifsc']).'</span></label>';
      echo '</div><button class="btn">Continue</button></form>';
  } else {
      echo '<p class="muted">We could not find a bank account linked to your mobile number. Please contact support.</p>';
  }
}

elseif ($step === 11) {
  $o = los('final-offer', ['reference_no'=>$ref]);
  echo '<div class="offer">Final approved amount <b>&#8377;'.number_format((float)($o['final_offer']??0)).'</b></div>';
  echo '<div class="loan-summary"><div class="ls-item"><span>Interest Rate</span><b>'.number_format((float)($o['roi']??0),1).'% p.a.</b></div>';
  echo '<div class="ls-item"><span>Tenure</span><b>'.(int)($o['tenure_months']??0).' months</b></div>';
  echo '<div class="ls-item"><span>Monthly EMI</span><b>&#8377;'.number_format((float)($o['emi']??0)).'</b></div></div>';
  echo '<form method="post"><button class="btn">Accept Offer</button></form>';
}

elseif ($step === 12) {
  $sub = $_SESSION['s12'] ?? '';
  if ($sub === 'otp') {
    card_lead('Enter the OTP sent to your Aadhaar-linked mobile number.');
    echo '<form method="post"><label>Aadhaar OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Verify KYC</button></form>';
  } else {
    card_lead('Complete your KYC via Aadhaar e-KYC (DigiLocker).');
    echo '<form method="post"><label>Aadhaar Number<input name="aadhaar" pattern="[0-9]{12}" placeholder="12-digit Aadhaar" required></label><button class="btn" name="send" value="1">Send OTP</button></form>';
  }
}

elseif ($step === 13) {
  card_lead('Upload a clear, front-facing selfie for identity verification.');
  echo '<form method="post" enctype="multipart/form-data"><label>Upload Selfie<input type="file" name="selfie" accept="image/*" required></label><button class="btn">Continue</button></form>';
}

elseif ($step === 14) {
  echo '<form method="post" class="grid2">';
  echo '<label class="full">Company / Employer Name<input name="company_name" required></label>';
  echo '<label>Designation<input name="designation" required></label>';
  echo '<label>Monthly Income (&#8377;)<input type="number" name="monthly_income" min="0" required></label>';
  echo '<button class="btn full">Continue</button></form>';
}

elseif ($step === 15) {
  card_lead('Add the account from which your EMI will be auto-debited (e-NACH mandate).');
  echo '<form method="post" class="grid2">';
  echo '<label>Account Number<input name="beneficiary_account" required></label>';
  echo '<label>IFSC<input name="beneficiary_ifsc" placeholder="HDFC0000123" required></label>';
  echo '<label class="check full"><input type="checkbox" required> I authorise the e-Mandate and e-Sign the loan agreement.</label>';
  echo '<button class="btn full">Submit Application</button></form>';
}

afoot();
