<?php
// LOS orchestration API — called by the FinanceCorp portal (and the Disburse node).
// LOS validates each step against the service nodes and is the loan system of record.
// LAB / isolated range only.

require __DIR__ . '/config.php';
require __DIR__ . '/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';
$pdo = ldb();

function app_by_ref($pdo, $ref) {
    $s = $pdo->prepare("SELECT * FROM applications WHERE reference_no=?"); $s->execute([$ref]); return $s->fetch();
}
function touch_app($pdo, $ref, $fields) {
    $set = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
    $vals = array_values($fields); $vals[] = $ref;
    $pdo->prepare("UPDATE applications SET $set, updated_at=datetime('now') WHERE reference_no=?")->execute($vals);
}

if (!defined('REAPPLY_DAYS')) define('REAPPLY_DAYS', 30);   // cooldown after a rejection

/** Reject an application mid-journey, set reason, notify the borrower. */
function reject_app($pdo, $ref, $mobile, $reason) {
    touch_app($pdo, $ref, ['status' => 'REJECTED', 'decision_reason' => $reason]);
    if (function_exists('notify_sms'))
        notify_sms($mobile, "FinanceCorp: Your loan application $ref could not be approved. Reason: $reason. You may reapply after " . REAPPLY_DAYS . " days.");
}

/** Underwriting decision engine: intent + capability + contactability + bank statement. */
function evaluate_app($app) {
    $reasons = [];
    $score   = (int)$app['credit_score'];
    $perf    = $app['credit_performance'];
    $income  = (float)$app['monthly_income'];
    $emi     = (float)$app['emi'];
    $exEmi   = (float)$app['existing_emi'];
    $health  = $app['bank_health'];

    // Intent to pay — credit score + repayment history
    if ($score > 0 && $score <= MIN_SCORE) $reasons[] = 'Low credit score (' . $score . ')';
    if ($perf === 'Weak') $reasons[] = 'Poor repayment history';

    // Bank statement behaviour — only reject when verified and poor
    if ($health === 'Poor') $reasons[] = 'Irregular bank statement / weak inflows';

    // Capability to repay — FOIR
    $foir = $income > 0 ? ($exEmi + $emi) / $income : 1;
    if ($foir > MAX_FOIR) $reasons[] = 'Insufficient repayment capacity (FOIR ' . round($foir * 100) . '%)';

    // Contactability
    if (empty($app['mobile'])) $reasons[] = 'Not contactable';

    return [empty($reasons) ? 'PENDING' : 'REJECTED', implode('; ', $reasons), round($foir, 2)];
}

/* ---------- application lifecycle ---------- */
if ($action === 'create-application') {
    $mobile = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    // Look at this number's most recent application before letting them start a new one.
    $s = $pdo->prepare("SELECT * FROM applications WHERE mobile=? ORDER BY id DESC LIMIT 1");
    $s->execute([$mobile]); $prev = $s->fetch();
    if ($prev) {
        $st = $prev['status'];
        // An application already submitted / approved / disbursed -> cannot apply again.
        if (in_array($st, ['PENDING', 'APPROVED', 'DISBURSED'], true)) {
            echo json_encode(['status' => 'exists', 'reason' => 'already_applied',
                'reference_no' => $prev['reference_no'], 'app_status' => $st]); exit;
        }
        // Rejected -> enforce the cooldown window.
        if ($st === 'REJECTED') {
            $days = floor((time() - strtotime($prev['updated_at'])) / 86400);
            $left = REAPPLY_DAYS - $days;
            if ($left > 0) {
                echo json_encode(['status' => 'blocked', 'reason' => 'cooldown',
                    'days_left' => (int)$left, 'decision_reason' => $prev['decision_reason'],
                    'reference_no' => $prev['reference_no']]); exit;
            }
        }
        // An abandoned DRAFT -> resume it instead of piling up duplicates.
        if ($st === 'DRAFT') { echo json_encode(['reference_no' => $prev['reference_no'], 'status' => 'resumed']); exit; }
    }
    $ref = 'FC' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
    $pdo->prepare("INSERT INTO applications(reference_no, mobile, status) VALUES(?,?, 'DRAFT')")->execute([$ref, $mobile]);
    echo json_encode(['reference_no' => $ref, 'status' => 'created']); exit;
}

/* ---------- step 1: login OTP (proxy to Telecom) ---------- */
if ($action === 'otp-send') {
    echo json_encode(http_post(TELECOM_URL, 'send', ['mobile' => preg_replace('/\D/','',$_POST['mobile'] ?? ''), 'service' => 'FinanceCorp'])
        ?: ['status' => 'error', 'reason' => 'telecom_unreachable']); exit;
}
if ($action === 'otp-verify') {
    echo json_encode(http_post(TELECOM_URL, 'verify', ['mobile' => preg_replace('/\D/','',$_POST['mobile'] ?? ''), 'otp' => preg_replace('/\D/','',$_POST['otp'] ?? '')])
        ?: ['valid' => false, 'reason' => 'telecom_unreachable']); exit;
}

/* ---------- step 2: PAN via NSDL ---------- */
if ($action === 'verify-pan') {
    $ref = $_POST['reference_no'] ?? ''; $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $r = http_post(NSDL_URL, 'verify', ['pan' => $pan]);
    if ($r && !empty($r['valid'])) {
        touch_app($pdo, $ref, ['pan' => $pan, 'full_name' => $r['full_name'], 'pan_verified' => 1]);
        echo json_encode(['verified' => true, 'full_name' => $r['full_name'], 'dob' => $r['dob'] ?? '']);
    } else {
        echo json_encode(['verified' => false, 'reason' => $r['reason'] ?? 'nsdl_unreachable']);
    }
    exit;
}

/* ---------- step 10: Aadhaar e-KYC via DigiLocker ---------- */
if ($action === 'ekyc-init') {
    $r = http_post(DIGILOCKER_URL, 'ekyc-send', ['aadhaar' => preg_replace('/\D/', '', $_POST['aadhaar'] ?? '')]);
    echo json_encode($r ?: ['status' => 'error', 'reason' => 'digilocker_unreachable']); exit;
}
if ($action === 'ekyc-verify') {
    $ref = $_POST['reference_no'] ?? '';
    $a   = preg_replace('/\D/', '', $_POST['aadhaar'] ?? '');
    $r = http_post(DIGILOCKER_URL, 'ekyc-verify', ['aadhaar' => $a, 'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]);
    if ($r && !empty($r['valid'])) {
        touch_app($pdo, $ref, ['aadhaar_last4' => substr($a, -4), 'address' => $r['address'], 'kyc_verified' => 1]);
        echo json_encode(['verified' => true, 'full_name' => $r['full_name'], 'address' => $r['address']]);
    } else {
        echo json_encode(['verified' => false, 'reason' => $r['reason'] ?? 'otp_invalid']);
    }
    exit;
}

/* ---------- step 5/6: credit score + existing loans via Bank, compute initial offer ---------- */
if ($action === 'credit-check') {
    $ref = $_POST['reference_no'] ?? ''; $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $c = http_post(BANK_URL, 'credit-score', ['pan' => $pan]);
    $loans = http_post(BANK_URL, 'existing-loans', ['pan' => $pan]);
    if (!$c || empty($c['found'])) { echo json_encode(['found' => false, 'reason' => 'no_credit_history']); exit; }
    $score = (int)$c['score'];
    // initial offer by score band (PAN-driven)
    $initial = $score >= 800 ? 500000 : ($score >= 750 ? 400000 : ($score >= 700 ? 300000 : ($score >= 650 ? 150000 : 0)));
    // total existing EMI obligations (capability to repay)
    $exEmi = 0; foreach (($loans['loans'] ?? []) as $l) $exEmi += (float)($l['emi'] ?? 0);
    touch_app($pdo, $ref, ['pan' => $pan, 'credit_score' => $score, 'credit_band' => $c['band'],
        'credit_performance' => $c['performance'], 'initial_offer' => $initial, 'existing_emi' => $exEmi]);
    // Hard stop mid-journey: score at/below threshold or weak repayment history -> reject now.
    if ($score <= MIN_SCORE || $c['performance'] === 'Weak') {
        $reason = $score <= MIN_SCORE ? 'Low credit score (' . $score . ')' : 'Poor repayment history';
        $app = app_by_ref($pdo, $ref);
        reject_app($pdo, $ref, $app['mobile'] ?? '', $reason);
        echo json_encode(['found' => true, 'rejected' => true, 'reason' => $reason, 'score' => $score]); exit;
    }
    echo json_encode(['found' => true, 'score' => $score, 'band' => $c['band'],
        'performance' => $c['performance'], 'initial_offer' => $initial, 'existing_loans' => $loans['loans'] ?? []]);
    exit;
}

/* ---------- step 7: bank statement via Account Aggregator ---------- */
if ($action === 'aa-consent-send') {
    echo json_encode(http_post(AA_URL, 'consent-send', ['mobile' => preg_replace('/\D/', '', $_POST['mobile'] ?? '')])
        ?: ['status' => 'error', 'reason' => 'aa_unreachable']); exit;
}
if ($action === 'aa-consent-approve') {
    $ref = $_POST['reference_no'] ?? '';
    $r = http_post(AA_URL, 'consent-approve', [
        'mobile' => preg_replace('/\D/', '', $_POST['mobile'] ?? ''),
        'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]);
    if ($r && ($r['status'] ?? '') === 'approved') {
        // analyse the fetched statement (banking behaviour)
        $txns = $r['transactions'] ?? [];
        $hasSalary = false; $credits = 0; $minBal = PHP_INT_MAX;
        foreach ($txns as $t) {
            if (stripos($t['description'] ?? '', 'salary') !== false && ($t['dr_cr'] ?? '') === 'CR') $hasSalary = true;
            if (($t['dr_cr'] ?? '') === 'CR') $credits += (float)$t['amount'];
            if (stripos($t['description'] ?? '', 'return') !== false || stripos($t['description'] ?? '', 'bounce') !== false) $hasSalary = $hasSalary; // bounce handled below
            $minBal = min($minBal, (float)($t['balance_after'] ?? 0));
        }
        $bounced = false; foreach ($txns as $t) { if (stripos($t['description'] ?? '', 'return') !== false || stripos($t['description'] ?? '', 'bounce') !== false) $bounced = true; }
        $health = ($hasSalary && $minBal >= 0 && $credits > 0 && !$bounced) ? 'Good' : 'Poor';
        if ($ref) touch_app($pdo, $ref, ['bank_health' => $health, 'statement_verified' => 1]);
        $r['bank_health'] = $health;
        // Only journeys with a healthy statement proceed; a poor one is rejected here.
        if ($health === 'Poor' && $ref) {
            $app = app_by_ref($pdo, $ref);
            $reason = 'Irregular bank statement / weak inflows';
            reject_app($pdo, $ref, $app['mobile'] ?? '', $reason);
            $r['rejected'] = true; $r['reason'] = $reason;
        }
    }
    echo json_encode($r ?: ['status' => 'error', 'reason' => 'aa_unreachable']); exit;
}

if ($action === 'statement-received') {        // PDF upload path — unverified, manual review
    $ref = $_POST['reference_no'] ?? '';
    if ($ref) touch_app($pdo, $ref, ['bank_health' => 'Unverified', 'statement_verified' => 0]);
    echo json_encode(['status' => 'received']); exit;
}

/* ---------- step 8: list banks ---------- */
if ($action === 'banks') { echo json_encode(http_post(BANK_URL, 'banks', []) ?: ['banks' => []]); exit; }

/* ---------- step 8: the customer's OWN bank (one mobile -> one bank) ---------- */
if ($action === 'my-bank') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    if (!$app) { echo json_encode(['found' => false, 'reason' => 'not_found']); exit; }
    $r = http_post(BANK_URL, 'account-by-mobile', ['mobile' => preg_replace('/\D/', '', $app['mobile'] ?? '')]);
    if (!$r || empty($r['found'])) { echo json_encode(['found' => false, 'reason' => 'no_account']); exit; }
    echo json_encode(['found' => true, 'bank_code' => $r['bank_code'], 'bank_name' => $r['bank_name'],
        'account_no' => $r['account_no'], 'ifsc' => $r['ifsc']]); exit;
}

/* ---------- generic step save (address, industry, income, bank, beneficiary, tenure) ---------- */
if ($action === 'save-step') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    if (!$app) { echo json_encode(['saved' => false, 'reason' => 'not_found']); exit; }
    // Bank choice must match the customer's own linked bank — reject anything else (server-side).
    if (isset($_POST['bank_code']) && $_POST['bank_code'] !== '') {
        $mine = http_post(BANK_URL, 'account-by-mobile', ['mobile' => preg_replace('/\D/', '', $app['mobile'] ?? '')]);
        if (!$mine || empty($mine['found']) || strtoupper($_POST['bank_code']) !== strtoupper($mine['bank_code'])) {
            echo json_encode(['saved' => false, 'reason' => 'bank_mismatch']); exit;
        }
    }
    $allowed = ['full_name','father_name','mother_name','gender','dob','email',
                'address','industry','company_name','designation','monthly_income','requested_amount',
                'bank_code','beneficiary_account','beneficiary_ifsc','tenure_months'];
    $f = [];
    foreach ($allowed as $k) if (isset($_POST[$k]) && $_POST[$k] !== '') $f[$k] = $_POST[$k];
    if ($f) touch_app($pdo, $ref, $f);
    echo json_encode(['saved' => true]); exit;
}

/* ---------- step 9: final offer (lower than initial — bank strategy) ---------- */
if ($action === 'final-offer') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    if (!$app) { echo json_encode(['error' => 'not_found']); exit; }
    $initial = (float)$app['initial_offer'];
    $req = (float)$app['requested_amount'];
    $base = $req > 0 ? min($req, $initial) : $initial;
    $final = round($base * 0.85 / 1000) * 1000;   // 15% lower; bank retention strategy
    $tenure = (int)($app['tenure_months'] ?: 12);
    $emi = $tenure > 0 ? round(($final * (1 + 0.016 * $tenure)) / $tenure) : 0;
    touch_app($pdo, $ref, ['final_offer' => $final, 'emi' => $emi, 'tenure_months' => $tenure]);
    echo json_encode(['initial_offer' => $initial, 'final_offer' => $final, 'tenure_months' => $tenure, 'emi' => $emi]); exit;
}

/* ---------- step 13: e-mandate via Bank ---------- */
if ($action === 'emandate') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    $r = http_post(BANK_URL, 'emandate-register', [
        'account_no' => $_POST['account_no'] ?? ($app['beneficiary_account'] ?? ''),
        'amount' => $app['emi'] ?? 0, 'ref' => $ref]);
    echo json_encode($r ?: ['status' => 'error', 'reason' => 'bank_unreachable']); exit;
}

/* ---------- submit for review ---------- */
if ($action === 'submit') {
    $ref = $_POST['reference_no'] ?? '';
    $app = app_by_ref($pdo, $ref);
    if (!$app) { echo json_encode(['error' => 'not_found']); exit; }
    list($decision, $reason, $foir) = evaluate_app($app);
    touch_app($pdo, $ref, ['status' => $decision, 'decision_reason' => $reason, 'foir' => $foir]);
    $m = $app['mobile'];
    if ($decision === 'REJECTED') {
        notify_sms($m, "FinanceCorp: Your loan application $ref could not be approved. Reason: $reason. You may reapply later.");
    } else {
        notify_sms($m, "FinanceCorp: Your loan application $ref has been received and is under review. We'll update you shortly.");
    }
    echo json_encode(['status' => $decision, 'reference_no' => $ref, 'reason' => $reason]); exit;
}

if ($action === 'get-status') {
    $ref = trim($_POST['reference_no'] ?? '');
    $mob = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    if ($ref) { $s = $pdo->prepare("SELECT * FROM applications WHERE reference_no=?"); $s->execute([$ref]); }
    else { $s = $pdo->prepare("SELECT * FROM applications WHERE mobile=? ORDER BY id DESC LIMIT 1"); $s->execute([$mob]); }
    $a = $s->fetch();
    if (!$a) { echo json_encode(['found' => false]); exit; }
    echo json_encode(['found' => true, 'reference_no' => $a['reference_no'], 'full_name' => $a['full_name'],
        'status' => $a['status'], 'final_offer' => $a['final_offer'], 'reason' => $a['decision_reason']]);
    exit;
}

/* ---------- disbursal queue (read by the Disburse node) ---------- */
if ($action === 'disbursal-queue') {
    $rows = $pdo->query("SELECT reference_no, full_name, final_offer, bank_code, beneficiary_account, beneficiary_ifsc
                         FROM applications WHERE status='APPROVED' ORDER BY updated_at")->fetchAll();
    echo json_encode(['queue' => $rows]); exit;
}
if ($action === 'mark-disbursed') {
    $ref = $_POST['reference_no'] ?? '';
    touch_app($pdo, $ref, ['status' => 'DISBURSED']);
    $app = app_by_ref($pdo, $ref);
    if ($app) add_loan_from_app($pdo, $app);   // real loan enters the book
    echo json_encode(['status' => 'DISBURSED']); exit;
}

echo json_encode(['status' => 'ok', 'service' => 'los-orchestrator']);
