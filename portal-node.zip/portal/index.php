<?php
// Entry point — the split-screen phone-number login is the first screen.
header('Location: /login.php');
exit;
