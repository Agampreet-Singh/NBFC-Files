<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$ref = $_GET['ref'] ?? '';

// console actions: approve / reject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['act'])) {
    $act = $_POST['act'];
    if ($act === 'disburse') {
        $pdo->prepare("UPDATE applications SET status='DISBURSED', updated_at=datetime('now') WHERE reference_no=?")->execute([$ref]);
        $app = $pdo->prepare("SELECT * FROM applications WHERE reference_no=?"); $app->execute([$ref]); $row = $app->fetch();
        if ($row) add_loan_from_app($pdo, $row);   // enters the real loan book
    } else {
        $new = $act === 'approve' ? 'APPROVED' : ($act === 'reject' ? 'REJECTED' : null);
        if ($new) $pdo->prepare("UPDATE applications SET status=?, updated_at=datetime('now') WHERE reference_no=?")->execute([$new, $ref]);
    }
    header('Location: /application.php?ref=' . urlencode($ref)); exit;
}

$st = $pdo->prepare("SELECT * FROM applications WHERE reference_no=?"); $st->execute([$ref]); $a = $st->fetch();
shell_head('apps', 'Application');
if (!$a) { echo '<div class="panel">Application not found.</div>'; shell_foot(); exit; }
function chk($v){ return $v ? '<span class="ok">&#10003; Verified</span>' : '<span class="no">&#10007; Not verified</span>'; }
?>
<div class="detail-head">
  <div><h2><?= h($a['full_name']) ?> <span class="ref"><?= h($a['reference_no']) ?></span></h2>
  <?= badge($a['status']) ?></div>
  <?php if ($a['status']==='PENDING'): ?>
  <div class="actions">
    <form method="post"><button class="btn" name="act" value="approve">Approve</button></form>
    <form method="post"><button class="btn ghost" name="act" value="reject">Reject</button></form>
  </div>
  <?php elseif ($a['status']==='APPROVED'): ?>
  <div class="actions">
    <form method="post"><button class="btn" name="act" value="disburse">Mark Disbursed</button></form>
  </div>
  <?php endif; ?>
</div>

<div class="cols">
  <div class="panel">
    <h3>Verifications</h3>
    <div class="kv"><span>PAN (<?= h($a['pan']) ?>)</span><?= chk($a['pan_verified']) ?></div>
    <div class="kv"><span>Aadhaar KYC (xxxx<?= h($a['aadhaar_last4']) ?>)</span><?= chk($a['kyc_verified']) ?></div>
    <div class="kv"><span>Credit score</span><b><?= $a['credit_score'] ?: '-' ?> (<?= h($a['credit_band']) ?>)</b></div>
    <div class="kv"><span>Performance</span><b><?= h($a['credit_performance']) ?></b></div>
  </div>
  <div class="panel">
    <h3>Applicant</h3>
    <div class="kv"><span>Mobile</span><b><?= h($a['mobile']) ?></b></div>
    <div class="kv"><span>Industry</span><b><?= h($a['industry']) ?></b></div>
    <div class="kv"><span>Monthly income</span><b>&#8377;<?= number_format((float)$a['monthly_income']) ?></b></div>
    <div class="kv"><span>Address</span><b><?= h($a['address']) ?></b></div>
  </div>
  <div class="panel">
    <h3>Offer</h3>
    <div class="kv"><span>Requested</span><b>&#8377;<?= number_format((float)$a['requested_amount']) ?></b></div>
    <div class="kv"><span>Initial offer</span><b>&#8377;<?= number_format((float)$a['initial_offer']) ?></b></div>
    <div class="kv"><span>Final offer</span><b>&#8377;<?= $a['final_offer']!==null?number_format((float)$a['final_offer']):'-' ?></b></div>
    <div class="kv"><span>Tenure / EMI</span><b><?= (int)$a['tenure_months'] ?> mo / &#8377;<?= number_format((float)$a['emi']) ?></b></div>
  </div>
  <div class="panel">
    <h3>Disbursal account</h3>
    <div class="kv"><span>Bank</span><b><?= h($a['bank_code']) ?></b></div>
    <div class="kv"><span>Account</span><b><?= h($a['beneficiary_account']) ?></b></div>
    <div class="kv"><span>IFSC</span><b><?= h($a['beneficiary_ifsc']) ?></b></div>
  </div>
</div>
<?php shell_foot();
