<?php
session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/config.php';
require __DIR__ . '/layout.php';

$pdo = ndb();
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['submit_form'])) {                   // applicant details -> send OTP
        $mobile = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
        $name   = trim($_POST['full_name'] ?? '');
        $father = trim($_POST['father_name'] ?? '');
        $dob    = $_POST['dob'] ?? '';
        if (!$name || !$father || !$dob || strlen($mobile) < 10) {
            $err = 'Please fill all fields with a valid 10-digit mobile.';
        } else {
            $chk = $pdo->prepare("SELECT pan FROM pan_records WHERE mobile = ?");
            $chk->execute([$mobile]);
            if ($chk->fetch()) {
                $err = 'This mobile is already linked to a PAN. Please go Home and download your e-PAN.';
            } else {
                $r = tele_post('send', ['mobile' => $mobile, 'service' => OTP_SERVICE]);
                if ($r && ($r['status'] ?? '') === 'sent') {
                    $_SESSION['apply'] = ['mobile' => $mobile, 'full_name' => $name, 'father_name' => $father, 'dob' => $dob];
                    $_SESSION['apply_stage'] = 'otp';
                    header('Location: /apply.php'); exit;
                }
                $err = 'Could not reach the OTP service. Check the Telecom node.';
            }
        }
    }

    if (isset($_POST['verify'])) {                         // verify OTP -> issue PAN
        $a = $_SESSION['apply'] ?? [];
        $o = preg_replace('/\D/', '', $_POST['otp'] ?? '');
        $r = tele_post('verify', ['mobile' => $a['mobile'] ?? '', 'otp' => $o]);
        if ($r && !empty($r['valid'])) {
            // issue a new PAN
            do { $pan = gen_pan(); $e = $pdo->prepare("SELECT 1 FROM pan_records WHERE pan=?"); $e->execute([$pan]); } while ($e->fetch());
            $pdo->prepare("INSERT INTO pan_records(pan, full_name, father_name, dob, mobile, status) VALUES(?,?,?,?,?, 'VALID')")
                ->execute([$pan, $a['full_name'], $a['father_name'], $a['dob'], $a['mobile']]);
            $ack = 'ACK' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
            $pdo->prepare("INSERT INTO pan_applications(ack_no, pan, full_name, father_name, dob, mobile) VALUES(?,?,?,?,?,?)")
                ->execute([$ack, $pan, $a['full_name'], $a['father_name'], $a['dob'], $a['mobile']]);
            $_SESSION['pan_verified_mobile'] = $a['mobile'];
            unset($_SESSION['apply'], $_SESSION['apply_stage']);
            $_SESSION['apply_done'] = ['ack' => $ack, 'pan' => $pan];
            header('Location: /apply.php'); exit;
        }
        $err = 'Invalid or expired OTP.';
    }
}

$stage = $_SESSION['apply_stage'] ?? 'form';
$done  = $_SESSION['apply_done'] ?? null;
$pref  = preg_replace('/\D/', '', $_GET['mobile'] ?? '');

nhead('Apply for PAN');
?>
<div class="gov-card">
  <?php if ($err) echo '<p class="gov-err">' . nh($err) . '</p>'; ?>

  <?php if ($done): unset($_SESSION['apply_done']); ?>
    <h3>Application successful</h3>
    <p class="gov-note">Your PAN has been issued and linked to your mobile number.</p>
    <div class="gov-kv"><span>Acknowledgement No.</span><b><?= nh($done['ack']) ?></b></div>
    <div class="gov-kv"><span>Permanent Account Number</span><b><?= nh($done['pan']) ?></b></div>
    <a class="gov-btn" href="/epan.php">Download e-PAN</a>

  <?php elseif ($stage === 'otp'): ?>
    <h3>Verify OTP</h3>
    <p class="gov-note">OTP sent to <b><?= nh($_SESSION['apply']['mobile'] ?? '') ?></b>. Check your Messages.</p>
    <form method="post">
      <label>Enter OTP<input name="otp" inputmode="numeric" pattern="[0-9]{6}" required autofocus></label>
      <button class="gov-btn" name="verify" value="1" type="submit">Verify &amp; Issue PAN</button>
    </form>

  <?php else: ?>
    <h3>Apply for a new PAN</h3>
    <p class="gov-note">Your mobile number is not linked to any PAN. Fill the form to apply.</p>
    <form method="post">
      <label>Full name<input name="full_name" required></label>
      <label>Father's name<input name="father_name" required></label>
      <label>Date of birth<input type="date" name="dob" required></label>
      <label>Mobile number<input name="mobile" pattern="[0-9]{10}" value="<?= nh($pref) ?>" required></label>
      <button class="gov-btn" name="submit_form" value="1" type="submit">Submit &amp; Get OTP</button>
    </form>
  <?php endif; ?>
</div>
<?php nfoot();
