<?php
require __DIR__ . '/lib.php';
require_login();
$m = $_GET['m'] ?? 'Module';
// map module name to active nav key
$map = ['Collections'=>'collections','Promise-to-Pay'=>'ptp','NACH / Mandates'=>'nach','Compliance'=>'compliance',
        'Products'=>'products','Branches'=>'branches','Groups'=>'groups','Charges & Fees'=>'charges',
        'Lending Settings'=>'settings','Reports'=>'reports'];
$active = $map[$m] ?? '';
shell_head($active, $m);
?>
<div class="panel" style="text-align:center;padding:60px 20px">
  <div style="font-size:40px">&#128296;</div>
  <h2><?= h($m) ?></h2>
  <p class="muted">This module is part of the Lending OS Stack. Configuration for this lab environment is pending.</p>
</div>
<?php shell_foot();
