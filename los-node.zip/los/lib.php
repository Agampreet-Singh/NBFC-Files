<?php
// lib.php — auth, professional product shell, and hand-rolled SVG chart helpers.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function require_login() {
    if (session_status() === PHP_SESSION_NONE) session_start();
    if (empty($_SESSION['los_user'])) { header('Location: /login.php'); exit; }
}

function badge($status) {
    $m = ['DRAFT'=>'draft','PENDING'=>'pending','APPROVED'=>'approved','DISBURSED'=>'disbursed','REJECTED'=>'rejected',
          'ACTIVE'=>'disbursed','OVERDUE'=>'pending','NPA'=>'rejected','Current'=>'disbursed','SMA'=>'pending'];
    $c = $m[$status] ?? 'draft';
    return '<span class="badge ' . $c . '">' . h($status) . '</span>';
}

function inr($n) { $n=(float)$n; if($n>=1e7) return '&#8377;'.rtrim(rtrim(number_format($n/1e7,2),'0'),'.').'Cr';
    if($n>=1e5) return '&#8377;'.rtrim(rtrim(number_format($n/1e5,2),'0'),'.').'L'; return '&#8377;'.number_format($n); }

/* ---- sidebar + topbar shell ---- */
function shell_head($active, $title = 'Dashboard') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp LOS</title><link rel="stylesheet" href="/assets/style.css"></head><body><div class="app">';
    $groups = [
        'CORE' => [
            'dashboard'=>['/index.php','&#9638;','Dashboard'],
            'borrowers'=>['/borrowers.php','&#128100;','Borrowers'],
            'apps'=>['/applications.php','&#128196;','Applications'],
            'portfolio'=>['/portfolio.php','&#127970;','Loan Portfolio'],
            'disbursal'=>['/disbursal.php','&#8599;','Disbursal Queue'],
            'emi'=>['/emi.php','&#128202;','EMI Calculator'],
        ],
        'INSIGHTS' => [
            'services'=>['/services.php','&#128268;','Services'],
            'audit'=>['/audit.php','&#128220;','Audit Trail'],
        ],
    ];
    echo '<aside class="side"><div class="logo"><span class="mark">LOS</span><div><b>FinanceCorp</b><small>Lending OS Stack</small></div></div><nav>';
    foreach ($groups as $g => $items) {
        echo '<div class="grp">' . h($g) . '</div>';
        foreach ($items as $k => $v) {
            $cls = $k === $active ? 'on' : '';
            echo '<a class="' . $cls . '" href="' . $v[0] . '"><span class="ic">' . $v[1] . '</span>' . $v[2] . '</a>';
        }
    }
    echo '</nav></aside>';
    echo '<div class="main"><header class="top"><div class="crumb"><b>' . h($title) . '</b></div>';
    echo '<div class="topr"><div class="search">Search&hellip;</div><div class="avatar">' . strtoupper(substr($_SESSION['los_user'] ?? 'U',0,1)) . '</div>';
    echo '<div class="whobox"><b>' . h($_SESSION['los_user'] ?? '') . '</b><small><a href="/login.php?logout=1">Logout</a></small></div></div></header><div class="content">';
}
function shell_foot() { echo '</div></div></div></body></html>'; }

/* ---- SVG charts (no external libs) ---- */
function donut($segments, $size = 170) {
    $total = array_sum(array_map(fn($s)=>$s[1], $segments)) ?: 1;
    $cx=$size/2; $cy=$size/2; $r=$size*0.38; $sw=$size*0.16; $circ=2*M_PI*$r; $off=0;
    $out = '<svg viewBox="0 0 '.$size.' '.$size.'" width="'.$size.'" height="'.$size.'">';
    $out .= '<circle cx="'.$cx.'" cy="'.$cy.'" r="'.$r.'" fill="none" stroke="#eef1f6" stroke-width="'.$sw.'"/>';
    foreach ($segments as $s) {
        $len = $circ * ($s[1]/$total);
        $out .= '<circle cx="'.$cx.'" cy="'.$cy.'" r="'.$r.'" fill="none" stroke="'.$s[2].'" stroke-width="'.$sw.'" stroke-dasharray="'.$len.' '.($circ-$len).'" stroke-dashoffset="'.(-$off).'" transform="rotate(-90 '.$cx.' '.$cy.')"/>';
        $off += $len;
    }
    $out .= '</svg>';
    return $out;
}
function linechart($vals, $w = 440, $h = 150) {
    $max = max($vals) ?: 1; $n = count($vals); $pad = 24;
    $iw = $w - $pad*2; $ih = $h - $pad;
    $pts = [];
    foreach ($vals as $i=>$v) { $x = $pad + ($n>1?$iw*$i/($n-1):0); $y = $pad + $ih*(1 - $v/$max); $pts[] = [$x,$y]; }
    $poly = implode(' ', array_map(fn($p)=>round($p[0],1).','.round($p[1],1), $pts));
    $area = $poly . ' ' . round($pad+$iw,1).','.round($pad+$ih,1) . ' ' . round($pad,1).','.round($pad+$ih,1);
    $out = '<svg viewBox="0 0 '.$w.' '.$h.'" width="100%" height="'.$h.'">';
    $out .= '<polygon points="'.$area.'" fill="rgba(99,102,241,.12)"/>';
    $out .= '<polyline points="'.$poly.'" fill="none" stroke="#6366f1" stroke-width="2.5"/>';
    foreach ($pts as $p) $out .= '<circle cx="'.round($p[0],1).'" cy="'.round($p[1],1).'" r="3" fill="#4338ca"/>';
    $out .= '</svg>';
    return $out;
}
function barpairs($labels, $a, $b, $w = 440, $h = 160) {
    $max = max(max($a), max($b)) ?: 1; $n = count($labels); $pad = 20;
    $iw = $w - $pad*2; $ih = $h - $pad*2; $slot = $iw/$n; $bw = $slot*0.3;
    $out = '<svg viewBox="0 0 '.$w.' '.$h.'" width="100%" height="'.$h.'">';
    foreach ($labels as $i=>$l) {
        $x = $pad + $slot*$i + $slot/2;
        $ha = $ih*$a[$i]/$max; $hb = $ih*$b[$i]/$max;
        $out .= '<rect x="'.round($x-$bw-1,1).'" y="'.round($pad+$ih-$ha,1).'" width="'.round($bw,1).'" height="'.round($ha,1).'" rx="2" fill="#c7d2fe"/>';
        $out .= '<rect x="'.round($x+1,1).'" y="'.round($pad+$ih-$hb,1).'" width="'.round($bw,1).'" height="'.round($hb,1).'" rx="2" fill="#16a34a"/>';
        $out .= '<text x="'.round($x,1).'" y="'.($h-6).'" text-anchor="middle" font-size="10" fill="#6b7793">'.h($l).'</text>';
    }
    $out .= '</svg>';
    return $out;
}
