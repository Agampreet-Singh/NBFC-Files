<?php
require __DIR__ . '/lib.php';
require_login();
shell_head('emi', 'EMI Calculator');
?>
<div class="panel" style="max-width:560px">
  <div class="panel-h"><h2>EMI Calculator</h2></div>
  <label>Loan amount (&#8377;)<input id="amt" type="number" value="300000"></label>
  <label>Interest rate (% p.a.)<input id="rate" type="number" value="19" step="0.1"></label>
  <label>Tenure (months)<input id="ten" type="number" value="24"></label>
  <div class="emi-out">
    <div><small>Monthly EMI</small><b id="emi">&#8377;0</b></div>
    <div><small>Total interest</small><b id="int">&#8377;0</b></div>
    <div><small>Total payable</small><b id="tot">&#8377;0</b></div>
  </div>
</div>
<style>
label{display:block;font-size:14px;margin-bottom:14px}label input{width:100%;margin-top:6px;padding:10px;border:1px solid var(--line);border-radius:9px}
.emi-out{display:flex;gap:16px;margin-top:10px}.emi-out div{flex:1;background:#f4f6fb;border-radius:10px;padding:14px}
.emi-out small{color:var(--muted);font-size:12px}.emi-out b{display:block;font-size:20px;margin-top:4px}
</style>
<script>
function calc(){
  const P=+document.getElementById('amt').value||0, R=(+document.getElementById('rate').value||0)/1200, N=+document.getElementById('ten').value||1;
  const emi = R>0 ? P*R*Math.pow(1+R,N)/(Math.pow(1+R,N)-1) : P/N;
  const tot = emi*N, intr = tot-P;
  const f=x=>'₹'+Math.round(x).toLocaleString('en-IN');
  document.getElementById('emi').textContent=f(emi);
  document.getElementById('int').textContent=f(intr);
  document.getElementById('tot').textContent=f(tot);
}
['amt','rate','ten'].forEach(id=>document.getElementById(id).addEventListener('input',calc)); calc();
</script>
<?php shell_foot();
