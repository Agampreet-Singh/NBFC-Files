<?php
// Bank Server API. Called by LOS / Account Aggregator / Disburse node (server-to-server).
//   ?action=banks            GET                              -> list of banks (choose bank)
//   ?action=credit-score     POST pan                         -> credit score + performance
//   ?action=existing-loans   POST pan                         -> existing loans
//   ?action=statement        POST account_no | pan           -> account + transactions (AA fetch)
//   ?action=account-verify   POST account_no, ifsc           -> penny-drop name match
//   ?action=emandate-register POST account_no, amount, ref   -> register e-mandate
//   ?action=payout           POST beneficiary_account, ifsc, amount, reference -> credit account
// LAB / isolated range only.

require __DIR__ . '/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';
$pdo = bdb();

function acct_by_no($pdo, $no) {
    $st = $pdo->prepare("SELECT * FROM accounts WHERE account_no = ?");
    $st->execute([$no]);
    return $st->fetch();
}

if ($action === 'banks') {
    echo json_encode(['banks' => $pdo->query("SELECT code, name FROM banks ORDER BY name")->fetchAll()]);
    exit;
}

if ($action === 'account-by-mobile') {         // which bank does this mobile belong to
    $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    $st = $pdo->prepare("SELECT a.account_no, a.ifsc, a.bank_code, a.holder_name, a.pan, b.name AS bank_name
                         FROM accounts a LEFT JOIN banks b ON a.bank_code = b.code
                         WHERE a.mobile = ? LIMIT 1");
    $st->execute([$m]);
    $row = $st->fetch();
    echo json_encode($row ? ['found' => true] + $row : ['found' => false, 'reason' => 'no_account_for_mobile']);
    exit;
}

if ($action === 'credit-score') {
    $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $st = $pdo->prepare("SELECT pan, score, band, performance, remarks FROM credit_profiles WHERE pan = ?");
    $st->execute([$pan]);
    $row = $st->fetch();
    echo json_encode($row ? ['found' => true] + $row
        : ['found' => false, 'score' => null, 'reason' => 'no_credit_history']);
    exit;
}

if ($action === 'existing-loans') {
    $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $st = $pdo->prepare("SELECT lender, product, outstanding, emi, status FROM existing_loans WHERE pan = ?");
    $st->execute([$pan]);
    echo json_encode(['loans' => $st->fetchAll()]);
    exit;
}

if ($action === 'statement') {
    $no  = trim($_POST['account_no'] ?? '');
    $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $mob = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    if (!$no && $pan) {
        $s = $pdo->prepare("SELECT account_no FROM accounts WHERE pan = ? LIMIT 1");
        $s->execute([$pan]); $r = $s->fetch(); $no = $r['account_no'] ?? '';
    }
    if (!$no && $mob) {
        $s = $pdo->prepare("SELECT account_no FROM accounts WHERE mobile = ? LIMIT 1");
        $s->execute([$mob]); $r = $s->fetch(); $no = $r['account_no'] ?? '';
    }
    $acc = $no ? acct_by_no($pdo, $no) : null;
    if (!$acc) { echo json_encode(['found' => false, 'reason' => 'account_not_found']); exit; }
    $t = $pdo->prepare("SELECT txn_date, description, amount, dr_cr, balance_after FROM transactions WHERE account_no = ? ORDER BY id");
    $t->execute([$no]);
    echo json_encode([
        'found' => true,
        'account' => ['account_no' => $acc['account_no'], 'ifsc' => $acc['ifsc'],
                      'holder_name' => $acc['holder_name'], 'balance' => $acc['balance']],
        'transactions' => $t->fetchAll(),
    ]);
    exit;
}

if ($action === 'account-verify') {           // penny-drop / name match
    $no   = trim($_POST['account_no'] ?? '');
    $ifsc = strtoupper(trim($_POST['ifsc'] ?? ''));
    $acc  = acct_by_no($pdo, $no);
    if ($acc && $acc['ifsc'] === $ifsc) {
        echo json_encode(['valid' => true, 'holder_name' => $acc['holder_name']]);
    } else {
        echo json_encode(['valid' => false, 'reason' => 'account_not_found']);
    }
    exit;
}

if ($action === 'emandate-register') {
    $no  = trim($_POST['account_no'] ?? '');
    $amt = (float)($_POST['amount'] ?? 0);
    $ref = trim($_POST['ref'] ?? '');
    $acc = acct_by_no($pdo, $no);
    if (!$acc) { echo json_encode(['status' => 'error', 'reason' => 'account_not_found']); exit; }
    $mref = 'MNDT' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    $pdo->prepare("INSERT INTO mandates(mandate_ref, account_no, amount, status) VALUES(?,?,?, 'ACTIVE')")
        ->execute([$mref, $no, $amt]);
    echo json_encode(['status' => 'registered', 'mandate_ref' => $mref]);
    exit;
}

if ($action === 'payout') {
    // NOTE: this endpoint trusts any caller that can reach it (IP allow-listing is the
    // only gate, enforced at the network layer). No maker-checker, no fresh beneficiary
    // check. This architectural trust is the scenario's core weakness. LAB target.
    $no   = trim($_POST['beneficiary_account'] ?? '');
    $ifsc = strtoupper(trim($_POST['ifsc'] ?? ''));
    $amt  = (float)($_POST['amount'] ?? 0);
    $ref  = trim($_POST['reference'] ?? '');
    $ip   = $_SERVER['REMOTE_ADDR'] ?? '';
    $acc  = acct_by_no($pdo, $no);
    if (!$acc || $amt <= 0) {
        $pdo->prepare("INSERT INTO payouts(utr, source_ip, beneficiary_account, ifsc, amount, reference, status) VALUES(?,?,?,?,?,?, 'FAILED')")
            ->execute(['', $ip, $no, $ifsc, $amt, $ref]);
        echo json_encode(['status' => 'failed', 'reason' => 'invalid_beneficiary_or_amount']); exit;
    }
    $utr = 'UTR' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
    $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE account_no = ?")->execute([$amt, $no]);
    $newbal = acct_by_no($pdo, $no)['balance'];
    $pdo->prepare("INSERT INTO transactions(account_no, txn_date, description, amount, dr_cr, balance_after) VALUES(?,?,?,?, 'CR', ?)")
        ->execute([$no, date('Y-m-d'), 'NEFT/IMPS Credit - ' . ($ref ?: 'DISBURSAL'), $amt, $newbal]);
    $pdo->prepare("INSERT INTO payouts(utr, source_ip, beneficiary_account, ifsc, amount, reference, status) VALUES(?,?,?,?,?,?, 'SUCCESS')")
        ->execute([$utr, $ip, $no, $ifsc, $amt, $ref]);
    echo json_encode(['status' => 'success', 'utr' => $utr, 'credited_to' => $acc['holder_name']]);
    exit;
}

echo json_encode(['status' => 'ok', 'service' => 'bank-core-server']);
