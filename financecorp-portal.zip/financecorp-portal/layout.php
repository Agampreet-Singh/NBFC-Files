<?php
// layout.php — shared header/footer for a realistic (fictional) NBFC look.

function render_head($title = 'FinanceCorp') {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . htmlspecialchars($title) . ' — FinanceCorp</title>';
    echo '<link rel="stylesheet" href="/assets/style.css"></head><body>';
    echo '<header class="nav"><div class="wrap">';
    echo '<a class="brand" href="/index.php"><span class="logo">F</span>FinanceCorp</a>';
    echo '<nav><a href="/apply.php?step=1">Apply for Loan</a><a href="/status.php">Track Application</a></nav>';
    echo '</div></header><main class="wrap">';
}

function render_foot() {
    echo '</main><footer class="foot"><div class="wrap">';
    echo 'FinanceCorp Capital Pvt Ltd &middot; CIN: U65XXXXXX &middot; RBI-registered NBFC (fictional). ';
    echo '<strong>Training environment — not a real financial institution.</strong>';
    echo '</div></footer></body></html>';
}

function stepper($active) {
    $labels = [1 => 'Personal Details', 2 => 'Banking &amp; KYC', 3 => 'Repayment &amp; e-Sign'];
    echo '<ol class="stepper">';
    foreach ($labels as $n => $l) {
        $cls = $n < $active ? 'done' : ($n == $active ? 'active' : '');
        echo '<li class="' . $cls . '"><span class="dot">' . $n . '</span>' . $l . '</li>';
    }
    echo '</ol>';
}

function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }
