<?php
require_once __DIR__ . '/config.php';

function step_labels() {
    return [1=>'Mobile',2=>'PAN',3=>'Address',4=>'Industry',5=>'Credit',6=>'Offer',
            7=>'Statement',8=>'Bank',9=>'Final Offer',10=>'KYC',11=>'Selfie',12=>'Work',13=>'e-Mandate'];
}

function render_stepper($step) {
    $labels = step_labels();
    echo '<div class="stepper"><div class="stepper-track">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
        $mark = $n < $step ? '&#10003;' : $n;
        echo '<div class="stp ' . $cls . '"><span class="node">' . $mark . '</span><em>' . h($l) . '</em></div>';
        if ($n < count($labels)) echo '<span class="seg ' . ($n < $step ? 'done' : '') . '"></span>';
    }
    echo '</div></div>';
}

/* ===== Professional (text-based) progress indicator — no circles/ticks ===== */
function render_steps_pro($step) {
    $labels = step_labels();
    $total  = count($labels);
    $pct    = $total > 1 ? max(0, min(100, round((($step - 1) / ($total - 1)) * 100))) : 0;
    echo '<div class="prog"><div class="prog-row">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'curr' : 'todo');
        echo '<span class="pstep ' . $cls . '">' . h($l) . '</span>';
        if ($n < $total) echo '<span class="psep">&rsaquo;</span>';
    }
    echo '</div><div class="prog-bar"><span style="width:' . $pct . '%"></span></div>';
    echo '<div class="prog-count">Step ' . (int)$step . ' of ' . $total . '</div></div>';
}

/* ===== Post-login app shell (full-screen, header + welcome) ===== */
function app_doc_open($title) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body class="app">';
}
function app_topbar($name = '', $toast = true) {
    echo '<header class="appbar"><div class="ab-in">';
    echo '<div class="ab-logo"><span class="logo">F</span><span class="ab-name">FinanceCorp</span></div>';
    echo '<div class="ab-right">';
    if ($name !== '') echo '<span class="ab-welcome">Welcome <b>' . h($name) . '</b></span>';
    echo '<a class="ab-logout" href="/logout.php">&#8614; Logout</a></div>';
    echo '</div></header>';
    if ($toast) echo '<div class="toast"><span class="toast-ic">&#10003;</span> Welcome to FinanceCorp</div>';
}
function ahead($title = '', $step = 0, $name = '') {
    app_doc_open($title);
    app_topbar($name, $step === 0 || $step === 2);   // welcome toast on first entry only
    echo '<main class="appmain"><div class="wrap">';
    if ($step > 0) { echo '<div class="prog-card">'; render_steps_pro($step); echo '</div>'; }
    echo '<div class="appcard">';
}
function afoot() { echo '</div></div></main></body></html>'; }

/* ===== Pre-login split-screen shell (login / OTP) ===== */
function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body>';
    echo '<div class="split">';
    // LEFT brand panel
    echo '<aside class="brandpanel"><div class="bp-in">';
    echo '<div class="bp-logo"><span class="logo">F</span><div class="bp-name"><b>FinanceCorp</b><small>Instant Personal Loan</small></div></div>';
    echo '<h1>Quick, easy loans up to <span class="hl">&#8377;5,00,000</span></h1>';
    echo '<ul class="bp-ticks"><li>Easy personal loan for all purposes</li><li>Collateral-free loans</li><li>Seamless login process</li><li>Simple repayment</li></ul>';
    echo '<div class="bp-cards"><div class="bp-card">&#9201; Calculate your EMI within minutes</div><div class="bp-card">&#128176; Low interest rates &amp; minimal fees</div><div class="bp-card">&#128241; 24x7 access to the loan app</div></div>';
    echo '</div></aside>';
    // RIGHT content pane
    echo '<section class="pane"><div class="pane-scroll">';
    if ($step > 0) render_stepper($step);
    echo '<div class="pane-inner">';
}

function pfoot() { echo '</div></div></section></div></body></html>'; }

/** SVG illustration for the status modal (folder + face + badge). */
function status_illustration($type) {
    $badge = $type === 'reject' ? '#dc2626' : '#d97706';
    $mark  = $type === 'reject'
        ? '<path d="M93 42l14 14M107 42l-14 14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>'
        : '<path d="M100 40v11M100 57v.5" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>';
    return '<svg viewBox="0 0 200 150" width="186" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<ellipse cx="100" cy="128" rx="78" ry="9" fill="#e8efea"/>'
        . '<rect x="104" y="30" width="46" height="58" rx="5" fill="#eef3f0"/>'
        . '<rect x="112" y="42" width="30" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="52" width="24" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="62" width="28" height="4" rx="2" fill="#d7e3dc"/>'
        . '<path d="M44 108V70a8 8 0 018-8h26l9 10h40a8 8 0 018 8v28a8 8 0 01-8 8H52a8 8 0 01-8-8z" fill="#06402b"/>'
        . '<path d="M60 86l10 10M70 86l-10 10M60 110l10 10M70 110l-10 10" stroke="#06402b" stroke-width="0" />'
        . '<text x="74" y="92" font-family="monospace" font-size="15" fill="#bfe8d4" font-weight="700">&gt;&lt;</text>'
        . '<path d="M72 104q8 -6 16 0" stroke="#bfe8d4" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
        . '<circle cx="100" cy="49" r="16" fill="#fff"/><circle cx="100" cy="49" r="13" fill="' . $badge . '"/>' . $mark
        . '</svg>';
}

/** Full-page modal result (reject / already-applied), styled over the app shell. Ends the request. */
function result_screen($type, $title, $reason = '', $sub = '', $showStatus = true) {
    $name = $_SESSION['pan_name'] ?? '';
    app_doc_open('Application Status');
    app_topbar($name);
    echo '<main class="appmain dimmed"><div class="wrap"><div class="appcard ghostcard"></div></div></main>';
    echo '<div class="backdrop"><div class="modal ' . ($type === 'reject' ? 'is-reject' : 'is-info') . '">';
    echo '<div class="modal-ill">' . status_illustration($type) . '</div>';
    echo '<h2 class="modal-title">' . h($title) . '</h2>';
    if ($reason !== '') echo '<p class="modal-text">' . h($reason) . '</p>';
    if ($sub !== '')    echo '<p class="modal-text sub">' . h($sub) . '</p>';
    echo '<div class="modal-actions">';
    if ($showStatus) echo '<a class="btn ghost" href="/status.php">Check status</a>';
    echo '<a class="btn" href="/login.php">Ok</a>';
    echo '</div></div></div></body></html>';
    exit;
}
function card_open($h){ echo '<h2 class="appcard-h">' . h($h) . '</h2>'; }
function card_close(){}
