<?php header('Content-Type: text/html'); ?><!DOCTYPE html>
<html><head><meta charset="utf-8"><title>NSDL PAN Verification</title>
<style>body{font-family:system-ui,Arial,sans-serif;background:#0b1220;color:#e2e8f0;display:grid;place-items:center;height:100vh;margin:0}
.box{background:#111a2e;border:1px solid #1e2a44;border-radius:14px;padding:30px 40px;text-align:center}
.dot{color:#22c55e}code{background:#0b1220;padding:2px 6px;border-radius:6px;color:#93c5fd}</style></head>
<body><div class="box"><h2><span class="dot">&#9679;</span> NSDL PAN Verification</h2>
<p>Service is running.</p>
<p style="color:#94a3b8;font-size:14px">Endpoint:<br><code>/api.php?action=verify</code> (POST pan)</p>
<p style="color:#64748b;font-size:12px">Lab / isolated range only.</p></div></body></html>
