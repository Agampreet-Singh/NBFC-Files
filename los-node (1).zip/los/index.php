<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();

// portfolio aggregates
$g = $pdo->query("SELECT
    COUNT(*) loans, COALESCE(SUM(principal),0) disbursed, COALESCE(SUM(collected),0) collected,
    COALESCE(SUM(outstanding),0) aum,
    COALESCE(SUM(CASE WHEN classification='NPA' THEN outstanding END),0) npa,
    COALESCE(SUM(CASE WHEN classification='Current' THEN outstanding END),0) cur,
    COALESCE(SUM(CASE WHEN classification='SMA' THEN outstanding END),0) sma,
    SUM(CASE WHEN status='ACTIVE' THEN 1 ELSE 0 END) active,
    SUM(CASE WHEN dpd>0 THEN 1 ELSE 0 END) overdue,
    COALESCE(SUM(CASE WHEN dpd>30 THEN outstanding END),0) par30,
    COALESCE(SUM(CASE WHEN dpd>60 THEN outstanding END),0) par60,
    COALESCE(SUM(CASE WHEN dpd>90 THEN outstanding END),0) par90
    FROM loans")->fetch();

$borrowers = (int)$pdo->query("SELECT COUNT(DISTINCT borrower) c FROM loans")->fetch()['c'];
$appTotal = (int)$pdo->query("SELECT COUNT(*) c FROM applications")->fetch()['c'] + (int)$g['loans'];
$pipeDraft = (int)$pdo->query("SELECT COUNT(*) c FROM applications WHERE status IN('DRAFT')")->fetch()['c'];
$pipeReview = (int)$pdo->query("SELECT COUNT(*) c FROM applications WHERE status IN('PENDING')")->fetch()['c'];

$npaRate = $g['aum'] > 0 ? $g['npa']/$g['aum']*100 : 0;
$eff = $g['disbursed'] > 0 ? $g['collected']/$g['disbursed']*100 : 0;
$par30p = $g['aum']>0 ? $g['par30']/$g['aum']*100 : 0;
$par60p = $g['aum']>0 ? $g['par60']/$g['aum']*100 : 0;
$par90p = $g['aum']>0 ? $g['par90']/$g['aum']*100 : 0;

// monthly disbursement (last 7 months)
$months = []; $disbByMon = [];
for ($i=6; $i>=0; $i--) { $m = date('Y-m', strtotime("-$i months", strtotime('2026-11-28'))); $months[] = date('M', strtotime($m.'-01')); $disbByMon[$m] = 0; }
foreach ($pdo->query("SELECT substr(disbursed_on,1,7) m, SUM(principal) s FROM loans GROUP BY m") as $r) {
    if (isset($disbByMon[$r['m']])) $disbByMon[$r['m']] = (float)$r['s'];
}
$disbSeries = array_map(fn($v)=>round($v/100000,1), array_values($disbByMon)); // in Lakhs
// collection vs demand — REAL: demand = EMI due from the book, collected = recorded repayments
$monthKeys = array_keys($disbByMon);
$demand = []; $collect = [];
$dStmt = $pdo->prepare("SELECT COALESCE(SUM(emi),0) s FROM loans WHERE substr(disbursed_on,1,7) <= ? AND status<>'CLOSED'");
$cStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) s FROM collections WHERE substr(paid_on,1,7) = ?");
foreach ($monthKeys as $mk) {
    $dStmt->execute([$mk]); $demand[]  = round(((float)$dStmt->fetch()['s'])/100000, 1);
    $cStmt->execute([$mk]); $collect[] = round(((float)$cStmt->fetch()['s'])/100000, 1);
}

shell_head('dashboard', 'Lending');
?>
<?php if ($npaRate > 5): ?>
<div class="alert">&#9888; NPA rate is <?= number_format($npaRate,2) ?>% — above 5% threshold. Immediate review required.</div>
<?php endif; ?>

<div class="kpis4">
  <div class="kpi"><span class="ic k1">&#8377;</span><div><small>Total Portfolio (AUM)</small><b><?= inr($g['aum']) ?></b><i>Outstanding principal</i></div></div>
  <div class="kpi"><span class="ic k2">&#8595;</span><div><small>Total Disbursed</small><b><?= inr($g['disbursed']) ?></b><i>All-time disbursals</i></div></div>
  <div class="kpi"><span class="ic k3">&#8599;</span><div><small>Total Collected</small><b><?= inr($g['collected']) ?></b><i><?= number_format($eff,2) ?>% efficiency</i></div></div>
  <div class="kpi danger"><span class="ic k4">&#9888;</span><div><small>NPA Outstanding</small><b><?= inr($g['npa']) ?></b><i class="red"><?= number_format($npaRate,2) ?>% NPA rate</i></div></div>
</div>

<div class="kpis4">
  <div class="kpi mini"><span class="ic k5">&#128100;</span><div><small>Total Borrowers</small><b><?= $borrowers ?></b></div></div>
  <div class="kpi mini"><span class="ic k6">&#9201;</span><div><small>Active Loans</small><b><?= (int)$g['active'] ?></b></div></div>
  <div class="kpi mini"><span class="ic k7">&#8681;</span><div><small>Overdue Loans</small><b><?= (int)$g['overdue'] ?></b></div></div>
  <div class="kpi mini"><span class="ic k8">&#128196;</span><div><small>Applications</small><b><?= $appTotal ?></b></div></div>
</div>

<div class="row3">
  <div class="panel">
    <div class="panel-h"><h2>Portfolio at Risk (PAR)</h2><span class="muted">vs. Outstanding</span></div>
    <?php
    $pars = [['PAR-30',$par30p,$g['par30'],'#f59e0b'],['PAR-60',$par60p,$g['par60'],'#f97316'],['PAR-90',$par90p,$g['par90'],'#ef4444'],['NPA',$npaRate,$g['npa'],'#dc2626']];
    foreach ($pars as $p): ?>
      <div class="par"><div class="par-top"><span><?= $p[0] ?></span><span><b><?= number_format($p[1],2) ?>%</b> <?= inr($p[2]) ?></span></div>
      <div class="bar"><i style="width:<?= min(100,$p[1]) ?>%;background:<?= $p[3] ?>"></i></div></div>
    <?php endforeach; ?>
    <p class="muted sm">Industry benchmark: PAR-30 &lt; 5% | NPA &lt; 2%</p>
  </div>

  <div class="panel center-panel">
    <div class="panel-h"><h2>Portfolio Mix by Classification</h2></div>
    <?= donut([['Current',$g['cur'],'#16a34a'],['SMA',$g['sma'],'#f59e0b'],['NPA',$g['npa'],'#ef4444']]) ?>
    <div class="legend">
      <span><i style="background:#16a34a"></i>Current <?= inr($g['cur']) ?></span>
      <span><i style="background:#f59e0b"></i>SMA <?= inr($g['sma']) ?></span>
      <span><i style="background:#ef4444"></i>NPA <?= inr($g['npa']) ?></span>
    </div>
  </div>

  <div class="panel">
    <div class="panel-h"><h2>Application Pipeline</h2></div>
    <div class="pipe"><span>Disbursed</span><div class="bar"><i style="width:98%;background:#16a34a"></i></div><b><?= (int)$g['loans'] ?></b></div>
    <div class="pipe"><span>Draft</span><div class="bar"><i style="width:8%;background:#c7d2fe"></i></div><b><?= $pipeDraft ?></b></div>
    <div class="pipe"><span>Under Review</span><div class="bar"><i style="width:5%;background:#fde68a"></i></div><b><?= $pipeReview ?></b></div>
  </div>
</div>

<div class="row2">
  <div class="panel"><div class="panel-h"><h2>Monthly Disbursement (&#8377; Lakhs)</h2></div><?= linechart($disbSeries) ?></div>
  <div class="panel"><div class="panel-h"><h2>Collection vs Demand (&#8377; Lakhs)</h2>
    <span class="muted sm"><i class="dot" style="background:#c7d2fe"></i>Demand <i class="dot" style="background:#16a34a"></i>Collected</span></div>
    <?= barpairs($months, $demand, $collect) ?></div>
</div>
<?php shell_foot();
