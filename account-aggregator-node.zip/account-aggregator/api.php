<?php
// Account Aggregator API — consent-based bank statement fetch. Called by LOS / portal.
//   ?action=discover        POST mobile            -> which bank/account is linked (masked)
//   ?action=consent-send    POST mobile            -> send consent OTP (via Telecom)
//   ?action=consent-approve POST mobile, otp       -> verify consent, fetch statement from Bank
// AA does NOT evaluate the statement; it securely fetches it from the bank and hands it to the lender.
// LAB / isolated range only.

require __DIR__ . '/config.php';
require __DIR__ . '/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';

if ($action === 'discover') {
    $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    $acc = http_post(BANK_URL, 'account-by-mobile', ['mobile' => $m]);
    if ($acc && !empty($acc['found'])) {
        echo json_encode([
            'found'       => true,
            'bank_name'   => $acc['bank_name'],
            'bank_code'   => $acc['bank_code'],
            'account_no'  => mask_acct($acc['account_no']),
            'holder_name' => $acc['holder_name'],
        ]);
    } else {
        echo json_encode(['found' => false, 'reason' => 'no_linked_account']);
    }
    exit;
}

if ($action === 'consent-send') {
    $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    $acc = http_post(BANK_URL, 'account-by-mobile', ['mobile' => $m]);
    if (!$acc || empty($acc['found'])) { echo json_encode(['status' => 'error', 'reason' => 'no_linked_account']); exit; }
    $r = http_post(TELECOM_URL, 'send', ['mobile' => $m, 'service' => OTP_SERVICE]);
    echo json_encode(($r && ($r['status'] ?? '') === 'sent')
        ? ['status' => 'sent', 'bank_name' => $acc['bank_name']]
        : ['status' => 'error', 'reason' => 'otp_service_unreachable']);
    exit;
}

if ($action === 'consent-approve') {
    $m   = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    $otp = preg_replace('/\D/', '', $_POST['otp'] ?? '');
    $v = http_post(TELECOM_URL, 'verify', ['mobile' => $m, 'otp' => $otp]);
    if (!$v || empty($v['valid'])) { echo json_encode(['status' => 'denied', 'reason' => 'otp_invalid']); exit; }

    // consent granted -> fetch statement from the bank (FIP)
    $stmt = http_post(BANK_URL, 'statement', ['mobile' => $m]);
    if (!$stmt || empty($stmt['found'])) { echo json_encode(['status' => 'error', 'reason' => 'statement_unavailable']); exit; }

    $handle = 'CONSENT' . strtoupper(substr(bin2hex(random_bytes(5)), 0, 10));
    aadb()->prepare("INSERT INTO consents(consent_handle, mobile, bank, status) VALUES(?,?,?, 'APPROVED')")
          ->execute([$handle, $m, $stmt['account']['ifsc'] ?? '']);

    echo json_encode([
        'status'         => 'approved',
        'consent_handle' => $handle,
        'account'        => $stmt['account'],
        'transactions'   => $stmt['transactions'],
    ]);
    exit;
}

echo json_encode(['status' => 'ok', 'service' => 'account-aggregator']);
