<?php
// config.php — NSDL portal config (OTP via the Telecom node).
define('TELECOM_URL', getenv('TELECOM_URL') ?: 'http://10.26.0.5');
define('OTP_SERVICE', 'e-PAN Portal');   // shown as the SMS sender for NSDL OTPs

function tele_post($action, $data) {
    $url = TELECOM_URL . '/api.php?action=' . urlencode($action);
    $opts = ['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content'       => http_build_query($data),
        'timeout'       => 5,
        'ignore_errors' => true,
    ]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}

function nh($s) { return htmlspecialchars((string)$s, ENT_QUOTES); }
