<?php
// LOS DB (SQLite) — REAL DATA ONLY. No seeded/fake rows.
// Tables start empty and fill from actual activity:
//   applications  -> created via the portal/LOS orchestration API
//   loans         -> created when an application is DISBURSED (real loan book)
//   collections   -> real repayments recorded against loans
function ldb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/los.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        schema($pdo);
    }
    return $pdo;
}

function schema($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT, reference_no TEXT UNIQUE,
        full_name TEXT, mobile TEXT, pan TEXT, pan_verified INTEGER DEFAULT 0,
        father_name TEXT, mother_name TEXT, gender TEXT, dob TEXT, email TEXT,
        aadhaar_last4 TEXT, address TEXT, kyc_verified INTEGER DEFAULT 0,
        credit_score INTEGER, credit_band TEXT, credit_performance TEXT,
        industry TEXT, company_name TEXT, designation TEXT, monthly_income REAL,
        requested_amount REAL, initial_offer REAL, final_offer REAL,
        tenure_months INTEGER, emi REAL, roi REAL,
        existing_emi REAL DEFAULT 0, foir REAL,
        bank_health TEXT, statement_verified INTEGER DEFAULT 0,
        decision_reason TEXT,
        bank_code TEXT, beneficiary_account TEXT, beneficiary_ifsc TEXT,
        status TEXT DEFAULT 'DRAFT',
        created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now')))");
    $pdo->exec("CREATE TABLE IF NOT EXISTS loans(
        id INTEGER PRIMARY KEY AUTOINCREMENT, loan_no TEXT, reference_no TEXT, borrower TEXT,
        product TEXT, branch TEXT, principal REAL, collected REAL DEFAULT 0, outstanding REAL,
        emi REAL, dpd INTEGER DEFAULT 0, classification TEXT DEFAULT 'Current', status TEXT DEFAULT 'ACTIVE',
        disbursed_on TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS collections(
        id INTEGER PRIMARY KEY AUTOINCREMENT, loan_no TEXT, amount REAL, paid_on TEXT)");
}

/** Create a real loan-book entry from a disbursed application. Idempotent per reference. */
function add_loan_from_app($pdo, $app) {
    $ex = $pdo->prepare("SELECT 1 FROM loans WHERE reference_no = ?");
    $ex->execute([$app['reference_no']]);
    if ($ex->fetch()) return;
    $principal = (float)($app['final_offer'] ?: 0);
    $n = (int)$pdo->query("SELECT COUNT(*) c FROM loans")->fetch()['c'] + 1;
    $pdo->prepare("INSERT INTO loans(loan_no, reference_no, borrower, product, branch, principal, collected, outstanding, emi, dpd, classification, status, disbursed_on)
        VALUES(?,?,?,?,?,?,0,?,?,0,'Current','ACTIVE',?)")
        ->execute(['LN' . str_pad((string)$n,5,'0',STR_PAD_LEFT), $app['reference_no'], $app['full_name'],
            'Personal Loan', $app['bank_code'] ?: 'Online', $principal, $principal, (float)($app['emi'] ?: 0), date('Y-m-d')]);
}
