<?php
session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/config.php';
require __DIR__ . '/layout.php';

$err = '';
$pdo = ndb();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['send'])) {                         // step: mobile entered
        $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
        if (strlen($m) < 10) {
            $err = 'Enter a valid 10-digit mobile number.';
        } else {
            $st = $pdo->prepare("SELECT pan FROM pan_records WHERE mobile = ?");
            $st->execute([$m]);
            if ($st->fetch()) {                          // registered -> send OTP
                $r = tele_post('send', ['mobile' => $m, 'service' => OTP_SERVICE]);
                if ($r && ($r['status'] ?? '') === 'sent') {
                    $_SESSION['pan_pending_mobile'] = $m;
                    $_SESSION['pan_stage'] = 'otp';
                    header('Location: /index.php'); exit;
                }
                $err = 'Could not reach the OTP service. Check the Telecom node.';
            } else {                                      // not registered -> apply
                header('Location: /apply.php?mobile=' . urlencode($m)); exit;
            }
        }
    }

    if (isset($_POST['verify'])) {                        // step: OTP entered
        $m = $_SESSION['pan_pending_mobile'] ?? '';
        $o = preg_replace('/\D/', '', $_POST['otp'] ?? '');
        $r = tele_post('verify', ['mobile' => $m, 'otp' => $o]);
        if ($r && !empty($r['valid'])) {
            $_SESSION['pan_verified_mobile'] = $m;
            unset($_SESSION['pan_pending_mobile'], $_SESSION['pan_stage']);
            header('Location: /epan.php'); exit;
        }
        $err = 'Invalid or expired OTP.';
    }

    if (isset($_POST['change'])) {
        unset($_SESSION['pan_pending_mobile'], $_SESSION['pan_stage']);
        header('Location: /index.php'); exit;
    }
}

$stage = $_SESSION['pan_stage'] ?? 'mobile';
nhead('PAN Services');
?>
<section class="gov-hero">
  <h1>Download your e-PAN</h1>
  <p>Access your Permanent Account Number online. Verify with the mobile number linked to your PAN.</p>
</section>

<div class="gov-card">
  <?php if ($err) echo '<p class="gov-err">' . nh($err) . '</p>'; ?>

  <?php if ($stage === 'mobile'): ?>
    <h3>Enter registered mobile number</h3>
    <form method="post">
      <label>Mobile number<input name="mobile" pattern="[0-9]{10}" placeholder="10-digit number" required></label>
      <button class="gov-btn" name="send" value="1" type="submit">Get OTP</button>
    </form>
    <p class="gov-note">Mobile number not registered with any PAN? You'll be guided to apply for a new PAN.</p>
  <?php else: ?>
    <h3>Verify OTP</h3>
    <p class="gov-note">An OTP has been sent to <b><?= nh($_SESSION['pan_pending_mobile'] ?? '') ?></b>. Check your Messages.</p>
    <form method="post">
      <label>Enter OTP<input name="otp" inputmode="numeric" pattern="[0-9]{6}" placeholder="6-digit OTP" required autofocus></label>
      <button class="gov-btn" name="verify" value="1" type="submit">Verify &amp; Continue</button>
    </form>
    <form method="post"><button class="gov-link" name="change" value="1" type="submit">Change number</button></form>
  <?php endif; ?>
</div>
<?php nfoot();
