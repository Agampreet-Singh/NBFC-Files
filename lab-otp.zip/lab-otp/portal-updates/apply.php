<?php
session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/layout.php';

// ---- require OTP login (new) ----
if (empty($_SESSION['mobile'])) { header('Location: /login.php'); exit; }

$step = isset($_GET['step']) ? max(1, min(3, (int)$_GET['step'])) : 1;

// ---------------- POST handlers ----------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($step === 1) {
        $_SESSION['app']['full_name']       = trim($_POST['full_name'] ?? '');
        $_SESSION['app']['dob']             = $_POST['dob'] ?? '';
        $_SESSION['app']['mobile']          = $_SESSION['mobile'];   // from verified login
        $_SESSION['app']['email']           = trim($_POST['email'] ?? '');
        $_SESSION['app']['employment_type'] = $_POST['employment_type'] ?? '';
        $_SESSION['app']['monthly_income']  = (float)($_POST['monthly_income'] ?? 0);
        $_SESSION['app']['loan_amount']     = (float)($_POST['loan_amount'] ?? 0);
        header('Location: /apply.php?step=2'); exit;
    }

    if ($step === 2) {
        $_SESSION['app']['pan']                 = strtoupper(trim($_POST['pan'] ?? ''));
        $_SESSION['app']['aadhaar_last4']       = substr(preg_replace('/\D/', '', $_POST['aadhaar'] ?? ''), -4);
        $_SESSION['app']['bank_name']           = trim($_POST['bank_name'] ?? '');
        $_SESSION['app']['beneficiary_account'] = trim($_POST['beneficiary_account'] ?? '');
        $_SESSION['app']['beneficiary_ifsc']    = strtoupper(trim($_POST['beneficiary_ifsc'] ?? ''));

        // =====================================================================
        //  INTENTIONAL LAB WEAKNESS  (red-team entry point) — insecure upload.
        //  No type / MIME / content / size validation; original filename kept;
        //  written INSIDE the web root (/uploads) => directly reachable by HTTP.
        //  >>> DO NOT use this pattern in production. <<<
        // =====================================================================
        $updir = __DIR__ . '/uploads';
        if (!is_dir($updir)) { mkdir($updir, 0775, true); }
        foreach (['kyc_doc', 'income_doc'] as $field) {
            if (!empty($_FILES[$field]['name']) && is_uploaded_file($_FILES[$field]['tmp_name'])) {
                $name = basename($_FILES[$field]['name']);
                move_uploaded_file($_FILES[$field]['tmp_name'], $updir . '/' . $name);
                $_SESSION['app'][$field] = 'uploads/' . $name;
            }
        }
        header('Location: /apply.php?step=3'); exit;
    }

    if ($step === 3) {
        $a = $_SESSION['app'] ?? [];
        $tenure = max(3, min(36, (int)($_POST['tenure_months'] ?? 12)));
        $rate   = 0.016;
        $amount = (float)($a['loan_amount'] ?? 0);
        $emi    = $tenure > 0 ? round(($amount * (1 + $rate * $tenure)) / $tenure) : 0;
        $ref    = 'FC' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));

        $pdo = db();
        $stmt = $pdo->prepare("INSERT INTO applications
            (reference_no, full_name, dob, mobile, email, employment_type, monthly_income, loan_amount,
             pan, aadhaar_last4, bank_name, beneficiary_account, beneficiary_ifsc, kyc_doc, income_doc,
             tenure_months, emi, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'PENDING')");
        $stmt->execute([
            $ref, $a['full_name'] ?? '', $a['dob'] ?? '', $a['mobile'] ?? '', $a['email'] ?? '',
            $a['employment_type'] ?? '', $a['monthly_income'] ?? 0, $amount,
            $a['pan'] ?? '', $a['aadhaar_last4'] ?? '', $a['bank_name'] ?? '',
            $a['beneficiary_account'] ?? '', $a['beneficiary_ifsc'] ?? '',
            $a['kyc_doc'] ?? '', $a['income_doc'] ?? '', $tenure, $emi
        ]);
        unset($_SESSION['app']);
        header('Location: /complete.php?ref=' . urlencode($ref)); exit;
    }
}

// ---------------- GET: render wizard ----------------
render_head('Apply for Loan');
stepper($step);
$a = $_SESSION['app'] ?? [];

if ($step === 1): ?>
  <form class="panel" method="post" action="/apply.php?step=1">
    <h2>Personal Details</h2>
    <div class="grid">
      <label>Full name<input name="full_name" required value="<?= h($a['full_name'] ?? '') ?>"></label>
      <label>Date of birth<input type="date" name="dob" required value="<?= h($a['dob'] ?? '') ?>"></label>
      <label>Mobile number (verified)<input name="mobile_display" value="<?= h($_SESSION['mobile']) ?>" readonly></label>
      <label>Email<input type="email" name="email" required value="<?= h($a['email'] ?? '') ?>"></label>
      <label>Employment type
        <select name="employment_type">
          <option>Salaried</option><option>Self-employed</option><option>Business</option>
        </select>
      </label>
      <label>Monthly income (&#8377;)<input type="number" name="monthly_income" min="0" required value="<?= h($a['monthly_income'] ?? '') ?>"></label>
      <label>Loan amount required (&#8377;)<input type="number" name="loan_amount" min="10000" max="500000" required value="<?= h($a['loan_amount'] ?? '') ?>"></label>
    </div>
    <button class="btn" type="submit">Continue to Banking &amp; KYC</button>
  </form>

<?php elseif ($step === 2): ?>
  <form class="panel" method="post" action="/apply.php?step=2" enctype="multipart/form-data">
    <h2>Banking &amp; KYC</h2>
    <p class="muted">Complete your KYC, add the bank account where your loan will be disbursed, and upload your documents.</p>
    <div class="grid">
      <label>PAN<input name="pan" placeholder="ABCDE1234F" required value="<?= h($a['pan'] ?? '') ?>"></label>
      <label>Aadhaar number<input name="aadhaar" placeholder="XXXX XXXX 1234" required value=""></label>
      <label>Bank name<input name="bank_name" required value="<?= h($a['bank_name'] ?? '') ?>"></label>
      <label>Beneficiary account number<input name="beneficiary_account" required value="<?= h($a['beneficiary_account'] ?? '') ?>"></label>
      <label>IFSC<input name="beneficiary_ifsc" placeholder="HDFC0000123" required value="<?= h($a['beneficiary_ifsc'] ?? '') ?>"></label>
    </div>
    <div class="grid">
      <label>Upload KYC document (PAN / Aadhaar)<input type="file" name="kyc_doc" required></label>
      <label>Upload income proof (salary slip / bank statement)<input type="file" name="income_doc" required></label>
    </div>
    <p class="hint">Accepted: PDF, JPG, PNG.</p>
    <button class="btn" type="submit">Continue to Repayment &amp; e-Sign</button>
  </form>

<?php else:
  $amount = (float)($a['loan_amount'] ?? 0); ?>
  <form class="panel" method="post" action="/apply.php?step=3">
    <h2>Repayment &amp; e-Sign</h2>
    <div class="summary">
      <div><span>Applicant</span><b><?= h($a['full_name'] ?? '') ?></b></div>
      <div><span>Loan amount</span><b>&#8377;<?= number_format($amount) ?></b></div>
      <div><span>Disbursal account</span><b><?= h($a['beneficiary_account'] ?? '') ?> (<?= h($a['beneficiary_ifsc'] ?? '') ?>)</b></div>
    </div>
    <label>Choose tenure
      <select name="tenure_months">
        <option value="6">6 months</option>
        <option value="12" selected>12 months</option>
        <option value="24">24 months</option>
        <option value="36">36 months</option>
      </select>
    </label>
    <p class="muted">An indicative EMI will be shown on the next screen based on your selected tenure.</p>
    <label class="check"><input type="checkbox" required> I have read and agree to the loan agreement and authorise FinanceCorp to disburse the loan to the bank account provided. (e-Sign)</label>
    <button class="btn" type="submit">Submit Application</button>
  </form>
<?php endif;
render_foot();
