<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$f = $_GET['class'] ?? '';
$valid = ['Current','SMA','NPA'];
if ($f && in_array($f,$valid)) { $st=$pdo->prepare("SELECT * FROM loans WHERE classification=? ORDER BY dpd DESC LIMIT 200"); $st->execute([$f]); $rows=$st->fetchAll(); }
else { $rows = $pdo->query("SELECT * FROM loans ORDER BY dpd DESC LIMIT 200")->fetchAll(); }
shell_head('portfolio', 'Loan Portfolio');
?>
<div class="filters">
  <a class="chip <?= !$f?'on':'' ?>" href="/portfolio.php">All</a>
  <?php foreach ($valid as $c): ?><a class="chip <?= $f===$c?'on':'' ?>" href="/portfolio.php?class=<?= $c ?>"><?= $c ?></a><?php endforeach; ?>
</div>
<div class="panel"><table class="tbl">
  <tr><th>Loan No</th><th>Borrower</th><th>Product</th><th>Branch</th><th>Principal</th><th>Outstanding</th><th>DPD</th><th>Class</th><th>Status</th></tr>
  <?php foreach ($rows as $l): ?>
  <tr><td><?= h($l['loan_no']) ?></td><td><?= h($l['borrower']) ?></td><td><?= h($l['product']) ?></td><td><?= h($l['branch']) ?></td>
  <td><?= inr($l['principal']) ?></td><td><?= inr($l['outstanding']) ?></td><td><?= (int)$l['dpd'] ?></td>
  <td><?= badge($l['classification']) ?></td><td><?= badge($l['status']) ?></td></tr>
  <?php endforeach; ?>
</table></div>
<?php shell_foot();
