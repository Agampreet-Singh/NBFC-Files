<?php
session_start();
require __DIR__ . '/layout.php';
$BANK = bank_code();
$pdo = pdo_bank();
if (isset($_GET['logout'])) { unset($_SESSION['cust_' . $BANK]); header('Location: /index.php'); exit; }
$acc = $_SESSION['cust_' . $BANK] ?? '';
if (!$acc) { header('Location: /index.php#login'); exit; }

$st = $pdo->prepare("SELECT * FROM accounts WHERE account_no=? AND bank_code=?"); $st->execute([$acc, $BANK]);
$a = $st->fetch(PDO::FETCH_ASSOC);
if (!$a) { unset($_SESSION['cust_' . $BANK]); header('Location: /index.php'); exit; }
$tx = $pdo->prepare("SELECT * FROM transactions WHERE account_no=? ORDER BY id DESC"); $tx->execute([$acc]);
$rows = $tx->fetchAll(PDO::FETCH_ASSOC);
$cr = 0; $drc = 0; foreach ($rows as $t) { if ($t['dr_cr'] === 'CR') $cr += $t['amount']; else $drc += $t['amount']; }
$sec = $_GET['sec'] ?? '';

function txn_table($rows, $limit = 0) {
    echo '<table><tr><th>Date</th><th>Description</th><th class="r">Debit</th><th class="r">Credit</th><th class="r">Balance</th></tr>';
    $i = 0; foreach ($rows as $t) { if ($limit && $i++ >= $limit) break;
        echo '<tr><td>' . h($t['txn_date']) . '</td><td>' . h($t['description']) . '</td>'
           . '<td class="r dr">' . ($t['dr_cr'] === 'DR' ? number_format($t['amount'], 2) : '') . '</td>'
           . '<td class="r cr">' . ($t['dr_cr'] === 'CR' ? number_format($t['amount'], 2) : '') . '</td>'
           . '<td class="r">' . number_format($t['balance_after'], 2) . '</td></tr>';
    }
    if (!$rows) echo '<tr><td colspan="5" class="hint">No transactions.</td></tr>';
    echo '</table>';
}

app_head($sec, $a['holder_name'], 'customer');

if ($sec === 'txns') {
    echo '<div class="panel"><div class="ph"><h3>All Transactions</h3></div>';
    txn_table($rows); echo '</div>';
} elseif ($sec === 'stmt') {
    echo '<div class="panel"><div class="ph"><h3>Account Statement</h3><a class="dlbtn" href="/statement.php">' . icon('doc') . ' Download PDF</a></div>';
    echo '<p class="hint">Download your full account statement as a PDF, or view all transactions in the Transactions tab.</p>';
    txn_table($rows, 10); echo '</div>';
} else {
    // overview
    echo '<div class="acct-hero"><div class="lab">Available Balance</div><div class="amt">' . inr($a['balance']) . '</div>';
    echo '<div class="meta"><div><b>Account Number</b>' . h($a['account_no']) . '</div><div><b>IFSC</b>' . h($a['ifsc']) . '</div><div><b>Type</b>' . h($a['acc_type']) . '</div></div></div>';
    echo '<div class="qrow">';
    echo '<div class="qcard"><div class="qic">' . icon('list') . '</div><div><div class="qv">' . count($rows) . '</div><div class="ql">Transactions</div></div></div>';
    echo '<div class="qcard"><div class="qic">' . icon('cash') . '</div><div><div class="qv">' . inr($cr) . '</div><div class="ql">Total Credits</div></div></div>';
    echo '<div class="qcard"><div class="qic">' . icon('wallet') . '</div><div><div class="qv">' . inr($drc) . '</div><div class="ql">Total Debits</div></div></div>';
    echo '</div>';
    echo '<div class="panel"><div class="ph"><h3>Recent Transactions</h3><a class="dlbtn" href="/statement.php">' . icon('doc') . ' Download Statement</a></div>';
    txn_table($rows, 8); echo '</div>';
}
app_foot();
