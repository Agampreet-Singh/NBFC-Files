# OTP / Telecom add-on for the Silent Disbursal lab

Adds mobile-number + OTP login to the FinanceCorp portal, with a real Telecom gateway
and a phone-style Messages app. Lab / isolated range only.

## Pieces & where they go

| Folder | Deploy on node | What it is |
|---|---|---|
| `telecom-service/` | **Telecom Service** (10.26.0.5) | OTP gateway: generates, stores, delivers & validates OTPs |
| `messages-app/` | **Red Team** node | Phone-style inbox that shows OTP SMS (the borrower's "phone") |
| `portal-updates/` | **FinanceCorp Portal** | Adds `login.php`, `config.php`, and an updated `apply.php` (login-gated) |

## 1) Telecom Service node
```
sudo apt update && sudo apt install -y apache2 php libapache2-mod-php php-sqlite3
sudo cp -r telecom-service/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html
sudo rm -f /var/www/html/index.html && sudo systemctl restart apache2
```
Check: `http://10.26.0.5/` shows "Telecom OTP Gateway".

## 2) Red Team node — Messages app
It's a single static file; serve it any way, e.g.:
```
cd messages-app && python3 -m http.server 8080
```
Open it, set **Telecom URL** = `http://10.26.0.5`, type the mobile number, tap **Load**.
OTP messages appear and auto-refresh every 3s.

## 3) FinanceCorp Portal — add OTP login
Copy these over your existing portal (they add/replace files):
```
sudo cp portal-updates/config.php portal-updates/login.php portal-updates/apply.php /var/www/html/
sudo chown www-data:www-data /var/www/html/config.php /var/www/html/login.php /var/www/html/apply.php
```
Set the Telecom node address in `config.php` (`TELECOM_URL`, default `http://10.26.0.5`).
Now `/apply.php` redirects to `/login.php` until a mobile+OTP is verified.

## The flow (real validation)
1. Borrower opens the portal -> `login.php`, enters mobile -> portal calls Telecom `send`.
2. Telecom generates an OTP, stores it, and drops an SMS into the inbox.
3. Borrower reads the OTP in the **Messages app** (Red Team node).
4. Borrower enters the OTP -> portal calls Telecom `verify` -> on success, login + apply opens.

## Reachability needed (router rules)
- Portal (10.21.0.2) -> Telecom (10.26.0.5) : `send` + `verify`
- Red Team (10.20.0.x) -> Telecom (10.26.0.5) : `messages` (the Messages app polls this)
Ideally restrict the Telecom segment to just this OTP API, so it doesn't become an open path between zones.

## Note
The `messages` endpoint returns an inbox by mobile number (lab simplification — no auth on read).
Fine for training; it just simulates SMS delivery to the number in use.
