<?php
require_once __DIR__ . '/config.php';

function step_labels() {
    return [1=>'Mobile',2=>'Loan',3=>'PAN',4=>'Details',5=>'Eligibility',6=>'Offer',
            7=>'Bank',8=>'Final Offer',9=>'KYC',10=>'Selfie',11=>'e-Mandate'];
}
function LAST_STEP() { return 11; }

/* Phases group the journey into the big boxes shown at the top. */
function phases() {
    return [
        ['Your Loan',   [2]],
        ['Identity',    [3,4]],
        ['Eligibility', [5,6]],
        ['Banking',     [7,8]],
        ['KYC',         [9,10]],
        ['Finalize',    [11]],
    ];
}

/* Context shown in the left panel for each step: [title, description, [bullets]]. */
function step_info($step) {
    $m = [
        2  => ['Loan Requirement', 'How much do you need, and for how long? Slide to choose.', ['Instant indicative pricing', 'No impact on your credit score']],
        3  => ['PAN & Date of Birth', 'We verify your PAN instantly with NSDL and match your DOB.', ['Instant verification', 'Bank-grade encryption']],
        4  => ['Personal Details', 'A few details about you, your address and your work.', ['Matched to your official records', 'All in one step']],
        5  => ['Credit Assessment', 'We securely assess your credit profile.', ['Soft check — no score impact', 'RBI-compliant bureau pull']],
        6  => ['Your Offer', 'Here is what you qualify for. Need more? Just ask.', ['Flexible amount & tenure', 'Transparent interest rate']],
        7  => ['Bank Details', 'Link the bank account for your statement and disbursal.', ['Secure Account Aggregator', 'Verified internally']],
        8  => ['Final Offer', 'Your final, locked-in loan terms.', ['Reviewed & approved', 'Accept to continue']],
        9  => ['Aadhaar KYC', 'Complete e-KYC via DigiLocker.', ['RBI-compliant', 'OTP based']],
        10 => ['Selfie Verification', 'A quick photo to confirm it is really you.', ['Liveness & identity check']],
        11 => ['Bank Account & e-Mandate', 'Verify your account and authorise auto-debit.', ['Account verification', 'e-NACH mandate']],
    ];
    return $m[$step] ?? ['FinanceCorp', '', []];
}

/* ===== pricing helpers (mirror los/config.php and the slider JS) ===== */
if (!function_exists('roi_for')) {
    function roi_for($amount) {
        $a = (float)$amount;
        if ($a <= 100000) return 15.0;
        if ($a <= 300000) return 13.5;
        if ($a <= 500000) return 12.0;
        return 11.0;
    }
}
if (!function_exists('emi_for')) {
    function emi_for($principal, $annual_roi, $months) {
        $p = (float)$principal; $n = (int)$months;
        if ($n <= 0) return 0;
        $r = (float)$annual_roi / 1200;
        if ($r <= 0) return (int)round($p / $n);
        $f = pow(1 + $r, $n);
        return (int)round($p * $r * $f / ($f - 1));
    }
}

/* ================= datasets (local, for the isolated range) ================= */
function industries_list() {
    return ['Agriculture & Farming','Dairy & Poultry','Horticulture','Fisheries','Agro-processing','Food Processing',
        'Diamond & Gems Traders','Jewellers / Goldsmiths','Textiles & Garments','Handloom & Handicrafts',
        'Astrologers','Priests / Clergy','Builders & Real Estate','Construction & Contractors',
        'Information Technology (IT) / Software','IT-enabled Services (BPO/KPO)','Telecom','Electronics & Hardware',
        'Banking & Financial Services','Insurance','Chartered Accountants / Auditors','Legal / Advocates',
        'Medical & Healthcare','Pharmaceuticals','Veterinary','Education & Teaching','Research & Development',
        'Government / Public Sector','Defence / Armed Forces','Automobile & Auto Components','Logistics & Transport',
        'Aviation','Shipping & Ports','Hospitality & Hotels','Restaurants & Catering','Tourism & Travel',
        'Retail & Trading','E-commerce','FMCG','Manufacturing','Steel & Metals','Cement','Chemicals',
        'Oil & Gas','Power & Energy','Renewable Energy','Mining','Media & Entertainment','Film & Television',
        'Advertising & Marketing','Printing & Publishing','Sports & Fitness','Beauty & Wellness / Salons',
        'Photography','Event Management','Security Services','Housekeeping & Facility','Plumbing / Electrical / Carpentry',
        'Tailoring','Kirana / Grocery Store','Street Vendors / Small Traders','Transport Operators (Taxi/Auto)',
        'Cold Storage & Warehousing','NGO / Social Work','Consultants / Freelancers','Others'];
}
function companies_list() {
    return ['Tata Consultancy Services','Infosys','Wipro','HCL Technologies','Tech Mahindra','LTIMindtree','Mphasis',
        'Accenture','Cognizant','Capgemini','IBM India','Oracle India','SAP Labs India','Amazon India','Flipkart',
        'Paytm','Zomato','Swiggy','PhonePe','Jio Platforms','Bharti Airtel','Vodafone Idea','Reliance Industries',
        'Hindustan Unilever','ITC Limited','Nestlé India','Larsen & Toubro','Mahindra & Mahindra','Tata Motors',
        'Maruti Suzuki','Bajaj Auto','Hero MotoCorp','Adani Group','HDFC Bank','ICICI Bank','State Bank of India',
        'Axis Bank','Kotak Mahindra Bank','Bajaj Finserv','Asian Paints','Sun Pharma','Dr. Reddy\'s Laboratories',
        'Cipla','Apollo Hospitals','DLF Limited','UltraTech Cement','JSW Steel','Tata Steel','ONGC','NTPC'];
}
function localities_list() {
    return ['Connaught Place, New Delhi - 110001','Saket, New Delhi - 110017','Dwarka, New Delhi - 110075',
        'Bandra West, Mumbai - 400050','Andheri East, Mumbai - 400069','Powai, Mumbai - 400076',
        'Koramangala, Bengaluru - 560034','Indiranagar, Bengaluru - 560038','Whitefield, Bengaluru - 560066',
        'Banjara Hills, Hyderabad - 500034','Gachibowli, Hyderabad - 500032','FC Road, Pune - 411004',
        'Kothrud, Pune - 411038','Hinjewadi, Pune - 411057','Anna Nagar, Chennai - 600040','T. Nagar, Chennai - 600017',
        'Salt Lake, Kolkata - 700064','Park Street, Kolkata - 700016','C-Scheme, Jaipur - 302001',
        'Navrangpura, Ahmedabad - 380009','MG Road, Gurugram - 122002','Sector 62, Noida - 201309',
        'Hazratganj, Lucknow - 226001','Civil Lines, Nagpur - 440001','MI Road, Jaipur - 302001',
        'Alkapuri, Vadodara - 390007'];
}
function bank_theme($code) {
    $m = ['HDFC'=>['HDFC Bank','#004C8F'],'PUNB'=>['Punjab National Bank','#7A1F2B'],
          'BARB'=>['Bank of Baroda','#F15A22'],'SBIN'=>['State Bank of India','#22409A'],
          'ICIC'=>['ICICI Bank','#AE292E'],'UTIB'=>['Axis Bank','#97144D'],'KKBK'=>['Kotak Mahindra Bank','#C4122E']];
    return $m[$code] ?? [$code, '#06402b'];
}

/* ================= widgets ================= */
function industry_input($name) {
    echo '<input list="industryList" name="'.h($name).'" placeholder="Search / select your industry" autocomplete="off" required>';
    echo '<datalist id="industryList">';
    foreach (industries_list() as $i) echo '<option value="'.h($i).'">';
    echo '</datalist>';
}
function company_input($name) {
    echo '<input list="companyList" name="'.h($name).'" id="companyField" placeholder="Type your company name" autocomplete="off" required>';
    echo '<datalist id="companyList">';
    foreach (companies_list() as $c) echo '<option value="'.h($c).'">';
    echo '</datalist>';
    echo '<p class="field-hint" id="companyHint"></p>';
    echo '<script>(function(){var set=' . json_encode(array_map("strtolower", companies_list())) . ';'
        .'var f=document.getElementById("companyField"),h=document.getElementById("companyHint");'
        .'f.addEventListener("input",function(){var v=f.value.trim().toLowerCase();'
        .'if(!v){h.textContent="";h.className="field-hint";return;}'
        .'if(set.indexOf(v)>=0){h.textContent="✓ Verified company";h.className="field-hint ok";}'
        .'else{h.textContent="New company — we\'ll use what you entered";h.className="field-hint";}});})();</script>';
}
function address_map_picker($name) {
    echo '<div class="mapwrap">';
    echo '<label class="maplabel">Mailing Address</label>';
    echo '<div class="mapsearch"><input id="addrSearch" placeholder="&#128269; Search area, locality or pincode" autocomplete="off">';
    echo '<div id="addrResults" class="addr-results"></div></div>';
    echo '<div class="fakemap" id="fakemap"><div class="map-grid"></div><div class="map-roads"></div>';
    echo '<div class="map-pin" id="mapPin">&#128205;</div>';
    echo '<button type="button" class="geo-btn" id="geoBtn">&#9678; Use current location</button>';
    echo '<div class="map-caption" id="mapCap">Search or tap the map to set your location</div></div>';
    echo '<label class="maplabel" style="margin-top:12px">Selected address</label>';
    echo '<textarea name="'.h($name).'" id="addrField" rows="2" placeholder="Your selected address will appear here" required></textarea>';
    echo '<script>(function(){var L=' . json_encode(localities_list()) . ';'
        .'var si=document.getElementById("addrSearch"),res=document.getElementById("addrResults"),'
        .'fld=document.getElementById("addrField"),pin=document.getElementById("mapPin"),'
        .'cap=document.getElementById("mapCap"),map=document.getElementById("fakemap");'
        .'function pick(v){fld.value=v;cap.textContent="✓ "+v;res.innerHTML="";si.value=v;}'
        .'si.addEventListener("input",function(){var q=si.value.trim().toLowerCase();res.innerHTML="";if(!q)return;'
        .'L.filter(function(x){return x.toLowerCase().indexOf(q)>=0;}).slice(0,6).forEach(function(x){'
        .'var d=document.createElement("div");d.className="addr-item";d.textContent=x;'
        .'d.addEventListener("mousedown",function(){pick(x);});res.appendChild(d);});});'
        .'document.getElementById("geoBtn").addEventListener("click",function(){'
        .'cap.textContent="Detecting your location…";pin.classList.add("drop");'
        .'if(navigator.geolocation){navigator.geolocation.getCurrentPosition('
        .'function(p){cap.textContent="📍 Location detected ("+p.coords.latitude.toFixed(3)+", "+p.coords.longitude.toFixed(3)+") — search above to confirm your address";},'
        .'function(){cap.textContent="Could not detect location — please search above";},{timeout:6000});'
        .'}else{cap.textContent="Location unavailable — please search above";}});'
        .'map.addEventListener("click",function(e){if(e.target.classList.contains("geo-btn"))return;'
        .'var r=map.getBoundingClientRect();pin.style.left=((e.clientX-r.left)/r.width*100)+"%";'
        .'pin.style.top=((e.clientY-r.top)/r.height*100)+"%";pin.classList.add("drop");'
        .'if(!fld.value)cap.textContent="Pin dropped — search to name this location";});'
        .'})();</script>';
}
function bank_search_ui($banks) {
    echo '<form method="post">';
    echo '<div class="acct-type"><div class="at-lead">Which account should we use?</div>';
    echo '<label class="at-opt"><input type="radio" name="acct_type" value="salary" checked> <span><b>Salary Account</b><small>Recommended</small></span></label>';
    echo '<label class="at-opt"><input type="radio" name="acct_type" value="transactions"> <span><b>Account with most transactions</b><small>Choose this if your salary bank is not listed</small></span></label>';
    echo '</div>';
    echo '<label style="margin-top:16px">Enter your bank<input id="bankSearch" placeholder="Search your bank" autocomplete="off"></label>';
    echo '<div class="bankgrid" id="bankGrid">';
    foreach ($banks as $b) {
        [$nm, $col] = bank_theme($b['code']);
        $ini = strtoupper(substr($b['code'], 0, 2));
        echo '<button type="button" class="bankcard" data-code="'.h($b['code']).'" data-name="'.h($b['name']).'">'
            .'<span class="bank-ic" style="background:'.$col.'">'.$ini.'</span>'
            .'<span class="bank-nm">'.h($b['name']).'</span></button>';
    }
    echo '</div>';
    echo '<input type="hidden" name="bank_code" id="bankCode"><input type="hidden" name="bank_name" id="bankName">';
    echo '<div class="bank-chosen" id="bankChosen"></div>';
    echo '<button class="btn" id="bankContinue" disabled>Continue</button>';
    echo '</form>';
    echo '<script>(function(){var s=document.getElementById("bankSearch"),g=document.getElementById("bankGrid"),'
        .'code=document.getElementById("bankCode"),nm=document.getElementById("bankName"),'
        .'ch=document.getElementById("bankChosen"),btn=document.getElementById("bankContinue");'
        .'var cards=[].slice.call(g.querySelectorAll(".bankcard"));'
        .'s.addEventListener("input",function(){var q=s.value.trim().toLowerCase();cards.forEach(function(c){'
        .'c.style.display=c.getAttribute("data-name").toLowerCase().indexOf(q)>=0?"":"none";});});'
        .'cards.forEach(function(c){c.addEventListener("click",function(){cards.forEach(function(x){x.classList.remove("sel");});'
        .'c.classList.add("sel");code.value=c.getAttribute("data-code");nm.value=c.getAttribute("data-name");'
        .'ch.textContent="Selected: "+c.getAttribute("data-name");btn.disabled=false;});});'
        .'})();</script>';
}

/* ===== Celebration: confetti burst (vanilla, no libs) ===== */
function celebration_js() {
    echo '<script>(function(){'
        .'var colors=["#22c55e","#16a34a","#06402b","#f59e0b","#ef4444","#3b82f6","#ec4899"];'
        // confetti only (balloons removed)
        .'for(var j=0;j<90;j++){var c=document.createElement("div");c.className="confetti";'
        .'c.style.left=(Math.random()*100)+"vw";c.style.background=colors[j%colors.length];'
        .'c.style.animationDuration=(2.4+Math.random()*2)+"s";c.style.animationDelay=(Math.random()*0.5)+"s";'
        .'c.style.transform="rotate("+(Math.random()*360)+"deg)";document.body.appendChild(c);'
        .'(function(c){setTimeout(function(){c.remove();},6000);})(c);}'
        .'})();</script>';
}

/* ===== Loan slider: shared UI + JS (ROI/EMI mirrors los/config.php) ===== */
function loan_slider_ui($amtMin, $amtMax, $amtDef, $tenDef, $submitLabel) {
    $f = fn($n) => '&#8377;' . number_format($n);
    echo '<form method="post" class="loanform">';
    echo '<div class="lf-row"><label>Loan amount</label><span class="lf-val" id="amtOut"></span></div>';
    echo '<input type="range" class="slider" id="amt" min="'.$amtMin.'" max="'.$amtMax.'" step="10000" value="'.$amtDef.'">';
    echo '<div class="lf-minmax"><span>'.$f($amtMin).'</span><span>'.$f($amtMax).'</span></div>';
    echo '<div class="lf-row" style="margin-top:20px"><label>Tenure</label><span class="lf-val" id="tenOut"></span></div>';
    echo '<input type="range" class="slider" id="ten" min="12" max="60" step="6" value="'.$tenDef.'">';
    echo '<div class="lf-minmax"><span>12 months</span><span>60 months</span></div>';
    echo '<div class="loan-summary"><div class="ls-item"><span>Interest Rate</span><b id="roiOut"></b></div>'
        .'<div class="ls-item"><span>Monthly EMI</span><b id="emiOut"></b></div></div>';
    echo '<input type="hidden" name="requested_amount" id="f_amt"><input type="hidden" name="tenure_months" id="f_ten">';
    echo '<input type="hidden" name="roi" id="f_roi"><input type="hidden" name="emi" id="f_emi">';
    echo '<button class="btn">'.h($submitLabel).'</button></form>';
    echo '<script>(function(){'
        .'function roiFor(a){a=+a;if(a<=100000)return 15.0;if(a<=300000)return 13.5;if(a<=500000)return 12.0;return 11.0;}'
        .'function emiFor(p,ann,n){p=+p;n=+n;if(n<=0)return 0;var r=ann/1200;if(r<=0)return Math.round(p/n);var f=Math.pow(1+r,n);return Math.round(p*r*f/(f-1));}'
        .'function inr(x){return "₹"+Math.round(x).toLocaleString("en-IN");}'
        .'var amt=document.getElementById("amt"),ten=document.getElementById("ten");'
        .'function upd(){var a=+amt.value,n=+ten.value,roi=roiFor(a),emi=emiFor(a,roi,n);'
        .'document.getElementById("amtOut").textContent=inr(a);'
        .'document.getElementById("tenOut").textContent=n+" months";'
        .'document.getElementById("roiOut").textContent=roi.toFixed(1)+"% p.a.";'
        .'document.getElementById("emiOut").textContent=inr(emi)+" / mo";'
        .'document.getElementById("f_amt").value=a;document.getElementById("f_ten").value=n;'
        .'document.getElementById("f_roi").value=roi;document.getElementById("f_emi").value=emi;}'
        .'amt.addEventListener("input",upd);ten.addEventListener("input",upd);upd();'
        .'})();</script>';
}

function render_stepper($step) {
    $labels = step_labels();
    echo '<div class="stepper"><div class="stepper-track">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
        $mark = $n < $step ? '&#10003;' : $n;
        echo '<div class="stp ' . $cls . '"><span class="node">' . $mark . '</span><em>' . h($l) . '</em></div>';
        if ($n < count($labels)) echo '<span class="seg ' . ($n < $step ? 'done' : '') . '"></span>';
    }
    echo '</div></div>';
}

/* ===== Phase stepper: full-width boxes with arrows (the big progress banner) ===== */
function render_phase_stepper($step) {
    $phases = phases();
    $labels = step_labels();
    $last   = LAST_STEP();
    $pct    = max(0, min(100, round((($step - 2) / ($last - 2)) * 100)));
    echo '<div class="phase-card"><div class="phase-row">';
    foreach ($phases as $i => $ph) {
        [$name, $steps] = $ph;
        $isCurr = in_array($step, $steps, true);
        $isDone = max($steps) < $step;
        $cls = $isDone ? 'done' : ($isCurr ? 'curr' : 'todo');
        echo '<div class="phase ' . $cls . '"><span class="ph-no">' . ($i + 1) . '</span><span class="ph-name">' . h($name) . '</span></div>';
        if ($i < count($phases) - 1) echo '<span class="phase-arrow">&rarr;</span>';
    }
    echo '</div><div class="prog-bar"><span style="width:' . $pct . '%"></span></div>';
    echo '<div class="prog-count">Step ' . (int)($step - 1) . ' of ' . ($last - 1) . ' &middot; ' . h($labels[$step] ?? '') . '</div>';
    echo '</div>';
}

/* ===== Post-login app shell (full-screen, header + welcome) ===== */
function app_doc_open($title) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body class="app">';
}
function app_topbar($name = '', $toast = true) {
    echo '<header class="appbar"><div class="ab-in">';
    echo '<div class="ab-logo"><span class="logo">F</span><span class="ab-name">FinanceCorp</span></div>';
    echo '<div class="ab-right">';
    if ($name !== '') echo '<span class="ab-welcome">Welcome <b>' . h($name) . '</b></span>';
    echo '<a class="ab-logout" href="/logout.php">&#8614; Logout</a></div>';
    echo '</div></header>';
    if ($toast) echo '<div class="toast"><span class="toast-ic">&#10003;</span> Welcome to FinanceCorp</div>';
}
function ahead($title = '', $step = 0, $name = '') {
    app_doc_open($title);
    app_topbar($name, $step === 0 || $step === 2);   // welcome toast on first entry only
    echo '<main class="appmain"><div class="wrap">';
    if ($step > 0) {
        render_phase_stepper($step);
        [$t, $d, $bul] = step_info($step);
        echo '<div class="cols"><aside class="side">';
        echo '<div class="side-step">STEP ' . (int)($step - 1) . '</div>';
        echo '<h2 class="side-title">' . h($t) . '</h2>';
        if ($d !== '') echo '<p class="side-desc">' . h($d) . '</p>';
        if ($bul) { echo '<ul class="side-bul">'; foreach ($bul as $b) echo '<li>' . h($b) . '</li>'; echo '</ul>'; }
        echo '<div class="side-secure">&#128274; 256-bit secure &middot; RBI-registered NBFC</div>';
        echo '</aside><div class="appcard">';
    } else {
        echo '<div class="cols single"><div class="appcard">';
    }
}
function afoot() {
    echo '</div></div></div></main>';
    // transition loader: one spinner that shows briefly on each step submit
    echo '<div class="route-loader" id="routeLoader"><div class="spinner-one big"></div><div class="rl-txt">Processing…</div></div>';
    echo '<script>(function(){document.addEventListener("submit",function(e){var f=e.target;if(f.__go)return;'
        .'if(f.getAttribute("data-noload")!==null)return;e.preventDefault();var sb=e.submitter;'
        .'if(sb&&sb.name){var h=document.createElement("input");h.type="hidden";h.name=sb.name;h.value=sb.value;f.appendChild(h);}'
        .'document.getElementById("routeLoader").classList.add("on");f.__go=true;'
        .'setTimeout(function(){f.submit();},1100);});})();</script>';
    echo '</body></html>';
}

/* ===== Pre-login split-screen shell (login / OTP) ===== */
function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body>';
    echo '<div class="split">';
    // LEFT brand panel
    echo '<aside class="brandpanel"><div class="bp-in">';
    echo '<div class="bp-logo"><span class="logo">F</span><div class="bp-name"><b>FinanceCorp</b><small>Instant Personal Loan</small></div></div>';
    echo '<h1>Quick, easy loans up to <span class="hl">&#8377;5,00,000</span></h1>';
    echo '<ul class="bp-ticks"><li>Easy personal loan for all purposes</li><li>Collateral-free loans</li><li>Seamless login process</li><li>Simple repayment</li></ul>';
    echo '<div class="bp-cards"><div class="bp-card">&#9201; Calculate your EMI within minutes</div><div class="bp-card">&#128176; Low interest rates &amp; minimal fees</div><div class="bp-card">&#128241; 24x7 access to the loan app</div></div>';
    echo '</div></aside>';
    // RIGHT content pane
    echo '<section class="pane"><div class="pane-scroll">';
    if ($step > 0) render_stepper($step);
    echo '<div class="pane-inner">';
}

function pfoot() { echo '</div></div></section></div></body></html>'; }

/** SVG illustration for the status modal (folder + face + badge). */
function status_illustration($type) {
    $badge = $type === 'reject' ? '#dc2626' : '#d97706';
    $mark  = $type === 'reject'
        ? '<path d="M93 42l14 14M107 42l-14 14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>'
        : '<path d="M100 40v11M100 57v.5" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>';
    return '<svg viewBox="0 0 200 150" width="186" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<ellipse cx="100" cy="128" rx="78" ry="9" fill="#e8efea"/>'
        . '<rect x="104" y="30" width="46" height="58" rx="5" fill="#eef3f0"/>'
        . '<rect x="112" y="42" width="30" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="52" width="24" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="62" width="28" height="4" rx="2" fill="#d7e3dc"/>'
        . '<path d="M44 108V70a8 8 0 018-8h26l9 10h40a8 8 0 018 8v28a8 8 0 01-8 8H52a8 8 0 01-8-8z" fill="#06402b"/>'
        . '<path d="M60 86l10 10M70 86l-10 10M60 110l10 10M70 110l-10 10" stroke="#06402b" stroke-width="0" />'
        . '<text x="74" y="92" font-family="monospace" font-size="15" fill="#bfe8d4" font-weight="700">&gt;&lt;</text>'
        . '<path d="M72 104q8 -6 16 0" stroke="#bfe8d4" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
        . '<circle cx="100" cy="49" r="16" fill="#fff"/><circle cx="100" cy="49" r="13" fill="' . $badge . '"/>' . $mark
        . '</svg>';
}

/** Full-page modal result (reject / already-applied), styled over the app shell. Ends the request. */
function result_screen($type, $title, $reason = '', $sub = '', $showStatus = true) {
    $name = $_SESSION['pan_name'] ?? '';
    app_doc_open('Application Status');
    app_topbar($name);
    echo '<main class="appmain dimmed"><div class="wrap"><div class="appcard ghostcard"></div></div></main>';
    echo '<div class="backdrop"><div class="modal ' . ($type === 'reject' ? 'is-reject' : 'is-info') . '">';
    echo '<div class="modal-ill">' . status_illustration($type) . '</div>';
    echo '<h2 class="modal-title">' . h($title) . '</h2>';
    if ($reason !== '') echo '<p class="modal-text">' . h($reason) . '</p>';
    if ($sub !== '')    echo '<p class="modal-text sub">' . h($sub) . '</p>';
    echo '<div class="modal-actions">';
    if ($showStatus) echo '<a class="btn ghost" href="/status.php">Check status</a>';
    echo '<a class="btn" href="/login.php">Ok</a>';
    echo '</div></div></div></body></html>';
    exit;
}
function card_open($h){ /* title now lives in the side panel */ }
function card_lead($t){ echo '<p class="appcard-lead">' . h($t) . '</p>'; }
function card_close(){}
