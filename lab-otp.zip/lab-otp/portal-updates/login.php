<?php
session_start();
require __DIR__ . '/layout.php';
require __DIR__ . '/config.php';

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send'])) {                       // step 1: request OTP
        $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
        if (strlen($m) < 10) {
            $err = 'Enter a valid 10-digit mobile number.';
        } else {
            $r = tele_post('send', ['mobile' => $m]);
            if ($r && ($r['status'] ?? '') === 'sent') {
                $_SESSION['pending_mobile'] = $m;
                $_SESSION['login_stage'] = 'otp';
                header('Location: /login.php'); exit;
            }
            $err = 'Could not reach the OTP service. Check the Telecom node / TELECOM_URL.';
        }
    }
    if (isset($_POST['verify'])) {                      // step 2: verify OTP
        $m = $_SESSION['pending_mobile'] ?? '';
        $o = preg_replace('/\D/', '', $_POST['otp'] ?? '');
        $r = tele_post('verify', ['mobile' => $m, 'otp' => $o]);
        if ($r && !empty($r['valid'])) {
            $_SESSION['mobile'] = $m;                   // logged in
            unset($_SESSION['pending_mobile'], $_SESSION['login_stage']);
            header('Location: /apply.php?step=1'); exit;
        }
        $err = 'Invalid or expired OTP. Please try again.';
    }
    if (isset($_POST['change'])) {                      // use a different number
        unset($_SESSION['pending_mobile'], $_SESSION['login_stage']);
        header('Location: /login.php'); exit;
    }
}

$stage = $_SESSION['login_stage'] ?? 'mobile';
render_head('Login');
?>
<div class="panel" style="max-width:460px;margin:0 auto">
  <h2>Login to FinanceCorp</h2>
  <?php if ($err) echo '<p class="hint" style="color:#c0392b">' . h($err) . '</p>'; ?>

  <?php if ($stage === 'mobile'): ?>
    <p class="muted">Enter your mobile number. We'll send you a one-time password (OTP).</p>
    <form method="post">
      <label>Mobile number<input name="mobile" pattern="[0-9]{10}" placeholder="10-digit number" required></label>
      <button class="btn" name="send" value="1" type="submit">Send OTP</button>
    </form>
  <?php else: ?>
    <p class="muted">We sent an OTP to <b><?= h($_SESSION['pending_mobile'] ?? '') ?></b>. Check your Messages app and enter it below.</p>
    <form method="post">
      <label>Enter OTP<input name="otp" inputmode="numeric" pattern="[0-9]{6}" placeholder="6-digit OTP" required autofocus></label>
      <button class="btn" name="verify" value="1" type="submit">Verify &amp; Continue</button>
    </form>
    <form method="post" style="margin-top:10px">
      <button class="btn" name="change" value="1" type="submit" style="background:#64748b">Change number</button>
    </form>
  <?php endif; ?>
</div>
<?php render_foot();
