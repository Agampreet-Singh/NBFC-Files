<?php
/**
 * SimplePDF — tiny dependency-free PDF writer (Helvetica core fonts).
 * Enough for account statements: text, lines, auto page-break rows. Works offline.
 */
class SimplePDF {
    const PW = 595.28, PH = 841.89;   // A4 points
    private $pages = [], $cur = '', $y, $mTop = 60, $mBot = 60;

    public function __construct() { $this->addPage(); }

    public function addPage() {
        if ($this->cur !== '') $this->pages[] = $this->cur;
        $this->cur = '';
        $this->y = self::PH - $this->mTop;
    }
    public function y() { return $this->y; }
    public function setY($y) { $this->y = $y; }
    public function needSpace($h) { if ($this->y - $h < $this->mBot) { $this->addPage(); return true; } return false; }

    private function esc($s) {
        $s = (string)$s;
        $s = str_replace(["\\", "(", ")", "\r", "\n"], ["\\\\", "\\(", "\\)", "", " "], $s);
        // keep it ASCII-safe for core fonts
        return preg_replace('/[^\x20-\x7E]/', ' ', $s);
    }
    public function text($x, $y, $s, $size = 10, $bold = false, $color = null) {
        $f = $bold ? 'F2' : 'F1';
        $c = '';
        if ($color) $c = sprintf("%.3f %.3f %.3f rg\n", $color[0]/255, $color[1]/255, $color[2]/255);
        $r = $color ? "0 0 0 rg\n" : '';
        $this->cur .= $c . "BT /$f $size Tf $x $y Td (" . $this->esc($s) . ") Tj ET\n" . $r;
    }
    public function line($x1, $y1, $x2, $y2, $w = 0.5, $g = 0.75) {
        $this->cur .= sprintf("%.2f w %.2f %.2f %.2f RG\n%.2f %.2f m %.2f %.2f l S\n0 0 0 RG\n", $w, $g, $g, $g, $x1, $y1, $x2, $y2);
    }
    public function fillRect($x, $y, $w, $h, $color) {
        $this->cur .= sprintf("%.3f %.3f %.3f rg\n%.2f %.2f %.2f %.2f re f\n0 0 0 rg\n", $color[0]/255, $color[1]/255, $color[2]/255, $x, $y, $w, $h);
    }

    public function output() {
        if ($this->cur !== '') { $this->pages[] = $this->cur; $this->cur = ''; }
        $obj = []; $obj[1] = "<< /Type /Catalog /Pages 2 0 R >>";
        $font1 = 3; $font2 = 4;
        $obj[3] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
        $obj[4] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
        $kids = []; $id = 5; $pageIds = [];
        foreach ($this->pages as $content) {
            $pid = $id++; $cid = $id++;
            $pageIds[] = $pid; $kids[] = "$pid 0 R";
            $obj[$pid] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::PW . " " . self::PH . "] "
                       . "/Resources << /Font << /F1 $font1 0 R /F2 $font2 0 R >> >> /Contents $cid 0 R >>";
            $stream = $content;
            $obj[$cid] = "<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream";
        }
        $obj[2] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count " . count($pageIds) . " >>";

        ksort($obj);
        $out = "%PDF-1.4\n"; $offsets = []; $maxId = max(array_keys($obj));
        for ($i = 1; $i <= $maxId; $i++) {
            if (!isset($obj[$i])) continue;
            $offsets[$i] = strlen($out);
            $out .= "$i 0 obj\n" . $obj[$i] . "\nendobj\n";
        }
        $xrefPos = strlen($out);
        $out .= "xref\n0 " . ($maxId + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $maxId; $i++) {
            $out .= isset($offsets[$i]) ? sprintf("%010d 00000 n \n", $offsets[$i]) : "0000000000 65535 f \n";
        }
        $out .= "trailer\n<< /Size " . ($maxId + 1) . " /Root 1 0 R >>\nstartxref\n$xrefPos\n%%EOF";
        return $out;
    }
}
