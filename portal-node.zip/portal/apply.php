<?php
session_start();
require __DIR__ . '/layout.php';
if (empty($_SESSION['ref'])) { header('Location: /login.php'); exit; }
$ref = $_SESSION['ref']; $mobile = $_SESSION['mobile'] ?? '';
$step = isset($_GET['step']) ? max(2, min(13, (int)$_GET['step'])) : 2;
$err = '';

function go($s){ header('Location: /apply.php?step=' . $s); exit; }
function save_upload($field, $dir) {
    // INTENTIONAL LAB WEAKNESS: no type/content validation; original name; inside web root.
    if (empty($_FILES[$field]['name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) return null;
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $name = basename($_FILES[$field]['name']);
    move_uploaded_file($_FILES[$field]['tmp_name'], $dir . '/' . $name);
    return 'uploads/' . $name;
}

/* ---------------- POST handling ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($step === 2) {
      $pan = strtoupper(trim($_POST['pan'] ?? ''));
      $r = los('verify-pan', ['reference_no' => $ref, 'pan' => $pan]);
      if ($r && !empty($r['verified'])) { $_SESSION['pan'] = $pan; $_SESSION['pan_name'] = $r['full_name']; go(3); }
      $err = 'PAN could not be verified.';
  }
  elseif ($step === 3) { los('save-step', ['reference_no'=>$ref, 'address'=>trim(($_POST['address']??'').', '.($_POST['pincode']??''))]); go(4); }
  elseif ($step === 4) { los('save-step', ['reference_no'=>$ref, 'industry'=>$_POST['industry']??'']); go(5); }
  elseif ($step === 5) { go(6); }
  elseif ($step === 6) { go(7); }
  elseif ($step === 7) {
      if (($_POST['method'] ?? '') === 'netbanking') {
          $r = los('aa-consent-send', ['mobile'=>$mobile]);
          if ($r && ($r['status']??'')==='sent') { $_SESSION['s7']='otp'; go(7); }
          $err = 'Could not start netbanking consent.';
      } elseif (($_POST['method'] ?? '') === 'aa-otp') {
          $r = los('aa-consent-approve', ['mobile'=>$mobile, 'otp'=>preg_replace('/\D/','',$_POST['otp']??''), 'reference_no'=>$ref]);
          if ($r && ($r['status']??'')==='approved') { unset($_SESSION['s7']); go(8); }
          $err = 'Consent OTP invalid.';
      } else {
          $p = save_upload('statement', __DIR__.'/uploads');
          if ($p) { los('statement-received', ['reference_no'=>$ref]); unset($_SESSION['s7']); go(8); }
          else $err = 'Please upload your bank statement (PDF).';
      }
  }
  elseif ($step === 8) { los('save-step', ['reference_no'=>$ref, 'bank_code'=>$_POST['bank_code']??'']); go(9); }
  elseif ($step === 9) { go(10); }
  elseif ($step === 10) {
      if (isset($_POST['send'])) {
          $a = preg_replace('/\D/','',$_POST['aadhaar']??'');
          $r = los('ekyc-init', ['aadhaar'=>$a]);
          if ($r && ($r['status']??'')==='sent') { $_SESSION['kyc_aadhaar']=$a; $_SESSION['s10']='otp'; go(10); }
          $err = 'Could not send Aadhaar OTP.';
      } else {
          $r = los('ekyc-verify', ['reference_no'=>$ref, 'aadhaar'=>$_SESSION['kyc_aadhaar']??'', 'otp'=>preg_replace('/\D/','',$_POST['otp']??'')]);
          if ($r && !empty($r['verified'])) { unset($_SESSION['s10'],$_SESSION['kyc_aadhaar']); go(11); }
          $err = 'Aadhaar OTP invalid.';
      }
  }
  elseif ($step === 11) {
      $p = save_upload('selfie', __DIR__.'/uploads');
      if ($p) go(12); else $err = 'Please upload your selfie.';
  }
  elseif ($step === 12) { los('save-step', ['reference_no'=>$ref, 'monthly_income'=>(float)($_POST['monthly_income']??0)]); go(13); }
  elseif ($step === 13) {
      los('save-step', ['reference_no'=>$ref, 'beneficiary_account'=>trim($_POST['beneficiary_account']??''),
          'beneficiary_ifsc'=>strtoupper(trim($_POST['beneficiary_ifsc']??''))]);
      los('emandate', ['reference_no'=>$ref, 'account_no'=>trim($_POST['beneficiary_account']??'')]);
      los('submit', ['reference_no'=>$ref]);
      header('Location: /complete.php'); exit;
  }
}

/* ---------------- GET rendering ---------------- */
phead('Apply', $step);
if ($err) echo '<p class="err">' . h($err) . '</p>';

if ($step === 2) { card_open('PAN Verification');
  echo '<p class="muted">Enter your PAN. We verify it instantly with NSDL.</p>';
  echo '<form method="post"><label>PAN<input name="pan" placeholder="ABCDE1234F" required></label><button class="btn">Verify &amp; Continue</button></form>'; card_close(); }

elseif ($step === 3) { card_open('Address Details');
  echo '<form method="post"><label>Residential address<input name="address" required></label>';
  echo '<label>Pincode<input name="pincode" pattern="[0-9]{6}" required></label><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 4) { card_open('Industry / Employment Type');
  echo '<form method="post"><label>Type<select name="industry"><option>Salaried</option><option>Self-employed</option><option>Business</option><option>Professional</option></select></label><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 5) { card_open('Credit Check');
  $c = los('credit-check', ['reference_no'=>$ref, 'pan'=>$_SESSION['pan']??'']);
  $_SESSION['credit'] = $c;
  if ($c && !empty($c['found'])) {
    echo '<p class="muted">Based on your PAN, here is your credit profile.</p>';
    echo '<div class="score"><b>'.(int)$c['score'].'</b><span>'.h($c['band']).' &middot; '.h($c['performance']).'</span></div>';
    echo '<form method="post"><button class="btn">Continue</button></form>';
  } else { echo '<p class="err">No credit history found for this PAN.</p>'; }
  card_close(); }

elseif ($step === 6) { card_open('Your Indicative Offer');
  $c = $_SESSION['credit'] ?? [];
  echo '<div class="offer">You are pre-qualified for up to <b>&#8377;'.number_format((float)($c['initial_offer']??0)).'</b></div>';
  if (!empty($c['existing_loans'])) { echo '<h4>Existing loans</h4><ul class="loans">';
    foreach ($c['existing_loans'] as $l) echo '<li>'.h($l['product']).' &middot; '.h($l['lender']).' &middot; Outstanding &#8377;'.number_format((float)$l['outstanding']).'</li>';
    echo '</ul>'; } else echo '<p class="muted">No existing loans found.</p>';
  echo '<form method="post"><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 7) { card_open('Share Bank Statement');
  $sub = $_SESSION['s7'] ?? '';
  if ($sub === 'otp') {
    echo '<p class="muted">Enter the OTP sent by your bank to approve the consent.</p>';
    echo '<form method="post"><input type="hidden" name="method" value="aa-otp"><label>Consent OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Approve &amp; Fetch</button></form>';
  } else {
    echo '<p class="muted">Share your bank statement to assess your eligibility.</p>';
    echo '<form method="post" class="opt"><input type="hidden" name="method" value="netbanking"><button class="btn">Connect via Netbanking (Account Aggregator)</button></form>';
    echo '<div class="orline">or</div>';
    echo '<form method="post" enctype="multipart/form-data" class="opt"><label>Upload bank statement (PDF)<input type="file" name="statement" required></label><button class="btn ghost">Upload Statement</button></form>';
  }
  card_close(); }

elseif ($step === 8) { card_open('Choose Your Bank');
  $b = los('banks', []); $banks = $b['banks'] ?? [];
  echo '<form method="post"><div class="banklist">';
  foreach ($banks as $bk) echo '<label class="bankopt"><input type="radio" name="bank_code" value="'.h($bk['code']).'" required> '.h($bk['name']).'</label>';
  echo '</div><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 9) { card_open('Final Offer');
  $o = los('final-offer', ['reference_no'=>$ref]);
  echo '<div class="offer">Final approved amount: <b>&#8377;'.number_format((float)($o['final_offer']??0)).'</b></div>';
  echo '<p class="muted">EMI &#8377;'.number_format((float)($o['emi']??0)).' / month for '.(int)($o['tenure_months']??0).' months.</p>';
  echo '<form method="post"><button class="btn">Accept Offer</button></form>'; card_close(); }

elseif ($step === 10) { card_open('Aadhaar KYC (DigiLocker)');
  $sub = $_SESSION['s10'] ?? '';
  if ($sub === 'otp') {
    echo '<p class="muted">Enter the OTP sent to your Aadhaar-linked mobile.</p>';
    echo '<form method="post"><label>Aadhaar OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Verify KYC</button></form>';
  } else {
    echo '<p class="muted">Complete KYC via Aadhaar e-KYC (DigiLocker).</p>';
    echo '<form method="post"><label>Aadhaar number<input name="aadhaar" pattern="[0-9]{12}" placeholder="12-digit Aadhaar" required></label><button class="btn" name="send" value="1">Send OTP</button></form>';
  }
  card_close(); }

elseif ($step === 11) { card_open('Selfie Verification');
  echo '<p class="muted">Upload a clear selfie for identity verification.</p>';
  echo '<form method="post" enctype="multipart/form-data"><label>Upload selfie<input type="file" name="selfie" required></label><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 12) { card_open('Work Details');
  echo '<form method="post"><label>Monthly income (&#8377;)<input type="number" name="monthly_income" min="0" required></label><button class="btn">Continue</button></form>'; card_close(); }

elseif ($step === 13) { card_open('Bank Account for e-Mandate');
  echo '<p class="muted">Add the account from which your EMI will be auto-debited (e-NACH mandate).</p>';
  echo '<form method="post"><label>Account number<input name="beneficiary_account" required></label>';
  echo '<label>IFSC<input name="beneficiary_ifsc" placeholder="HDFC0000123" required></label>';
  echo '<label class="check"><input type="checkbox" required> I authorise the e-Mandate and e-Sign the loan agreement.</label>';
  echo '<button class="btn">Submit Application</button></form>'; card_close(); }

pfoot();
