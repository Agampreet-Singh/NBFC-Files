<?php
// LOS DB (SQLite) — loan applications (system of record). LAB only.
function ldb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/los.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS applications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reference_no TEXT UNIQUE,
            full_name TEXT, mobile TEXT,
            pan TEXT, pan_verified INTEGER DEFAULT 0,
            aadhaar_last4 TEXT, address TEXT, kyc_verified INTEGER DEFAULT 0,
            credit_score INTEGER, credit_band TEXT, credit_performance TEXT,
            industry TEXT, monthly_income REAL,
            requested_amount REAL, initial_offer REAL, final_offer REAL,
            tenure_months INTEGER, emi REAL,
            bank_code TEXT, beneficiary_account TEXT, beneficiary_ifsc TEXT,
            status TEXT DEFAULT 'DRAFT',   -- DRAFT/PENDING/APPROVED/DISBURSED/REJECTED
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        )");
        seed($pdo);
    }
    return $pdo;
}

function seed($pdo) {
    if ((int)$pdo->query("SELECT COUNT(*) c FROM applications")->fetch()['c'] > 0) return;
    $rows = [
        ['FC261125AA01','Rajesh Kumar','9812345678','ABCDE1234F',1,'5678','12 MG Road, New Delhi 110001',1,780,'Excellent','Good','Salaried',95000,300000,300000,250000,24,11800,'HDFC','50100012345678','HDFC0000123','APPROVED'],
        ['FC261125AA02','Priya Sharma','9820011122','PQRSX5678L',1,'6789','45 FC Road, Pune 411004',1,720,'Good','Good','Salaried',70000,200000,200000,170000,18,10900,'PUNB','001122334455','PUNB0000456','APPROVED'],
        ['FC261125AA03','Amit Verma','9833044455','LMNOP9012Q',1,'7890','7 Park Street, Kolkata 700016',0,650,'Fair','Average','Self-employed',55000,150000,150000,null,12,null,'BARB','30011223344','BARB0000789','PENDING'],
        ['FC261125AA04','Sneha Patel','9844055566','FGHIJ3456M',1,'8901','88 CG Road, Ahmedabad 380009',1,810,'Excellent','Good','Salaried',120000,400000,400000,360000,36,12400,'SBIN','918000123456','SBIN0000111','DISBURSED'],
        ['FC261125AA05','Vikram Singh','9855066677','TUVWX7890R',1,'9012','22 Mall Road, Jaipur 302001',1,590,'Poor','Weak','Business',40000,100000,0,0,0,0,'ICIC','147500987654','ICIC0000222','REJECTED'],
    ];
    $cols = "reference_no,full_name,mobile,pan,pan_verified,aadhaar_last4,address,kyc_verified,credit_score,credit_band,credit_performance,industry,monthly_income,requested_amount,initial_offer,final_offer,tenure_months,emi,bank_code,beneficiary_account,beneficiary_ifsc,status";
    $ph = implode(',', array_fill(0, 22, '?'));
    $st = $pdo->prepare("INSERT INTO applications($cols) VALUES($ph)");
    foreach ($rows as $r) $st->execute($r);
}
