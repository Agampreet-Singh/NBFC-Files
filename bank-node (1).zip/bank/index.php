<?php
// Bank Server console (read-only) — view accounts & payouts. LAB only.
session_start();
require __DIR__ . '/db.php';
$USER = 'bankadmin'; $PASS = 'changeme';

if (isset($_GET['logout'])) { unset($_SESSION['bank']); header('Location: /index.php'); exit; }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    if (($_POST['u'] ?? '') === $USER && ($_POST['p'] ?? '') === $PASS) $_SESSION['bank'] = true;
    else $err = 'Invalid credentials';
}
function bh($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }
$pdo = bdb();
?><!DOCTYPE html><html><head><meta charset="utf-8"><title>Bank Core Console</title>
<style>
body{font-family:system-ui,Arial,sans-serif;background:#0e1726;color:#e6edf6;margin:0}
.wrap{max-width:1000px;margin:0 auto;padding:24px}
.nav{background:#13203a;border-bottom:2px solid #1f3a66;padding:14px 0}
.nav .wrap{display:flex;justify-content:space-between;align-items:center;padding:0 24px}
.brand{font-weight:800;color:#5aa0ff}
h2{color:#9bc0ff}
table{width:100%;border-collapse:collapse;margin:10px 0 26px}
th,td{text-align:left;padding:9px 10px;border-bottom:1px solid #22314f;font-size:14px}
th{color:#8aa6d6}
.mule{color:#ff7a7a;font-weight:700}
.ok{color:#5ad18a}.fail{color:#ff7a7a}
input{padding:9px;border-radius:7px;border:1px solid #2a3b5c;background:#0e1726;color:#e6edf6}
.btn{background:#2563eb;color:#fff;border:0;padding:9px 16px;border-radius:7px;cursor:pointer}
.card{background:#13203a;border:1px solid #1f3a66;border-radius:12px;padding:20px;max-width:360px}
a{color:#8aa6d6}
</style></head><body>
<div class="nav"><div class="wrap"><span class="brand">&#127974; Bank Core Console</span>
<?php if(!empty($_SESSION['bank'])) echo '<a href="/index.php?logout=1">Logout</a>'; ?></div></div>
<div class="wrap">
<?php if (empty($_SESSION['bank'])): ?>
  <div class="card"><h2>Sign in</h2>
  <?php if(!empty($err)) echo '<p class="fail">'.bh($err).'</p>'; ?>
  <form method="post">
    <p><input name="u" placeholder="username" required></p>
    <p><input type="password" name="p" placeholder="password" required></p>
    <button class="btn" name="login" value="1">Sign in</button>
  </form></div>
<?php else:
  $accts = $pdo->query("SELECT a.*, b.name bank FROM accounts a LEFT JOIN banks b ON a.bank_code=b.code ORDER BY is_mule, holder_name")->fetchAll();
  $pays  = $pdo->query("SELECT * FROM payouts ORDER BY id DESC LIMIT 25")->fetchAll();
?>
  <h2>Accounts</h2>
  <table><tr><th>Holder</th><th>Bank</th><th>Account</th><th>IFSC</th><th>Type</th><th>Balance</th></tr>
  <?php foreach($accts as $a): ?>
    <tr><td><?= bh($a['holder_name']) ?><?= $a['is_mule']?' <span class="mule">(flagged)</span>':'' ?></td>
    <td><?= bh($a['bank']) ?></td><td><?= bh($a['account_no']) ?></td><td><?= bh($a['ifsc']) ?></td>
    <td><?= bh($a['acc_type']) ?></td><td>&#8377;<?= number_format((float)$a['balance']) ?></td></tr>
  <?php endforeach; ?></table>

  <h2>Recent payouts</h2>
  <table><tr><th>UTR</th><th>Source IP</th><th>Beneficiary A/C</th><th>Amount</th><th>Reference</th><th>Status</th><th>Time</th></tr>
  <?php if(!$pays): ?><tr><td colspan="7" style="color:#6b7f9e">No payouts yet.</td></tr><?php endif; ?>
  <?php foreach($pays as $p): ?>
    <tr><td><?= bh($p['utr']) ?></td><td><?= bh($p['source_ip']) ?></td><td><?= bh($p['beneficiary_account']) ?></td>
    <td>&#8377;<?= number_format((float)$p['amount']) ?></td><td><?= bh($p['reference']) ?></td>
    <td class="<?= $p['status']==='SUCCESS'?'ok':'fail' ?>"><?= bh($p['status']) ?></td><td><?= bh($p['created_at']) ?></td></tr>
  <?php endforeach; ?></table>
<?php endif; ?>
</div></body></html>
