<?php
session_start();
require __DIR__ . '/layout.php';
$ref = $_SESSION['ref'] ?? '';
session_destroy();
phead('Submitted');
card_open('Application Submitted');
?>
<div class="tick-big">&#10003;</div>
<p>Your loan application has been submitted and is now under review.</p>
<?php if ($ref): ?><p class="refbox">Reference: <b><?= h($ref) ?></b></p><?php endif; ?>
<p class="muted">Our team will review your application and notify you on your registered mobile number.</p>
<a class="btn" href="/index.php">Done</a>
<?php card_close(); pfoot();
