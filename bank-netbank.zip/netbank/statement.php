<?php
session_start();
require __DIR__ . '/config.php';
require __DIR__ . '/pdf.php';
$BANK = bank_code();
[$bname, $colorHex] = bank_meta();
$pdo = pdo_bank();

// Who may download which account?
$acc = '';
if (!empty($_SESSION['cust_' . $BANK])) {
    $acc = $_SESSION['cust_' . $BANK];                       // customer: own account
} elseif (!empty($_SESSION['mgr_' . $BANK]) && isset($_GET['acc'])) {
    $acc = preg_replace('/\s+/', '', $_GET['acc']);          // manager: any account in this bank
} else {
    header('Location: /customer.php'); exit;
}

$st = $pdo->prepare("SELECT * FROM accounts WHERE account_no=? AND bank_code=?");
$st->execute([$acc, $BANK]); $a = $st->fetch(PDO::FETCH_ASSOC);
if (!$a) { http_response_code(404); exit('Account not found'); }
$tx = $pdo->prepare("SELECT * FROM transactions WHERE account_no=? ORDER BY id ASC");
$tx->execute([$acc]); $rows = $tx->fetchAll(PDO::FETCH_ASSOC);

// hex -> rgb
$c = sscanf($colorHex, "#%02x%02x%02x"); $rgb = [$c[0] ?? 6, $c[1] ?? 64, $c[2] ?? 43];

$pdf = new SimplePDF();
$W = SimplePDF::PW;
function header_band($pdf, $rgb, $bname, $W) {
    $pdf->fillRect(0, SimplePDF::PH - 70, $W, 70, $rgb);
    $pdf->text(40, SimplePDF::PH - 42, $bname, 17, true, [255, 255, 255]);
    $pdf->text(40, SimplePDF::PH - 60, 'Account Statement', 10, false, [235, 235, 235]);
    $pdf->setY(SimplePDF::PH - 95);
}
header_band($pdf, $rgb, $bname, $W);

$y = $pdf->y();
$pdf->text(40, $y, 'Account Holder: ' . $a['holder_name'], 10, true);
$pdf->text(330, $y, 'Account No: ' . $a['account_no'], 10, true); $y -= 16;
$pdf->text(40, $y, 'IFSC: ' . $a['ifsc'], 10);
$pdf->text(330, $y, 'Type: ' . $a['acc_type'], 10); $y -= 16;
$pdf->text(40, $y, 'Balance: INR ' . number_format($a['balance'], 2), 10, true);
$pdf->text(330, $y, 'Generated: ' . date('Y-m-d H:i'), 9); $y -= 22;

// table header
function tbl_header($pdf, &$y, $rgb) {
    $pdf->fillRect(40, $y - 4, SimplePDF::PW - 80, 20, [241, 244, 248]);
    $pdf->text(46, $y, 'Date', 9, true); $pdf->text(120, $y, 'Description', 9, true);
    $pdf->text(360, $y, 'Debit', 9, true); $pdf->text(430, $y, 'Credit', 9, true); $pdf->text(500, $y, 'Balance', 9, true);
    $y -= 20;
}
tbl_header($pdf, $y, $rgb);

foreach ($rows as $t) {
    if ($y < 70) { $pdf->addPage(); header_band($pdf, $rgb, $bname, $W); $y = $pdf->y(); tbl_header($pdf, $y, $rgb); }
    $desc = substr($t['description'], 0, 40);
    $pdf->text(46, $y, $t['txn_date'], 9);
    $pdf->text(120, $y, $desc, 9);
    if ($t['dr_cr'] === 'DR') $pdf->text(360, $y, number_format($t['amount'], 2), 9);
    if ($t['dr_cr'] === 'CR') $pdf->text(430, $y, number_format($t['amount'], 2), 9);
    $pdf->text(500, $y, number_format($t['balance_after'], 2), 9);
    $y -= 15;
    $pdf->line(40, $y + 4, $W - 40, $y + 4, 0.3, 0.9);
}
if (!$rows) { $pdf->text(46, $y, 'No transactions on record.', 9); }

$data = $pdf->output();
$fname = $BANK . '_Statement_' . substr($acc, -4) . '.pdf';
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $fname . '"');
header('Content-Length: ' . strlen($data));
echo $data;
