<?php
// NSDL node API — PAN verification. Called by the LOS node (server-to-server).
//   ?action=verify   POST pan   -> validates PAN format + registry lookup
// LAB / isolated range only.

require __DIR__ . '/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';
$pdo = ndb();

if ($action === 'verify') {
    $pan = strtoupper(trim($_POST['pan'] ?? ''));

    // PAN format: 5 letters, 4 digits, 1 letter
    if (!preg_match('/^[A-Z]{5}[0-9]{4}[A-Z]$/', $pan)) {
        echo json_encode(['valid' => false, 'reason' => 'invalid_format']);
        exit;
    }

    $st = $pdo->prepare("SELECT pan, full_name, dob, status FROM pan_records WHERE pan = ?");
    $st->execute([$pan]);
    $row = $st->fetch();

    if (!$row) {
        echo json_encode(['valid' => false, 'reason' => 'not_found']);
        exit;
    }
    if ($row['status'] !== 'VALID') {
        echo json_encode(['valid' => false, 'reason' => 'inactive']);
        exit;
    }

    echo json_encode([
        'valid'     => true,
        'pan'       => $row['pan'],
        'full_name' => $row['full_name'],
        'dob'       => $row['dob'],
    ]);
    exit;
}

echo json_encode(['status' => 'ok', 'service' => 'nsdl-pan-verification']);
