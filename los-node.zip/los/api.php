<?php
// LOS orchestration API — called by the FinanceCorp portal (and the Disburse node).
// LOS validates each step against the service nodes and is the loan system of record.
// LAB / isolated range only.

require __DIR__ . '/config.php';
require __DIR__ . '/db.php';
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? '';
$pdo = ldb();

function app_by_ref($pdo, $ref) {
    $s = $pdo->prepare("SELECT * FROM applications WHERE reference_no=?"); $s->execute([$ref]); return $s->fetch();
}
function touch_app($pdo, $ref, $fields) {
    $set = implode(',', array_map(fn($k) => "$k=?", array_keys($fields)));
    $vals = array_values($fields); $vals[] = $ref;
    $pdo->prepare("UPDATE applications SET $set, updated_at=datetime('now') WHERE reference_no=?")->execute($vals);
}

/* ---------- application lifecycle ---------- */
if ($action === 'create-application') {
    $mobile = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
    $ref = 'FC' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
    $pdo->prepare("INSERT INTO applications(reference_no, mobile, status) VALUES(?,?, 'DRAFT')")->execute([$ref, $mobile]);
    echo json_encode(['reference_no' => $ref]); exit;
}

/* ---------- step 1: login OTP (proxy to Telecom) ---------- */
if ($action === 'otp-send') {
    echo json_encode(http_post(TELECOM_URL, 'send', ['mobile' => preg_replace('/\D/','',$_POST['mobile'] ?? ''), 'service' => 'FinanceCorp'])
        ?: ['status' => 'error', 'reason' => 'telecom_unreachable']); exit;
}
if ($action === 'otp-verify') {
    echo json_encode(http_post(TELECOM_URL, 'verify', ['mobile' => preg_replace('/\D/','',$_POST['mobile'] ?? ''), 'otp' => preg_replace('/\D/','',$_POST['otp'] ?? '')])
        ?: ['valid' => false, 'reason' => 'telecom_unreachable']); exit;
}

/* ---------- step 2: PAN via NSDL ---------- */
if ($action === 'verify-pan') {
    $ref = $_POST['reference_no'] ?? ''; $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $r = http_post(NSDL_URL, 'verify', ['pan' => $pan]);
    if ($r && !empty($r['valid'])) {
        touch_app($pdo, $ref, ['pan' => $pan, 'full_name' => $r['full_name'], 'pan_verified' => 1]);
        echo json_encode(['verified' => true, 'full_name' => $r['full_name'], 'dob' => $r['dob'] ?? '']);
    } else {
        echo json_encode(['verified' => false, 'reason' => $r['reason'] ?? 'nsdl_unreachable']);
    }
    exit;
}

/* ---------- step 10: Aadhaar e-KYC via DigiLocker ---------- */
if ($action === 'ekyc-init') {
    $r = http_post(DIGILOCKER_URL, 'ekyc-send', ['aadhaar' => preg_replace('/\D/', '', $_POST['aadhaar'] ?? '')]);
    echo json_encode($r ?: ['status' => 'error', 'reason' => 'digilocker_unreachable']); exit;
}
if ($action === 'ekyc-verify') {
    $ref = $_POST['reference_no'] ?? '';
    $a   = preg_replace('/\D/', '', $_POST['aadhaar'] ?? '');
    $r = http_post(DIGILOCKER_URL, 'ekyc-verify', ['aadhaar' => $a, 'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]);
    if ($r && !empty($r['valid'])) {
        touch_app($pdo, $ref, ['aadhaar_last4' => substr($a, -4), 'address' => $r['address'], 'kyc_verified' => 1]);
        echo json_encode(['verified' => true, 'full_name' => $r['full_name'], 'address' => $r['address']]);
    } else {
        echo json_encode(['verified' => false, 'reason' => $r['reason'] ?? 'otp_invalid']);
    }
    exit;
}

/* ---------- step 5/6: credit score + existing loans via Bank, compute initial offer ---------- */
if ($action === 'credit-check') {
    $ref = $_POST['reference_no'] ?? ''; $pan = strtoupper(trim($_POST['pan'] ?? ''));
    $c = http_post(BANK_URL, 'credit-score', ['pan' => $pan]);
    $loans = http_post(BANK_URL, 'existing-loans', ['pan' => $pan]);
    if (!$c || empty($c['found'])) { echo json_encode(['found' => false, 'reason' => 'no_credit_history']); exit; }
    $score = (int)$c['score'];
    // initial offer by score band (PAN-driven)
    $initial = $score >= 800 ? 500000 : ($score >= 750 ? 400000 : ($score >= 700 ? 300000 : ($score >= 650 ? 150000 : 0)));
    touch_app($pdo, $ref, ['pan' => $pan, 'credit_score' => $score, 'credit_band' => $c['band'],
        'credit_performance' => $c['performance'], 'initial_offer' => $initial]);
    echo json_encode(['found' => true, 'score' => $score, 'band' => $c['band'],
        'performance' => $c['performance'], 'initial_offer' => $initial, 'existing_loans' => $loans['loans'] ?? []]);
    exit;
}

/* ---------- step 7: bank statement via Account Aggregator ---------- */
if ($action === 'aa-consent-send') {
    echo json_encode(http_post(AA_URL, 'consent-send', ['mobile' => preg_replace('/\D/', '', $_POST['mobile'] ?? '')])
        ?: ['status' => 'error', 'reason' => 'aa_unreachable']); exit;
}
if ($action === 'aa-consent-approve') {
    echo json_encode(http_post(AA_URL, 'consent-approve', [
        'mobile' => preg_replace('/\D/', '', $_POST['mobile'] ?? ''),
        'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]) ?: ['status' => 'error', 'reason' => 'aa_unreachable']); exit;
}

/* ---------- step 8: list banks ---------- */
if ($action === 'banks') { echo json_encode(http_post(BANK_URL, 'banks', []) ?: ['banks' => []]); exit; }

/* ---------- generic step save (address, industry, income, bank, beneficiary, tenure) ---------- */
if ($action === 'save-step') {
    $ref = $_POST['reference_no'] ?? '';
    $allowed = ['address','industry','monthly_income','requested_amount','bank_code','beneficiary_account','beneficiary_ifsc','tenure_months'];
    $f = [];
    foreach ($allowed as $k) if (isset($_POST[$k]) && $_POST[$k] !== '') $f[$k] = $_POST[$k];
    if ($f) touch_app($pdo, $ref, $f);
    echo json_encode(['saved' => true]); exit;
}

/* ---------- step 9: final offer (lower than initial — bank strategy) ---------- */
if ($action === 'final-offer') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    if (!$app) { echo json_encode(['error' => 'not_found']); exit; }
    $initial = (float)$app['initial_offer'];
    $req = (float)$app['requested_amount'];
    $base = $req > 0 ? min($req, $initial) : $initial;
    $final = round($base * 0.85 / 1000) * 1000;   // 15% lower; bank retention strategy
    $tenure = (int)($app['tenure_months'] ?: 12);
    $emi = $tenure > 0 ? round(($final * (1 + 0.016 * $tenure)) / $tenure) : 0;
    touch_app($pdo, $ref, ['final_offer' => $final, 'emi' => $emi, 'tenure_months' => $tenure]);
    echo json_encode(['initial_offer' => $initial, 'final_offer' => $final, 'tenure_months' => $tenure, 'emi' => $emi]); exit;
}

/* ---------- step 13: e-mandate via Bank ---------- */
if ($action === 'emandate') {
    $ref = $_POST['reference_no'] ?? ''; $app = app_by_ref($pdo, $ref);
    $r = http_post(BANK_URL, 'emandate-register', [
        'account_no' => $_POST['account_no'] ?? ($app['beneficiary_account'] ?? ''),
        'amount' => $app['emi'] ?? 0, 'ref' => $ref]);
    echo json_encode($r ?: ['status' => 'error', 'reason' => 'bank_unreachable']); exit;
}

/* ---------- submit for review ---------- */
if ($action === 'submit') {
    $ref = $_POST['reference_no'] ?? '';
    touch_app($pdo, $ref, ['status' => 'PENDING']);
    echo json_encode(['status' => 'PENDING', 'reference_no' => $ref]); exit;
}

/* ---------- disbursal queue (read by the Disburse node) ---------- */
if ($action === 'disbursal-queue') {
    $rows = $pdo->query("SELECT reference_no, full_name, final_offer, bank_code, beneficiary_account, beneficiary_ifsc
                         FROM applications WHERE status='APPROVED' ORDER BY updated_at")->fetchAll();
    echo json_encode(['queue' => $rows]); exit;
}
if ($action === 'mark-disbursed') {
    $ref = $_POST['reference_no'] ?? '';
    touch_app($pdo, $ref, ['status' => 'DISBURSED']);
    $app = app_by_ref($pdo, $ref);
    if ($app) add_loan_from_app($pdo, $app);   // real loan enters the book
    echo json_encode(['status' => 'DISBURSED']); exit;
}

echo json_encode(['status' => 'ok', 'service' => 'los-orchestrator']);
