<?php
session_start();
require __DIR__ . '/layout.php';
[$name, $color, $brand] = bank_meta();
$BANK = bank_code();
$pdo = pdo_bank();
$err = ''; $info = ''; $tab = 'c';
if (isset($_GET['reset'])) { unset($_SESSION['pending_acc'], $_SESSION['pending_mob']); header('Location: /index.php#login'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send'])) {                        // customer: request OTP
        $acc = preg_replace('/\s+/', '', $_POST['account_no'] ?? '');
        $st = $pdo->prepare("SELECT * FROM accounts WHERE account_no=? AND bank_code=?"); $st->execute([$acc, $BANK]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) $err = 'No such account in ' . $name . '.';
        else {
            $r = tele_post('send', ['mobile' => $row['mobile'], 'service' => $BANK . ' NetBank']);
            if ($r && ($r['status'] ?? '') === 'sent') { $_SESSION['pending_acc'] = $acc; $_SESSION['pending_mob'] = $row['mobile']; $info = 'OTP sent to your registered mobile.'; }
            else $err = 'Could not send OTP. Try again.';
        }
    } elseif (isset($_POST['verify'])) {                // customer: verify OTP
        $r = tele_post('verify', ['mobile' => $_SESSION['pending_mob'] ?? '', 'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]);
        if ($r && !empty($r['valid'])) { $_SESSION['cust_' . $BANK] = $_SESSION['pending_acc']; unset($_SESSION['pending_acc'], $_SESSION['pending_mob']); header('Location: /customer.php'); exit; }
        $err = 'Invalid or expired OTP.';
    } elseif (isset($_POST['mlogin'])) {                // manager login
        $tab = 'm';
        if (($_POST['username'] ?? '') === MANAGER_USER && ($_POST['password'] ?? '') === MANAGER_PASS) { $_SESSION['mgr_' . $BANK] = 1; header('Location: /manager.php'); exit; }
        $err = 'Invalid manager credentials.';
    }
}
$otpStep = !empty($_SESSION['pending_acc']);

site_head();
?>
<section class="hero" id="personal">
  <div class="hero-in">
    <div>
      <h1>Banking made simple,<br>secure &amp; instant.</h1>
      <p>Manage your accounts, check balances, download statements and more — anytime, anywhere with <?= h($brand) ?>.</p>
      <div class="hero-btns"><a class="btn-w" href="#login">NetBanking Login</a><a class="btn-o" href="#loans">Explore Loans</a></div>
      <div class="trust"><div><b>24x7</b>Digital Banking</div><div><b>7</b>Core Products</div><div><b>100%</b>Secure</div></div>
    </div>
    <div class="login-card" id="login">
      <input type="radio" name="tab" id="tc" <?= $tab==='c'?'checked':'' ?>><input type="radio" name="tab" id="tm" <?= $tab==='m'?'checked':'' ?>>
      <h3>NetBanking Login</h3><p class="sub"><?= h($name) ?> secure sign in</p>
      <div class="tabs"><label for="tc">Customer</label><label for="tm">Manager</label></div>
      <?php if ($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>
      <?php if ($info): ?><div class="ok"><?= h($info) ?></div><?php endif; ?>
      <div class="pane" id="pane-c">
        <?php if (!$otpStep): ?>
          <form method="post"><label class="fl">Account Number</label><input class="in" name="account_no" inputmode="numeric" placeholder="Your <?= h($name) ?> account number" required>
          <button class="btn" name="send" value="1">Get OTP</button></form>
          <p class="hint">An OTP will be sent to your registered mobile.</p>
        <?php else: ?>
          <form method="post"><label class="fl">Enter OTP</label><input class="in" name="otp" pattern="[0-9]{6}" placeholder="6-digit OTP" required autofocus>
          <button class="btn" name="verify" value="1">Secure Login</button></form>
          <p class="hint">Sent to <?= h(substr($_SESSION['pending_mob'],0,2)).'XXXXX'.h(substr($_SESSION['pending_mob'],-2)) ?> · <a class="link" href="/index.php?reset=1">Change account</a></p>
        <?php endif; ?>
      </div>
      <div class="pane" id="pane-m">
        <form method="post"><label class="fl">Manager Username</label><input class="in" name="username" placeholder="manager" required>
        <label class="fl">Password</label><input class="in" type="password" name="password" required>
        <button class="btn" name="mlogin" value="1">Sign In</button></form>
        <p class="hint">Branch manager access only.</p>
      </div>
    </div>
  </div>
</section>

<section class="sec" id="loans">
  <h2>Products for every need</h2><p class="lead">Simple, transparent and designed around you.</p>
  <div class="prod">
    <div class="pcard"><div class="pic"><?= icon('cash') ?></div><h4>Savings Account</h4><p>Zero-balance digital savings with instant NetBanking.</p></div>
    <div class="pcard" id="cards"><div class="pic"><?= icon('card') ?></div><h4>Cards</h4><p>Debit &amp; credit cards with rewards and secure payments.</p></div>
    <div class="pcard"><div class="pic"><?= icon('bank') ?></div><h4>Personal Loans</h4><p>Quick loans at competitive rates, minimal paperwork.</p></div>
    <div class="pcard"><div class="pic"><?= icon('bolt') ?></div><h4>Instant Transfers</h4><p>NEFT, IMPS &amp; UPI — money moves in seconds.</p></div>
  </div>
</section>

<section class="strip"><div class="sec" id="about"><div class="stripg">
  <div><b>5M+</b><span>Happy customers</span></div>
  <div><b>₹40,000 Cr</b><span>Deposits managed</span></div>
  <div><b>1,200+</b><span>Branches &amp; ATMs</span></div>
</div></div></section>
<?php site_foot();
