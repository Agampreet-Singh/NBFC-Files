<?php
require_once __DIR__ . '/config.php';

function step_labels() {
    return [1=>'Mobile',2=>'Loan',3=>'Personal',4=>'PAN',5=>'Address',6=>'Employment',7=>'Credit',
            8=>'Offer',9=>'Statement',10=>'Bank',11=>'Final Offer',12=>'KYC',13=>'Selfie',
            14=>'Company',15=>'e-Mandate'];
}
function LAST_STEP() { return 15; }

/* Phases group the journey into the big boxes shown at the top. */
function phases() {
    return [
        ['Your Loan',     [2]],
        ['Personal Info', [3,4,5]],
        ['Eligibility',   [6,7,8]],
        ['Banking',       [9,10,11]],
        ['KYC',           [12,13]],
        ['Finalize',      [14,15]],
    ];
}

/* Context shown in the left panel for each step: [title, description, [bullets]]. */
function step_info($step) {
    $m = [
        2  => ['Loan Requirement', 'How much do you need, and for how long? Slide to choose.', ['Instant indicative pricing', 'No impact on your credit score']],
        3  => ['Personal Details', 'Tell us a little about yourself so we can set up your profile.', ['Matches your official records', 'Takes under a minute']],
        4  => ['PAN Verification', 'We verify your PAN instantly and match it against your details.', ['Instant verification', 'Bank-grade encryption']],
        5  => ['Address Details', 'Where do you currently reside?', ['Used for correspondence', 'Affects serviceability']],
        6  => ['Employment Type', 'How do you primarily earn your income?', ['Helps assess eligibility']],
        7  => ['Credit Assessment', 'We securely assess your credit profile.', ['Soft check — no score impact', 'RBI-compliant bureau pull']],
        8  => ['Your Offer', 'Adjust your amount and tenure — EMI updates instantly.', ['Flexible amount & tenure', 'Transparent interest rate']],
        9  => ['Bank Statement', 'Share your statement so we can assess repayment capacity.', ['Secure Account Aggregator', 'Or upload a PDF']],
        10 => ['Your Bank Account', 'Confirm the account linked to your mobile number.', ['Used for disbursal & EMIs']],
        11 => ['Final Offer', 'Your final, locked-in loan terms.', ['Reviewed & approved', 'Accept to continue']],
        12 => ['Aadhaar KYC', 'Complete e-KYC via DigiLocker.', ['RBI-compliant', 'OTP based']],
        13 => ['Selfie Verification', 'A quick photo to confirm it is really you.', ['Liveness & identity check']],
        14 => ['Employment & Company Details', 'Tell us about where you work.', ['Employer details', 'Income assessment']],
        15 => ['Bank Account & e-Mandate', 'Set up auto-debit for your monthly EMIs.', ['e-NACH mandate', 'e-Sign loan agreement']],
    ];
    return $m[$step] ?? ['FinanceCorp', '', []];
}

/* ===== Celebration: rising balloons + confetti burst (vanilla, no libs) ===== */
function celebration_js() {
    echo '<script>(function(){'
        .'var colors=["#22c55e","#16a34a","#06402b","#f59e0b","#ef4444","#3b82f6","#ec4899"];'
        .'var W=window.innerWidth;'
        // balloons
        .'for(var i=0;i<14;i++){(function(i){var b=document.createElement("div");b.className="balloon";'
        .'b.style.left=(Math.random()*95)+"vw";b.style.background=colors[i%colors.length];'
        .'b.style.animationDuration=(3.2+Math.random()*2.2)+"s";b.style.animationDelay=(Math.random()*0.6)+"s";'
        .'document.body.appendChild(b);setTimeout(function(){b.remove();},7000);})(i);}'
        // confetti
        .'for(var j=0;j<70;j++){var c=document.createElement("div");c.className="confetti";'
        .'c.style.left=(Math.random()*100)+"vw";c.style.background=colors[j%colors.length];'
        .'c.style.animationDuration=(2.4+Math.random()*2)+"s";c.style.animationDelay=(Math.random()*0.5)+"s";'
        .'c.style.transform="rotate("+(Math.random()*360)+"deg)";document.body.appendChild(c);'
        .'(function(c){setTimeout(function(){c.remove();},6000);})(c);}'
        .'})();</script>';
}

/* ===== Loan slider: shared UI + JS (ROI/EMI mirrors los/config.php) ===== */
function loan_slider_ui($amtMin, $amtMax, $amtDef, $tenDef, $submitLabel) {
    $f = fn($n) => '&#8377;' . number_format($n);
    echo '<form method="post" class="loanform">';
    echo '<div class="lf-row"><label>Loan amount</label><span class="lf-val" id="amtOut"></span></div>';
    echo '<input type="range" class="slider" id="amt" min="'.$amtMin.'" max="'.$amtMax.'" step="10000" value="'.$amtDef.'">';
    echo '<div class="lf-minmax"><span>'.$f($amtMin).'</span><span>'.$f($amtMax).'</span></div>';
    echo '<div class="lf-row" style="margin-top:20px"><label>Tenure</label><span class="lf-val" id="tenOut"></span></div>';
    echo '<input type="range" class="slider" id="ten" min="12" max="60" step="6" value="'.$tenDef.'">';
    echo '<div class="lf-minmax"><span>12 months</span><span>60 months</span></div>';
    echo '<div class="loan-summary"><div class="ls-item"><span>Interest Rate</span><b id="roiOut"></b></div>'
        .'<div class="ls-item"><span>Monthly EMI</span><b id="emiOut"></b></div></div>';
    echo '<input type="hidden" name="requested_amount" id="f_amt"><input type="hidden" name="tenure_months" id="f_ten">';
    echo '<input type="hidden" name="roi" id="f_roi"><input type="hidden" name="emi" id="f_emi">';
    echo '<button class="btn">'.h($submitLabel).'</button></form>';
    echo '<script>(function(){'
        .'function roiFor(a){a=+a;if(a<=100000)return 15.0;if(a<=300000)return 13.5;if(a<=500000)return 12.0;return 11.0;}'
        .'function emiFor(p,ann,n){p=+p;n=+n;if(n<=0)return 0;var r=ann/1200;if(r<=0)return Math.round(p/n);var f=Math.pow(1+r,n);return Math.round(p*r*f/(f-1));}'
        .'function inr(x){return "₹"+Math.round(x).toLocaleString("en-IN");}'
        .'var amt=document.getElementById("amt"),ten=document.getElementById("ten");'
        .'function upd(){var a=+amt.value,n=+ten.value,roi=roiFor(a),emi=emiFor(a,roi,n);'
        .'document.getElementById("amtOut").textContent=inr(a);'
        .'document.getElementById("tenOut").textContent=n+" months";'
        .'document.getElementById("roiOut").textContent=roi.toFixed(1)+"% p.a.";'
        .'document.getElementById("emiOut").textContent=inr(emi)+" / mo";'
        .'document.getElementById("f_amt").value=a;document.getElementById("f_ten").value=n;'
        .'document.getElementById("f_roi").value=roi;document.getElementById("f_emi").value=emi;}'
        .'amt.addEventListener("input",upd);ten.addEventListener("input",upd);upd();'
        .'})();</script>';
}

function render_stepper($step) {
    $labels = step_labels();
    echo '<div class="stepper"><div class="stepper-track">';
    foreach ($labels as $n => $l) {
        $cls = $n < $step ? 'done' : ($n == $step ? 'active' : '');
        $mark = $n < $step ? '&#10003;' : $n;
        echo '<div class="stp ' . $cls . '"><span class="node">' . $mark . '</span><em>' . h($l) . '</em></div>';
        if ($n < count($labels)) echo '<span class="seg ' . ($n < $step ? 'done' : '') . '"></span>';
    }
    echo '</div></div>';
}

/* ===== Phase stepper: full-width boxes with arrows (the big progress banner) ===== */
function render_phase_stepper($step) {
    $phases = phases();
    $labels = step_labels();
    $last   = LAST_STEP();
    $pct    = max(0, min(100, round((($step - 2) / ($last - 2)) * 100)));
    echo '<div class="phase-card"><div class="phase-row">';
    foreach ($phases as $i => $ph) {
        [$name, $steps] = $ph;
        $isCurr = in_array($step, $steps, true);
        $isDone = max($steps) < $step;
        $cls = $isDone ? 'done' : ($isCurr ? 'curr' : 'todo');
        echo '<div class="phase ' . $cls . '"><span class="ph-no">' . ($i + 1) . '</span><span class="ph-name">' . h($name) . '</span></div>';
        if ($i < count($phases) - 1) echo '<span class="phase-arrow">&rarr;</span>';
    }
    echo '</div><div class="prog-bar"><span style="width:' . $pct . '%"></span></div>';
    echo '<div class="prog-count">Step ' . (int)($step - 1) . ' of ' . ($last - 1) . ' &middot; ' . h($labels[$step] ?? '') . '</div>';
    echo '</div>';
}

/* ===== Post-login app shell (full-screen, header + welcome) ===== */
function app_doc_open($title) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body class="app">';
}
function app_topbar($name = '', $toast = true) {
    echo '<header class="appbar"><div class="ab-in">';
    echo '<div class="ab-logo"><span class="logo">F</span><span class="ab-name">FinanceCorp</span></div>';
    echo '<div class="ab-right">';
    if ($name !== '') echo '<span class="ab-welcome">Welcome <b>' . h($name) . '</b></span>';
    echo '<a class="ab-logout" href="/logout.php">&#8614; Logout</a></div>';
    echo '</div></header>';
    if ($toast) echo '<div class="toast"><span class="toast-ic">&#10003;</span> Welcome to FinanceCorp</div>';
}
function ahead($title = '', $step = 0, $name = '') {
    app_doc_open($title);
    app_topbar($name, $step === 0 || $step === 2);   // welcome toast on first entry only
    echo '<main class="appmain"><div class="wrap">';
    if ($step > 0) {
        render_phase_stepper($step);
        [$t, $d, $bul] = step_info($step);
        echo '<div class="cols"><aside class="side">';
        echo '<div class="side-step">STEP ' . (int)($step - 1) . '</div>';
        echo '<h2 class="side-title">' . h($t) . '</h2>';
        if ($d !== '') echo '<p class="side-desc">' . h($d) . '</p>';
        if ($bul) { echo '<ul class="side-bul">'; foreach ($bul as $b) echo '<li>' . h($b) . '</li>'; echo '</ul>'; }
        echo '<div class="side-secure">&#128274; 256-bit secure &middot; RBI-registered NBFC</div>';
        echo '</aside><div class="appcard">';
    } else {
        echo '<div class="cols single"><div class="appcard">';
    }
}
function afoot() { echo '</div></div></div></main></body></html>'; }

/* ===== Pre-login split-screen shell (login / OTP) ===== */
function phead($title = 'FinanceCorp', $step = 0) {
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<title>' . h($title) . ' — FinanceCorp</title><link rel="stylesheet" href="/assets/style.css?v=' . @filemtime(__DIR__ . '/assets/style.css') . '"></head><body>';
    echo '<div class="split">';
    // LEFT brand panel
    echo '<aside class="brandpanel"><div class="bp-in">';
    echo '<div class="bp-logo"><span class="logo">F</span><div class="bp-name"><b>FinanceCorp</b><small>Instant Personal Loan</small></div></div>';
    echo '<h1>Quick, easy loans up to <span class="hl">&#8377;5,00,000</span></h1>';
    echo '<ul class="bp-ticks"><li>Easy personal loan for all purposes</li><li>Collateral-free loans</li><li>Seamless login process</li><li>Simple repayment</li></ul>';
    echo '<div class="bp-cards"><div class="bp-card">&#9201; Calculate your EMI within minutes</div><div class="bp-card">&#128176; Low interest rates &amp; minimal fees</div><div class="bp-card">&#128241; 24x7 access to the loan app</div></div>';
    echo '</div></aside>';
    // RIGHT content pane
    echo '<section class="pane"><div class="pane-scroll">';
    if ($step > 0) render_stepper($step);
    echo '<div class="pane-inner">';
}

function pfoot() { echo '</div></div></section></div></body></html>'; }

/** SVG illustration for the status modal (folder + face + badge). */
function status_illustration($type) {
    $badge = $type === 'reject' ? '#dc2626' : '#d97706';
    $mark  = $type === 'reject'
        ? '<path d="M93 42l14 14M107 42l-14 14" stroke="#fff" stroke-width="3.2" stroke-linecap="round"/>'
        : '<path d="M100 40v11M100 57v.5" stroke="#fff" stroke-width="3.4" stroke-linecap="round"/>';
    return '<svg viewBox="0 0 200 150" width="186" height="140" fill="none" xmlns="http://www.w3.org/2000/svg">'
        . '<ellipse cx="100" cy="128" rx="78" ry="9" fill="#e8efea"/>'
        . '<rect x="104" y="30" width="46" height="58" rx="5" fill="#eef3f0"/>'
        . '<rect x="112" y="42" width="30" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="52" width="24" height="4" rx="2" fill="#d7e3dc"/>'
        . '<rect x="112" y="62" width="28" height="4" rx="2" fill="#d7e3dc"/>'
        . '<path d="M44 108V70a8 8 0 018-8h26l9 10h40a8 8 0 018 8v28a8 8 0 01-8 8H52a8 8 0 01-8-8z" fill="#06402b"/>'
        . '<path d="M60 86l10 10M70 86l-10 10M60 110l10 10M70 110l-10 10" stroke="#06402b" stroke-width="0" />'
        . '<text x="74" y="92" font-family="monospace" font-size="15" fill="#bfe8d4" font-weight="700">&gt;&lt;</text>'
        . '<path d="M72 104q8 -6 16 0" stroke="#bfe8d4" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
        . '<circle cx="100" cy="49" r="16" fill="#fff"/><circle cx="100" cy="49" r="13" fill="' . $badge . '"/>' . $mark
        . '</svg>';
}

/** Full-page modal result (reject / already-applied), styled over the app shell. Ends the request. */
function result_screen($type, $title, $reason = '', $sub = '', $showStatus = true) {
    $name = $_SESSION['pan_name'] ?? '';
    app_doc_open('Application Status');
    app_topbar($name);
    echo '<main class="appmain dimmed"><div class="wrap"><div class="appcard ghostcard"></div></div></main>';
    echo '<div class="backdrop"><div class="modal ' . ($type === 'reject' ? 'is-reject' : 'is-info') . '">';
    echo '<div class="modal-ill">' . status_illustration($type) . '</div>';
    echo '<h2 class="modal-title">' . h($title) . '</h2>';
    if ($reason !== '') echo '<p class="modal-text">' . h($reason) . '</p>';
    if ($sub !== '')    echo '<p class="modal-text sub">' . h($sub) . '</p>';
    echo '<div class="modal-actions">';
    if ($showStatus) echo '<a class="btn ghost" href="/status.php">Check status</a>';
    echo '<a class="btn" href="/login.php">Ok</a>';
    echo '</div></div></div></body></html>';
    exit;
}
function card_open($h){ /* title now lives in the side panel */ }
function card_lead($t){ echo '<p class="appcard-lead">' . h($t) . '</p>'; }
function card_close(){}
