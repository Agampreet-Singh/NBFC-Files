<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$tot = (int)$pdo->query("SELECT COUNT(*) c FROM applications")->fetch()['c'];
$pend = (int)$pdo->query("SELECT COUNT(*) c FROM applications WHERE status='PENDING'")->fetch()['c'];
$appr = (int)$pdo->query("SELECT COUNT(*) c FROM applications WHERE status='APPROVED'")->fetch()['c'];
$disb = (int)$pdo->query("SELECT COUNT(*) c FROM applications WHERE status='DISBURSED'")->fetch()['c'];
$disbAmt = (float)$pdo->query("SELECT COALESCE(SUM(final_offer),0) s FROM applications WHERE status='DISBURSED'")->fetch()['s'];
$queueAmt = (float)$pdo->query("SELECT COALESCE(SUM(final_offer),0) s FROM applications WHERE status='APPROVED'")->fetch()['s'];
$recent = $pdo->query("SELECT * FROM applications ORDER BY id DESC LIMIT 8")->fetchAll();

shell_head('dashboard', 'Dashboard');
?>
<div class="kpis">
  <div class="kpi"><span>Total applications</span><b><?= $tot ?></b></div>
  <div class="kpi"><span>Pending review</span><b><?= $pend ?></b></div>
  <div class="kpi"><span>Approved (in queue)</span><b><?= $appr ?></b></div>
  <div class="kpi"><span>Disbursed</span><b><?= $disb ?></b></div>
  <div class="kpi accent"><span>Awaiting disbursal</span><b>&#8377;<?= number_format($queueAmt) ?></b></div>
  <div class="kpi"><span>Total disbursed</span><b>&#8377;<?= number_format($disbAmt) ?></b></div>
</div>

<div class="panel">
  <div class="panel-h"><h2>Recent applications</h2><a class="link" href="/applications.php">View all</a></div>
  <table class="tbl">
    <tr><th>Reference</th><th>Applicant</th><th>PAN</th><th>Score</th><th>Offer</th><th>Status</th></tr>
    <?php foreach ($recent as $a): ?>
    <tr onclick="location='/application.php?ref=<?= h($a['reference_no']) ?>'">
      <td><?= h($a['reference_no']) ?></td>
      <td><?= h($a['full_name']) ?></td>
      <td><?= h($a['pan']) ?></td>
      <td><?= $a['credit_score'] ?: '-' ?></td>
      <td><?= $a['final_offer'] !== null ? '&#8377;'.number_format((float)$a['final_offer']) : '-' ?></td>
      <td><?= badge($a['status']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php shell_foot();
