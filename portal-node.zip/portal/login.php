<?php
session_start();
require __DIR__ . '/layout.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send'])) {
        $m = preg_replace('/\D/', '', $_POST['mobile'] ?? '');
        if (strlen($m) < 10) { $err = 'Enter a valid 10-digit mobile number.'; }
        else {
            $r = los('otp-send', ['mobile' => $m]);
            if ($r && ($r['status'] ?? '') === 'sent') { $_SESSION['pending_mobile'] = $m; $_SESSION['login_stage'] = 'otp'; header('Location: /login.php'); exit; }
            $err = 'Could not send OTP. Please try again.';
        }
    }
    if (isset($_POST['verify'])) {
        $m = $_SESSION['pending_mobile'] ?? '';
        $r = los('otp-verify', ['mobile' => $m, 'otp' => preg_replace('/\D/', '', $_POST['otp'] ?? '')]);
        if ($r && !empty($r['valid'])) {
            $app = los('create-application', ['mobile' => $m]);
            $_SESSION['mobile'] = $m; $_SESSION['ref'] = $app['reference_no'] ?? '';
            unset($_SESSION['pending_mobile'], $_SESSION['login_stage']);
            header('Location: /apply.php?step=2'); exit;
        }
        $err = 'Invalid or expired OTP.';
    }
    if (isset($_POST['change'])) { unset($_SESSION['pending_mobile'], $_SESSION['login_stage']); header('Location: /login.php'); exit; }
}
$stage = $_SESSION['login_stage'] ?? 'mobile';
phead('Login', 1);
if ($err) echo '<p class="err">' . h($err) . '</p>';
if ($stage === 'mobile'): ?>
  <h2 class="pane-h">What's your phone number?</h2>
  <form method="post">
    <label>Phone Number<input name="mobile" pattern="[0-9]{10}" placeholder="Enter 10-digit mobile number" required autofocus></label>
    <button class="btn" name="send" value="1">Generate OTP</button>
    <label class="check" style="margin-top:16px"><input type="checkbox" required> By proceeding, you agree to our Terms &amp; Conditions and Privacy Policy</label>
  </form>
  <div class="rates">
    <h4>Personal Loan Rates &amp; Fees</h4>
    <ul>
      <li>Loan amount up to &#8377;5,00,000</li>
      <li>Tenure: 12 to 36 months</li>
      <li>Rate of Interest: starting from 19% per year</li>
      <li>Processing fee: 1.5% of loan amount + taxes</li>
    </ul>
  </div>
<?php else: ?>
  <h2 class="pane-h">Verify OTP</h2>
  <p class="muted">An OTP has been sent to <b><?= h($_SESSION['pending_mobile'] ?? '') ?></b>. Check your Messages.</p>
  <form method="post">
    <label>Enter OTP<input name="otp" inputmode="numeric" pattern="[0-9]{6}" placeholder="6-digit OTP" required autofocus></label>
    <button class="btn" name="verify" value="1">Verify &amp; Continue</button>
  </form>
  <form method="post"><button class="linkbtn" name="change" value="1">Change number</button></form>
<?php endif;
pfoot();
