<?php
// NSDL node DB (SQLite) — PAN registry + mobile linkage. LAB / isolated range only.
// PAN is the shared identifier across the lab (same PANs get credit profiles on Bank Server).

function ndb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/nsdl.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS pan_records(
            pan TEXT PRIMARY KEY,
            full_name TEXT,
            father_name TEXT,
            dob TEXT,
            mobile TEXT,
            status TEXT DEFAULT 'VALID'   -- VALID / INACTIVE
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS pan_applications(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ack_no TEXT UNIQUE,
            pan TEXT,
            full_name TEXT,
            father_name TEXT,
            dob TEXT,
            mobile TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        )");
        seed($pdo);
    }
    return $pdo;
}

function seed($pdo) {
    $n = (int)$pdo->query("SELECT COUNT(*) c FROM pan_records")->fetch()['c'];
    if ($n > 0) return;
    $rows = [
        ['ABCDE1234F', 'Rajesh Kumar',  'Suresh Kumar',    '1988-05-12', '9812345678', 'VALID'],
        ['PQRSX5678L', 'Priya Sharma',  'Mohan Sharma',    '1992-09-03', '9820011122', 'VALID'],
        ['LMNOP9012Q', 'Amit Verma',    'Rakesh Verma',    '1985-01-25', '9833044455', 'VALID'],
        ['FGHIJ3456M', 'Sneha Patel',   'Dinesh Patel',    '1990-11-18', '9844055566', 'VALID'],
        ['TUVWX7890R', 'Vikram Singh',  'Harbhajan Singh', '1983-07-30', '9855066677', 'VALID'],
        ['ZZZZZ0000Z', 'Inactive Test', 'Senior Test',     '1979-02-02', '9800000000', 'INACTIVE'],
    ];
    $st = $pdo->prepare("INSERT INTO pan_records(pan, full_name, father_name, dob, mobile, status) VALUES(?,?,?,?,?,?)");
    foreach ($rows as $r) { $st->execute($r); }
}

/** Generate a syntactically-valid PAN (5 letters, 4 digits, 1 letter). */
function gen_pan() {
    $L = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $s = '';
    for ($i = 0; $i < 5; $i++) $s .= $L[random_int(0, 25)];
    $s .= str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);
    $s .= $L[random_int(0, 25)];
    return $s;
}
