<?php
// FinanceCorp customer portal — talks ONLY to LOS. LOS orchestrates every node.
define('LOS_URL', getenv('LOS_URL') ?: 'http://10.21.0.3');

// Google Maps API key for the Mailing Address picker.
// Leave empty to use the built-in offline picker. Paste your key (Maps JavaScript
// API + Places API + Geocoding API enabled) to use real Google Maps.
define('GMAPS_KEY', getenv('GMAPS_KEY') ?: '');

function los($action, $data) {
    $url = rtrim(LOS_URL, '/') . '/api.php?action=' . urlencode($action);
    $opts = ['http' => ['method' => 'POST',
        'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => http_build_query($data), 'timeout' => 8, 'ignore_errors' => true]];
    $res = @file_get_contents($url, false, stream_context_create($opts));
    return $res ? json_decode($res, true) : null;
}
function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES); }

// 13-step journey labels
function steps() {
    return [1=>'Login',2=>'PAN',3=>'Address',4=>'Industry',5=>'Credit Check',6=>'Your Offer',
            7=>'Bank Statement',8=>'Choose Bank',9=>'Final Offer',10=>'Aadhaar KYC',11=>'Selfie',
            12=>'Work Details',13=>'e-Mandate'];
}
