<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
// Customer master: everyone who applied (Applicant) + those disbursed (Borrower), with loan info if any.
$rows = $pdo->query("SELECT a.full_name, a.mobile, a.pan, a.status AS app_status,
        a.requested_amount, a.final_offer,
        l.loan_no, l.outstanding, l.dpd, l.classification
    FROM applications a
    LEFT JOIN loans l ON a.reference_no = l.reference_no
    ORDER BY a.updated_at DESC LIMIT 300")->fetchAll();
shell_head('borrowers', 'Borrowers');
?>
<div class="panel">
  <div class="panel-h"><h2>Borrowers &amp; Applicants</h2><span class="muted"><?= count($rows) ?> customers</span></div>
  <table class="tbl">
    <tr><th>Name</th><th>Mobile</th><th>PAN</th><th>Type</th><th>Status</th><th>Amount</th><th>Outstanding</th><th>DPD</th></tr>
    <?php foreach ($rows as $r):
      $isBorrower = !empty($r['loan_no']);
      $amt = $r['final_offer'] ?: $r['requested_amount'];
    ?>
    <tr>
      <td><?= h($r['full_name'] ?: '-') ?></td>
      <td><?= h($r['mobile']) ?></td>
      <td><?= h($r['pan'] ?: '-') ?></td>
      <td><?= $isBorrower ? '<span class="badge disbursed">Borrower</span>' : '<span class="badge draft">Applicant</span>' ?></td>
      <td><?= badge($isBorrower ? ($r['classification'] ?: 'Current') : $r['app_status']) ?></td>
      <td><?= $amt ? inr($amt) : '-' ?></td>
      <td><?= $isBorrower ? inr($r['outstanding']) : '-' ?></td>
      <td><?= $isBorrower ? (int)$r['dpd'] : '-' ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="8" class="muted">No customers yet.</td></tr><?php endif; ?>
  </table>
</div>
<?php shell_foot();
