<?php
require_once __DIR__ . '/config.php';

function darken($hex, $f = 0.72) {
    $c = sscanf($hex, "#%02x%02x%02x");
    return sprintf("#%02x%02x%02x", (int)($c[0]*$f), (int)($c[1]*$f), (int)($c[2]*$f));
}
function icon($n) {
    $p = [
        'wallet' => '<path d="M3 7h16a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/><path d="M16 12h3"/><path d="M3 7l12-4 2 4"/>',
        'list'   => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
        'doc'    => '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5"/>',
        'home'   => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
        'user'   => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
        'out'    => '<path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
        'shield' => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
        'card'   => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
        'cash'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M9 9.5h4a1.5 1.5 0 010 3H10a1.5 1.5 0 000 3h5"/>',
        'bolt'   => '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
        'bank'   => '<path d="M3 10l9-6 9 6"/><path d="M5 10v8M9 10v8M15 10v8M19 10v8M3 21h18"/>',
    ];
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20">' . ($p[$n] ?? '') . '</svg>';
}

/* ---------------- PUBLIC SITE (landing / login) ---------------- */
function site_head() {
    [$name, $color, $brand] = bank_meta();
    $ini = strtoupper(substr(bank_code(), 0, 2));
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . h($name) . ' — ' . h($brand) . '</title><style>' . nb_css($color) . '</style></head><body>';
    echo '<nav class="nav"><div class="nav-in"><div class="brand"><span class="brand-ic">' . $ini . '</span><div><b>' . h($name) . '</b><small>' . h($brand) . '</small></div></div>';
    echo '<div class="nav-links"><a href="#personal">Personal</a><a href="#loans">Loans</a><a href="#cards">Cards</a><a href="#about">About Us</a></div>';
    echo '<a href="#login" class="nav-cta">Login</a></div></nav>';
}
function site_foot() {
    [$name] = bank_meta();
    echo '<footer class="foot"><div class="foot-in"><div><b>' . h($name) . '</b><p>Retail &amp; Corporate Banking</p></div>';
    echo '<div class="foot-cols"><div><h4>Products</h4><a>Savings</a><a>Loans</a><a>Cards</a><a>Deposits</a></div>';
    echo '<div><h4>Support</h4><a>Contact</a><a>Branches</a><a>FAQs</a></div>';
    echo '<div><h4>Legal</h4><a>Privacy</a><a>Terms</a><a>Grievance</a></div></div></div>';
    echo '<div class="foot-bar">' . h($name) . ' &middot; For lab / training use only &middot; Secure NetBanking</div></footer></body></html>';
}

/* ---------------- APP SHELL (logged-in dashboard) ---------------- */
function app_head($section, $who, $role = 'customer') {
    [$name, $color, $brand] = bank_meta();
    $ini = strtoupper(substr(bank_code(), 0, 2));
    $base = $role === 'manager' ? '/manager.php' : '/customer.php';
    $items = $role === 'manager'
        ? [['', 'home', 'Overview'], ['accounts', 'list', 'Accounts'], ['payouts', 'cash', 'Payouts']]
        : [['', 'home', 'Overview'], ['txns', 'list', 'Transactions'], ['stmt', 'doc', 'Statements']];
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . h($name) . ' — Dashboard</title><style>' . nb_css($color) . '</style></head><body class="app">';
    echo '<aside class="side"><div class="side-brand"><span class="brand-ic">' . $ini . '</span><div><b>' . h($name) . '</b><small>' . h($brand) . '</small></div></div><nav class="side-nav">';
    foreach ($items as $it) {
        $act = ($section === $it[0]) ? ' class="on"' : '';
        echo '<a href="' . $base . ($it[0] ? '?sec=' . $it[0] : '') . '"' . $act . '>' . icon($it[1]) . '<span>' . h($it[2]) . '</span></a>';
    }
    echo '<a href="?logout=1" class="logout">' . icon('out') . '<span>Logout</span></a></nav></aside>';
    echo '<div class="app-body"><header class="topbar"><div><span class="hello">' . ($role === 'manager' ? 'Manager Console' : 'Welcome back') . '</span><b>' . h($who) . '</b></div>';
    echo '<span class="shield-badge">' . icon('shield') . ' Secure session</span></header><main class="content">';
}
function app_foot() { echo '</main></div></body></html>'; }

function nb_css($color) {
    $d = darken($color, 0.68); $d2 = darken($color, 0.5);
    return '
    *{box-sizing:border-box} html,body{margin:0} body{font-family:"Segoe UI",system-ui,Arial,sans-serif;color:#1a2235;background:#fff;line-height:1.5}
    a{color:inherit;text-decoration:none}
    :root{--c:' . $color . ';--cd:' . $d . ';--cd2:' . $d2 . '}
    .brand-ic{width:40px;height:40px;border-radius:10px;background:rgba(255,255,255,.18);display:grid;place-items:center;font-weight:800;font-size:16px;flex:none}
    /* nav */
    .nav{position:sticky;top:0;z-index:30;background:var(--c);color:#fff}
    .nav-in{max-width:1120px;margin:0 auto;height:66px;display:flex;align-items:center;gap:24px;padding:0 22px}
    .brand{display:flex;align-items:center;gap:11px}.brand small{display:block;opacity:.8;font-size:11.5px}.brand b{font-size:16px}
    .nav-links{display:flex;gap:22px;margin-left:12px;font-size:14.5px;font-weight:500}.nav-links a{opacity:.9}.nav-links a:hover{opacity:1}
    .nav-cta{margin-left:auto;background:#fff;color:var(--cd);padding:9px 20px;border-radius:9px;font-weight:700;font-size:14px}
    /* hero */
    .hero{background:linear-gradient(135deg,var(--c),var(--cd2));color:#fff;position:relative;overflow:hidden}
    .hero:after{content:"";position:absolute;right:-120px;top:-120px;width:420px;height:420px;border-radius:50%;background:rgba(255,255,255,.07)}
    .hero-in{max-width:1120px;margin:0 auto;padding:56px 22px 64px;display:grid;grid-template-columns:1.1fr .9fr;gap:40px;align-items:center}
    .hero h1{font-size:40px;line-height:1.15;margin:0 0 16px;font-weight:800}
    .hero p{font-size:17px;opacity:.92;margin:0 0 26px;max-width:460px}
    .hero-btns a{display:inline-block;margin-right:12px;padding:13px 24px;border-radius:10px;font-weight:700;font-size:15px}
    .btn-w{background:#fff;color:var(--cd)}.btn-o{border:1.5px solid rgba(255,255,255,.6);color:#fff}
    .trust{display:flex;gap:26px;margin-top:34px;font-size:13px;opacity:.9}.trust b{display:block;font-size:22px}
    /* login card */
    .login-card{background:#fff;color:#1a2235;border-radius:16px;padding:26px;box-shadow:0 20px 50px rgba(0,0,0,.25)}
    .login-card h3{margin:0 0 4px;font-size:20px;color:var(--cd)}
    .login-card .sub{color:#64748b;font-size:13.5px;margin:0 0 16px}
    .tabs{display:flex;background:#eef2f7;border-radius:10px;padding:4px;margin-bottom:16px}
    .tabs label{flex:1;text-align:center;padding:9px;border-radius:8px;font-size:14px;font-weight:600;color:#64748b;cursor:pointer}
    .tabs input{display:none}
    #tc:checked~.tabs label[for=tc],#tm:checked~.tabs label[for=tm]{background:#fff;color:var(--cd);box-shadow:0 1px 4px rgba(0,0,0,.08)}
    .pane{display:none}#tc:checked~#pane-c{display:block}#tm:checked~#pane-m{display:block}
    label.fl{display:block;font-weight:600;font-size:13.5px;margin-top:12px}
    input.in{width:100%;margin-top:6px;padding:12px 13px;border:1px solid #d5dce6;border-radius:10px;font-size:15px;font-family:inherit}
    input.in:focus{outline:none;border-color:var(--c)}
    .btn{width:100%;margin-top:16px;background:var(--c);color:#fff;border:0;padding:13px;border-radius:10px;font-size:15px;font-weight:700;cursor:pointer}
    .btn:hover{background:var(--cd)}
    .err{background:#fee2e2;color:#b91c1c;padding:10px 13px;border-radius:9px;font-size:13.5px;margin-bottom:10px}
    .ok{background:#dcfce7;color:#15803d;padding:10px 13px;border-radius:9px;font-size:13.5px;margin-bottom:10px}
    .hint{color:#64748b;font-size:12.5px;margin-top:10px}
    /* sections */
    .sec{max-width:1120px;margin:0 auto;padding:54px 22px}
    .sec h2{text-align:center;font-size:28px;margin:0 0 6px}.sec .lead{text-align:center;color:#64748b;margin:0 0 34px}
    .prod{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
    .pcard{border:1px solid #e7ecf3;border-radius:14px;padding:22px;transition:.15s}.pcard:hover{box-shadow:0 10px 30px rgba(20,34,59,.1);transform:translateY(-3px)}
    .pcard .pic{width:46px;height:46px;border-radius:11px;background:color-mix(in srgb,var(--c) 14%,#fff);color:var(--cd);display:grid;place-items:center;margin-bottom:12px}
    .pcard h4{margin:0 0 6px;font-size:16px}.pcard p{margin:0;color:#64748b;font-size:13.5px}
    .strip{background:#f5f8fc}.stripg{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;text-align:center}
    .stripg b{display:block;font-size:30px;color:var(--cd)}.stripg span{color:#64748b;font-size:14px}
    /* footer */
    .foot{background:#0f1830;color:#cdd6e6;margin-top:20px}
    .foot-in{max-width:1120px;margin:0 auto;padding:40px 22px;display:grid;grid-template-columns:1.2fr 2fr;gap:30px}
    .foot b{color:#fff}.foot p{color:#8a97b2;font-size:13px}
    .foot-cols{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
    .foot-cols h4{color:#fff;font-size:14px;margin:0 0 10px}.foot-cols a{display:block;color:#aab6cd;font-size:13.5px;padding:3px 0}
    .foot-bar{border-top:1px solid #23304d;text-align:center;padding:14px;font-size:12.5px;color:#7c8aa6}
    /* ---------- app shell ---------- */
    body.app{background:#eef2f7;display:flex;min-height:100vh}
    .side{width:240px;background:linear-gradient(180deg,var(--c),var(--cd2));color:#fff;flex:none;display:flex;flex-direction:column;position:sticky;top:0;height:100vh}
    .side-brand{display:flex;align-items:center;gap:11px;padding:20px 18px;border-bottom:1px solid rgba(255,255,255,.14)}
    .side-brand small{display:block;opacity:.8;font-size:11px}
    .side-nav{display:flex;flex-direction:column;padding:14px 10px;gap:4px;flex:1}
    .side-nav a{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:10px;font-size:14.5px;font-weight:500;opacity:.9}
    .side-nav a:hover{background:rgba(255,255,255,.12)}
    .side-nav a.on{background:rgba(255,255,255,.18);opacity:1;font-weight:700}
    .side-nav .logout{margin-top:auto;opacity:.85}
    .app-body{flex:1;display:flex;flex-direction:column;min-width:0}
    .topbar{background:#fff;height:66px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;box-shadow:0 1px 3px rgba(20,34,59,.06)}
    .topbar .hello{display:block;color:#64748b;font-size:12.5px}.topbar b{font-size:16px}
    .shield-badge{display:flex;align-items:center;gap:7px;color:var(--cd);font-size:13px;font-weight:600}
    .content{padding:26px 28px 50px;max-width:1040px;width:100%}
    .acct-hero{background:linear-gradient(120deg,var(--c),var(--cd2));color:#fff;border-radius:16px;padding:24px 26px;box-shadow:0 10px 26px rgba(20,34,59,.12)}
    .acct-hero .lab{opacity:.85;font-size:13px}.acct-hero .amt{font-size:34px;font-weight:800;margin:4px 0 14px}
    .acct-hero .meta{display:flex;gap:28px;flex-wrap:wrap;font-size:13.5px}.acct-hero .meta b{display:block;opacity:.8;font-weight:500;font-size:12px}
    .qrow{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0}
    .qcard{background:#fff;border:1px solid #e7ecf3;border-radius:13px;padding:16px;display:flex;align-items:center;gap:12px}
    .qcard .qic{width:42px;height:42px;border-radius:11px;background:color-mix(in srgb,var(--c) 13%,#fff);color:var(--cd);display:grid;place-items:center;flex:none}
    .qcard .qv{font-size:18px;font-weight:800}.qcard .ql{color:#64748b;font-size:12.5px}
    .panel{background:#fff;border:1px solid #e7ecf3;border-radius:14px;padding:20px 22px;margin-top:18px}
    .panel .ph{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
    .panel h3{margin:0;font-size:17px}
    .dlbtn{background:var(--c);color:#fff;padding:10px 16px;border-radius:9px;font-weight:700;font-size:13.5px;display:inline-flex;gap:8px;align-items:center}
    table{width:100%;border-collapse:collapse;font-size:13.5px}
    th{text-align:left;color:#64748b;font-weight:600;padding:10px 8px;border-bottom:2px solid #eef2f7}
    td{padding:10px 8px;border-bottom:1px solid #f1f4f9}
    td.r,th.r{text-align:right} .dr{color:#b91c1c}.cr{color:#15803d}
    .pill{display:inline-block;padding:3px 10px;border-radius:20px;font-size:11.5px;font-weight:700}
    .pill.flag{background:#fee2e2;color:#b91c1c}.pill.ok{background:#dcfce7;color:#15803d}
    .link{color:var(--cd);font-weight:600}
    @media(max-width:820px){.hero-in,.foot-in{grid-template-columns:1fr}.prod{grid-template-columns:1fr 1fr}.side{display:none}}
    ';
}
