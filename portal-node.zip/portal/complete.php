<?php
session_start();
require __DIR__ . '/layout.php';
$ref  = $_SESSION['ref'] ?? '';
$name = $_SESSION['pan_name'] ?? '';
// Decision may have rejected at submit (e.g. FOIR / contactability) — reflect it honestly.
$res = $ref ? los('get-status', ['reference_no' => $ref]) : null;
$st  = $res['status'] ?? 'PENDING';
session_destroy();

if ($st === 'REJECTED') {
    session_start(); $_SESSION['pan_name'] = $name;   // keep name for the header
    result_screen('reject', 'Application Rejected',
        $res['reason'] ?? 'Your application did not meet our eligibility criteria.',
        'You can apply again after 30 days from this number.');
}

ahead('Submitted', 0, $name);
?>
<div class="done-ill"><svg viewBox="0 0 120 120" width="96" height="96" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="60" cy="60" r="52" fill="#dcfce7"/><circle cx="60" cy="60" r="38" fill="#16a34a"/><path d="M46 61l10 10 20-23" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
<h2 class="appcard-h">Application received</h2>
<p class="appcard-p">Your loan application has been received and is now under review. We've sent a confirmation to your registered mobile number, and you'll get an update as soon as there's a decision.</p>
<?php if ($ref): ?><p class="refbox">Reference: <b><?= h($ref) ?></b></p><?php endif; ?>
<p style="margin-top:18px"><a class="btn" href="/status.php?ref=<?= urlencode($ref) ?>">Track Application Status</a></p>
<?php afoot();
