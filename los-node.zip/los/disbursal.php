<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$rows = $pdo->query("SELECT * FROM applications WHERE status='APPROVED' ORDER BY updated_at")->fetchAll();
$total = array_sum(array_map(fn($r) => (float)$r['final_offer'], $rows));
shell_head('disbursal', 'Disbursal Queue');
?>
<div class="panel">
  <div class="panel-h"><h2>Approved &mdash; awaiting disbursal</h2>
    <span class="muted"><?= count($rows) ?> loans &middot; &#8377;<?= number_format($total) ?></span></div>
  <p class="muted">These approved loans are picked up by the Disbursal System and paid to the beneficiary account on file.</p>
  <table class="tbl">
    <tr><th>Reference</th><th>Applicant</th><th>Amount</th><th>Bank</th><th>Beneficiary A/C</th><th>IFSC</th></tr>
    <?php foreach ($rows as $a): ?>
    <tr onclick="location='/application.php?ref=<?= h($a['reference_no']) ?>'">
      <td><?= h($a['reference_no']) ?></td>
      <td><?= h($a['full_name']) ?></td>
      <td>&#8377;<?= number_format((float)$a['final_offer']) ?></td>
      <td><?= h($a['bank_code']) ?></td>
      <td><?= h($a['beneficiary_account']) ?></td>
      <td><?= h($a['beneficiary_ifsc']) ?></td>
    </tr>
    <?php endforeach; ?>
    <?php if (!$rows): ?><tr><td colspan="6" class="muted">Queue is empty.</td></tr><?php endif; ?>
  </table>
</div>
<?php shell_foot();
