<?php
require __DIR__ . '/layout.php';
phead('Instant Personal Loan');
?>
<section class="hero">
  <div>
    <h1>Instant Personal Loan up to &#8377;5,00,000</h1>
    <p>100% digital. Approval in minutes. Money to your bank account.</p>
    <a class="btn" href="/login.php">Apply Now</a>
    <ul class="ticks"><li>Paperless KYC</li><li>Flexible tenure up to 36 months</li><li>Interest from 19% p.a.</li></ul>
  </div>
  <div class="hero-card">
    <h3>Simple 13-step journey</h3>
    <ol class="mini"><li>Mobile login</li><li>PAN &amp; KYC</li><li>Credit check &amp; offer</li><li>Bank statement</li><li>e-Sign &amp; mandate</li></ol>
  </div>
</section>
<?php pfoot();
