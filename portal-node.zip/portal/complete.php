<?php
session_start();
require __DIR__ . '/layout.php';
$ref = $_SESSION['ref'] ?? '';
session_destroy();
phead('Submitted');
?>
<div class="tick-big">&#10003;</div>
<h2 class="pane-h">Application received</h2>
<p>Your loan application has been received and is now under review. We've sent a confirmation to your registered mobile number, and you'll get an update as soon as there's a decision.</p>
<?php if ($ref): ?><p class="refbox">Reference: <b><?= h($ref) ?></b></p><?php endif; ?>
<p style="margin-top:18px">
  <a class="btn" href="/status.php?ref=<?= urlencode($ref) ?>">Track Application Status</a>
</p>
<?php pfoot();
