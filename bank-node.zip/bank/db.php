<?php
// Bank Server DB (SQLite) — banks, accounts, credit, loans, statements, mandates, payouts.
// LAB / isolated range only. Credit profiles are keyed by PAN (consistent with NSDL/DigiLocker).

function bdb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/bank.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        schema($pdo);
        seed($pdo);
    }
    return $pdo;
}

function schema($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS banks(code TEXT PRIMARY KEY, name TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS accounts(
        account_no TEXT PRIMARY KEY, ifsc TEXT, bank_code TEXT, holder_name TEXT,
        pan TEXT, mobile TEXT, balance REAL, acc_type TEXT, is_mule INTEGER DEFAULT 0)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS credit_profiles(
        pan TEXT PRIMARY KEY, score INTEGER, band TEXT, performance TEXT, remarks TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS existing_loans(
        id INTEGER PRIMARY KEY AUTOINCREMENT, pan TEXT, lender TEXT, product TEXT,
        outstanding REAL, emi REAL, status TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT, account_no TEXT, txn_date TEXT,
        description TEXT, amount REAL, dr_cr TEXT, balance_after REAL)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mandates(
        id INTEGER PRIMARY KEY AUTOINCREMENT, mandate_ref TEXT, account_no TEXT,
        amount REAL, status TEXT, created_at TEXT DEFAULT (datetime('now')))");
    $pdo->exec("CREATE TABLE IF NOT EXISTS payouts(
        id INTEGER PRIMARY KEY AUTOINCREMENT, utr TEXT, source_ip TEXT,
        beneficiary_account TEXT, ifsc TEXT, amount REAL, reference TEXT,
        status TEXT, created_at TEXT DEFAULT (datetime('now')))");
}

function seed($pdo) {
    if ((int)$pdo->query("SELECT COUNT(*) c FROM banks")->fetch()['c'] > 0) return;

    // Master bank server — manages 7 banks
    $banks = [
        ['HDFC', 'HDFC Bank'],
        ['PUNB', 'Punjab National Bank'],
        ['BARB', 'Bank of Baroda'],
        ['SBIN', 'State Bank of India'],
        ['ICIC', 'ICICI Bank'],
        ['UTIB', 'Axis Bank'],
        ['KKBK', 'Kotak Mahindra Bank'],
    ];
    $bs = $pdo->prepare("INSERT INTO banks(code, name) VALUES(?,?)");
    foreach ($banks as $b) $bs->execute($b);

    // customer accounts — each mobile number belongs to ONE particular bank
    // (holder, pan, mobile, bank, ifsc, account_no, balance, type, is_mule)
    $accts = [
        ['Rajesh Kumar', 'ABCDE1234F', '9812345678', 'HDFC', 'HDFC0000123', '50100012345678', 125000, 'SAVINGS', 0],
        ['Priya Sharma', 'PQRSX5678L', '9820011122', 'PUNB', 'PUNB0000456', '001122334455',   86000,  'SAVINGS', 0],
        ['Amit Verma',   'LMNOP9012Q', '9833044455', 'BARB', 'BARB0000789', '30011223344',     42000,  'SAVINGS', 0],
        ['Sneha Patel',  'FGHIJ3456M', '9844055566', 'SBIN', 'SBIN0000111', '918000123456',    210000, 'SAVINGS', 0],
        ['Vikram Singh', 'TUVWX7890R', '9855066677', 'ICIC', 'ICIC0000222', '147500987654',    15000,  'SAVINGS', 0],
        // pre-existing "collection" (mule) accounts the attacker may use (spread across banks)
        ['Gopal Traders',    '', '9700000011', 'KKBK', 'KKBK0000911', '147500111222', 2000, 'CURRENT', 1],
        ['Sunrise Agencies', '', '9700000022', 'UTIB', 'UTIB0000911', '30099887766',  1500, 'CURRENT', 1],
        ['M R Enterprises',  '', '9700000033', 'PUNB', 'PUNB0000911', '009988776655', 500,  'CURRENT', 1],
    ];
    $as = $pdo->prepare("INSERT INTO accounts(holder_name, pan, mobile, bank_code, ifsc, account_no, balance, acc_type, is_mule) VALUES(?,?,?,?,?,?,?,?,?)");
    foreach ($accts as $a) $as->execute($a);

    // credit profiles (keyed by PAN) — credit score "starts from PAN"
    $cp = [
        ['ABCDE1234F', 780, 'Excellent', 'Good',    'No overdues; healthy repayment history'],
        ['PQRSX5678L', 720, 'Good',      'Good',    'Minor delay once; otherwise regular'],
        ['LMNOP9012Q', 650, 'Fair',      'Average', '1 active loan; occasional late EMI'],
        ['FGHIJ3456M', 810, 'Excellent', 'Good',    'Clean record, high limit utilisation low'],
        ['TUVWX7890R', 590, 'Poor',      'Weak',    'Multiple late payments; high utilisation'],
    ];
    $cs = $pdo->prepare("INSERT INTO credit_profiles(pan, score, band, performance, remarks) VALUES(?,?,?,?,?)");
    foreach ($cp as $c) $cs->execute($c);

    // existing loans
    $loans = [
        ['ABCDE1234F', 'HDFC Bank', 'Personal Loan',    120000, 5200,  'ACTIVE'],
        ['LMNOP9012Q', 'Bajaj Finance', 'Two-Wheeler Loan', 38000, 2100, 'ACTIVE'],
        ['TUVWX7890R', 'SBI', 'Consumer Durable Loan',  9000,  1500,  'ACTIVE'],
    ];
    $ls = $pdo->prepare("INSERT INTO existing_loans(pan, lender, product, outstanding, emi, status) VALUES(?,?,?,?,?,?)");
    foreach ($loans as $l) $ls->execute($l);

    // transactions for statements (per customer account)
    seed_txns($pdo, '50100012345678', 125000, 'Rajesh');
    seed_txns_poor($pdo, '001122334455');            // Priya — deliberately weak statement (bounce, no salary)
    seed_txns($pdo, '30011223344',    42000,  'Amit');
    seed_txns($pdo, '918000123456',   210000, 'Sneha');
    seed_txns($pdo, '147500987654',   15000,  'Vikram');
}

function seed_txns_poor($pdo, $acct) {
    // weak banking behaviour: no salary credit, irregular small inflows, a bounced debit, balance dips low
    $rows = [
        [$acct, '2026-11-04', 'UPI/Misc Credit', 3000, 'CR', 3200],
        [$acct, '2026-11-07', 'ATM Withdrawal', 2500, 'DR', 700],
        [$acct, '2026-11-10', 'ECS Return/Bounce Charge', 590, 'DR', 110],
        [$acct, '2026-11-14', 'UPI/Misc Credit', 4000, 'CR', 4110],
        [$acct, '2026-11-18', 'UPI/Shopping', 3900, 'DR', 210],
        [$acct, '2026-11-22', 'Cash Deposit', 1500, 'CR', 1710],
    ];
    $st = $pdo->prepare("INSERT INTO transactions(account_no, txn_date, description, amount, dr_cr, balance_after) VALUES(?,?,?,?,?,?)");
    foreach ($rows as $r) $st->execute($r);
}

function seed_txns($pdo, $acct, $bal, $who) {
    // build a short, realistic statement ending at $bal
    $items = [
        ['Salary Credit - '.strtoupper($who).' EMPLOYER', 55000, 'CR'],
        ['UPI/Grocery/BigBasket', 2400, 'DR'],
        ['UPI/Electricity Bill', 1800, 'DR'],
        ['ATM Withdrawal', 10000, 'DR'],
        ['UPI/Swiggy', 650, 'DR'],
        ['NEFT/Rent', 18000, 'DR'],
        ['UPI/Refund Amazon', 1200, 'CR'],
        ['Card/Fuel', 2000, 'DR'],
    ];
    // walk backwards from current balance to assign balance_after plausibly
    $running = $bal;
    $rows = [];
    $day = 20;
    foreach ($items as $it) {
        $rows[] = [$acct, sprintf('2026-11-%02d', $day), $it[0], $it[1], $it[2], $running];
        $running += ($it[2] === 'CR') ? -$it[1] : $it[1]; // reverse to get earlier balances
        $day -= 2; if ($day < 1) $day = 1;
    }
    $rows = array_reverse($rows);
    $st = $pdo->prepare("INSERT INTO transactions(account_no, txn_date, description, amount, dr_cr, balance_after) VALUES(?,?,?,?,?,?)");
    foreach ($rows as $r) $st->execute($r);
}
