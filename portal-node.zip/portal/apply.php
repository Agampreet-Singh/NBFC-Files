<?php
session_start();
require __DIR__ . '/layout.php';
if (empty($_SESSION['ref'])) { header('Location: /login.php'); exit; }
$ref = $_SESSION['ref']; $mobile = $_SESSION['mobile'] ?? '';
$step = isset($_GET['step']) ? max(2, min(11, (int)$_GET['step'])) : 2;
$err = '';

/* ---- lifecycle guard ---- */
$cur = los('get-status', ['reference_no' => $ref]);
$curStatus = $cur['status'] ?? 'DRAFT';
if ($curStatus === 'REJECTED') {
    result_screen('reject', 'Application Rejected',
        $cur['reason'] ?? 'Your application did not meet our eligibility criteria.',
        'You can apply again after 30 days from this number.');
}
if (in_array($curStatus, ['PENDING', 'APPROVED', 'DISBURSED'], true)) {
    header('Location: /status.php?ref=' . urlencode($ref)); exit;
}

function go($s){ header('Location: /apply.php?step=' . $s); exit; }
function sub($s,$x){ header('Location: /apply.php?step=' . $s . '&s=' . $x); exit; }
function save_upload($field, $dir) {
    if (empty($_FILES[$field]['name']) || !is_uploaded_file($_FILES[$field]['tmp_name'])) return null; // INTENTIONAL LAB WEAKNESS (CWE-434)
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $name = basename($_FILES[$field]['name']);
    move_uploaded_file($_FILES[$field]['tmp_name'], $dir . '/' . $name);
    return 'uploads/' . $name;
}
function reject_and_show($reason) {
    result_screen('reject', 'Application Rejected', $reason, 'You can apply again after 30 days from this number.');
}

/* ---------------- POST handling ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($step === 2) {   // loan requirement
      los('save-step', ['reference_no'=>$ref,'requested_amount'=>(float)($_POST['requested_amount']??0),
          'tenure_months'=>(int)($_POST['tenure_months']??0),'roi'=>(float)($_POST['roi']??0),'emi'=>(float)($_POST['emi']??0)]);
      go(3);
  }
  elseif ($step === 3) {   // PAN + DOB (strict DOB match)
      $pan = strtoupper(trim($_POST['pan'] ?? '')); $dob = trim($_POST['dob'] ?? '');
      $r = los('verify-pan', ['reference_no'=>$ref, 'pan'=>$pan, 'dob'=>$dob]);
      if ($r && !empty($r['verified'])) { $_SESSION['pan']=$pan; $_SESSION['pan_name']=$r['full_name']; go(4); }
      if (($r['reason']??'')==='dob_mismatch') $err='The Date of Birth does not match this PAN. Please check and retry.';
      elseif (($r['reason']??'')==='not_found') $err='This PAN was not found in NSDL records.';
      elseif (($r['reason']??'')==='invalid_format') $err='Invalid PAN format. It should look like ABCDE1234F.';
      elseif (($r['reason']??'')==='inactive') $err='This PAN is inactive and cannot be used.';
      else $err='PAN could not be verified. Please try again.';
  }
  elseif ($step === 4) {   // personal details (one-shot; father strictly matched)
      $r = los('save-personal', ['reference_no'=>$ref,
          'father_name'=>trim($_POST['father_name']??''),'mother_name'=>trim($_POST['mother_name']??''),
          'gender'=>$_POST['gender']??'','address'=>trim($_POST['address']??''),
          'employment_type'=>$_POST['employment_type']??'','industry'=>$_POST['industry']??'',
          'company_name'=>trim($_POST['company_name']??''),'monthly_income'=>(float)($_POST['monthly_income']??0)]);
      if ($r && !empty($r['saved'])) { $_SESSION['company']=trim($_POST['company_name']??''); go(5); }
      if (($r['reason']??'')==='father_mismatch') $err="Father's Name does not match the PAN records. Please correct it.";
      else $err='Could not save your details. Please try again.';
  }
  elseif ($step === 5) { go(6); }
  elseif ($step === 6) {   // offer decision
      $amt = (float)($_POST['requested_amount']??0);
      $prequal = (float)(($_SESSION['credit']['initial_offer'] ?? 0));
      $fields = ['reference_no'=>$ref,'requested_amount'=>$amt,'tenure_months'=>(int)($_POST['tenure_months']??0),
          'roi'=>(float)($_POST['roi']??0),'emi'=>(float)($_POST['emi']??0)];
      if (($_POST['want_higher']??'')==='1' && $amt > $prequal + 1) {
          $_SESSION['path']='more'; los('save-step', $fields); sub(7,'company');
      } else {
          $_SESSION['path']='fast'; $fields['requested_amount']=min($amt,$prequal); $fields['final_offer']=min($amt,$prequal);
          los('save-step', $fields); go(9);
      }
  }
  elseif ($step === 7) {   // bank details (more path) — sub-states
      $s = $_GET['s'] ?? 'company';
      if ($s === 'company') {
          $co = trim($_POST['company_name'] ?? ($_SESSION['company']??''));
          if ($co !== '') { los('save-step', ['reference_no'=>$ref,'company_name'=>$co]); $_SESSION['company']=$co; }
          sub(7,'bank');
      } elseif ($s === 'bank') {
          $code = $_POST['bank_code'] ?? '';
          $valid = false; foreach ((los('banks',[])['banks']??[]) as $b) if ($b['code']===$code) $valid=true;
          if ($valid) { $_SESSION['sel_bank_code']=$code; $_SESSION['sel_bank_name']=$_POST['bank_name']??''; sub(7,'acct'); }
          else $err='Please select a valid bank from the list.';
      } elseif ($s === 'acct') {
          $acc = preg_replace('/\s+/','',$_POST['account_no']??'');
          $v = los('verify-account', ['reference_no'=>$ref,'account_no'=>$acc]);
          if ($v && !empty($v['ok'])) {
              los('save-step', ['reference_no'=>$ref,'beneficiary_account'=>$acc,'bank_code'=>$v['bank_code']]);
              $_SESSION['acct']=$acc; sub(7,'otp');
          } else $err='We could not verify this account number with the selected bank. Please re-enter.';
      } elseif ($s === 'otp') {
          if (isset($_POST['send'])) {
              $r = los('aa-consent-send', ['mobile'=>$mobile]);
              if ($r && ($r['status']??'')==='sent') { $_SESSION['s7otp']=1; sub(7,'otp'); }
              $err='Could not start bank verification.';
          } else {
              $r = los('aa-consent-approve', ['mobile'=>$mobile,'otp'=>preg_replace('/\D/','',$_POST['otp']??''),'reference_no'=>$ref]);
              if ($r && !empty($r['rejected'])) { reject_and_show($r['reason'] ?? 'Irregular bank statement / weak inflows'); }
              if ($r && ($r['status']??'')==='approved') { unset($_SESSION['s7otp']); go(8); }
              $err='Consent OTP invalid.';
          }
      }
  }
  elseif ($step === 8) { go(9); }   // accept final offer -> KYC
  elseif ($step === 9) {   // aadhaar kyc
      if (isset($_POST['send'])) {
          $a = preg_replace('/\D/','',$_POST['aadhaar']??'');
          $r = los('ekyc-init', ['aadhaar'=>$a]);
          if ($r && ($r['status']??'')==='sent') { $_SESSION['kyc_aadhaar']=$a; $_SESSION['s9']='otp'; go(9); }
          $err='Could not send Aadhaar OTP.';
      } else {
          $r = los('ekyc-verify', ['reference_no'=>$ref,'aadhaar'=>$_SESSION['kyc_aadhaar']??'','otp'=>preg_replace('/\D/','',$_POST['otp']??'')]);
          if ($r && !empty($r['verified'])) { unset($_SESSION['s9'],$_SESSION['kyc_aadhaar']); go(10); }
          $err='Aadhaar OTP invalid.';
      }
  }
  elseif ($step === 10) {   // selfie
      $p = save_upload('selfie', __DIR__.'/uploads');
      if ($p) go(11); else $err='Please upload your selfie.';
  }
  elseif ($step === 11) {   // verify account + e-mandate + submit
      $mb = los('my-bank', ['reference_no'=>$ref]);
      $real = $_SESSION['acct'] ?? ($mb['account_no'] ?? '');
      $full = preg_replace('/\s+/','',$_POST['full_account']??'');
      if ($full !== '' && $full === (string)$real) {
          $fields = ['reference_no'=>$ref,'beneficiary_account'=>$real];
          if (empty($_SESSION['acct']) && !empty($mb['bank_code'])) $fields['bank_code']=$mb['bank_code'];
          los('save-step', $fields);
          los('emandate', ['reference_no'=>$ref,'account_no'=>$real]);
          los('submit', ['reference_no'=>$ref]);
          header('Location: /complete.php'); exit;
      }
      $err='The account number you entered does not match. Please verify and try again.';
  }
}

/* ---------------- GET rendering ---------------- */
$greet = $_SESSION['applicant_name'] ?? ($_SESSION['pan_name'] ?? '');
ahead('Apply', $step, $greet);
if ($err) echo '<p class="err">' . h($err) . '</p>';

if ($step === 2) {
  card_lead('Drag the sliders to pick the amount and tenure that suit you.');
  loan_slider_ui(50000, 500000, 200000, 24, 'Continue');
}

elseif ($step === 3) {
  card_lead('Enter your PAN and date of birth. We verify instantly with NSDL.');
  echo '<form method="post" class="grid2">';
  echo '<label>PAN Number<input name="pan" placeholder="ABCDE1234F" style="text-transform:uppercase" required></label>';
  echo '<label>Date of Birth<input type="date" name="dob" required></label>';
  echo '<button class="btn full">Verify &amp; Continue</button></form>';
}

elseif ($step === 4) {
  echo '<form method="post" class="grid2">';
  echo '<div class="full">'; address_map_picker('address'); echo '</div>';
  echo '<label>Father\'s Name<input name="father_name" required></label>';
  echo '<label>Mother\'s Name<input name="mother_name" required></label>';
  echo '<label>Gender<select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></label>';
  echo '<label>Employment Type<select name="employment_type"><option>Salaried</option><option>Self-employed</option><option>Business</option><option>Professional</option></select></label>';
  echo '<div><label>Industry Type</label>'; industry_input('industry'); echo '</div>';
  echo '<div><label>Company Name</label>'; company_input('company_name'); echo '</div>';
  echo '<label class="full">Monthly Income (&#8377;)<input type="number" name="monthly_income" min="0" required></label>';
  echo '<button class="btn full">Continue</button></form>';
}

elseif ($step === 5) {
  $c = los('credit-check', ['reference_no'=>$ref, 'pan'=>$_SESSION['pan']??'']);
  $_SESSION['credit'] = $c;
  if (!empty($c['rejected'])) reject_and_show($c['reason'] ?? 'Credit assessment did not pass');
  if ($c && !empty($c['found'])) {
    echo '<div class="checking"><div class="dots"><span></span><span></span><span></span></div>';
    echo '<div class="checking-txt">Checking Eligibility</div><p class="muted">Please wait while we assess your profile…</p></div>';
    echo '<script>setTimeout(function(){location.href="/apply.php?step=6";},3000);</script>';
  } else { echo '<p class="err">No credit history found for this PAN.</p>'; }
}

elseif ($step === 6) {
  $c = $_SESSION['credit'] ?? [];
  $prequal = max(50000, (int)($c['initial_offer'] ?? 0));
  $applied = (int)($cur['requested_amount'] ?? 0); if ($applied <= 0) $applied = min(200000, $prequal);
  $tenure  = (int)($cur['tenure_months'] ?: 24);
  $rRoi = roi_for($prequal); $rEmi = emi_for($prequal, $rRoi, $tenure);
  $aAmt = min($applied, $prequal); $aRoi = roi_for($aAmt); $aEmi = emi_for($aAmt, $aRoi, $tenure);
  $ceil = 1000000; $hmin = min($ceil, $prequal + 10000);
  echo '<div class="offer offer-hero">&#127881; Congratulations!</div>';
  echo '<div class="eligible">You are now eligible for a loan up to <b>&#8377;'.number_format($prequal).'</b></div>';
  echo '<table class="offtab"><thead><tr><th></th><th>Loan Amount</th><th>EMI</th><th>Tenure</th><th>Interest</th></tr></thead><tbody id="offBody">';
  echo '<tr class="row-rec"><td>Recommended</td><td>&#8377;'.number_format($prequal).'</td><td>&#8377;'.number_format($rEmi).'</td><td>'.$tenure.' mo</td><td>'.number_format($rRoi,1).'%</td></tr>';
  echo '<tr class="row-app"><td>Applied</td><td>&#8377;'.number_format($aAmt).'</td><td>&#8377;'.number_format($aEmi).'</td><td>'.$tenure.' mo</td><td>'.number_format($aRoi,1).'%</td></tr>';
  echo '</tbody></table>';
  // default (no higher): proceed with applied/recommended amount
  echo '<form method="post" id="offForm">';
  echo '<label class="wm-toggle" style="margin-top:16px"><input type="checkbox" id="wantHigher" name="want_higher" value="1"> Do you need a higher loan amount?</label>';
  echo '<div id="higherBox" class="higher-box">';
  echo '<div class="lf-row"><label>Higher amount</label><span class="lf-val" id="amtOut"></span></div>';
  echo '<input type="range" class="slider" id="amt" min="'.$hmin.'" max="'.$ceil.'" step="10000" value="'.$hmin.'">';
  echo '<div class="lf-minmax"><span>&#8377;'.number_format($hmin).'</span><span>&#8377;'.number_format($ceil).'</span></div>';
  echo '<div class="lf-row" style="margin-top:14px"><label>Tenure</label><span class="lf-val" id="tenOut"></span></div>';
  echo '<input type="range" class="slider" id="ten" min="12" max="60" step="6" value="'.$tenure.'">';
  echo '<div class="lf-minmax"><span>12 months</span><span>60 months</span></div>';
  echo '<div class="loan-summary"><div class="ls-item"><span>Interest Rate</span><b id="roiOut"></b></div><div class="ls-item"><span>Monthly EMI</span><b id="emiOut"></b></div></div>';
  echo '<p class="wm-note on">Amounts above your pre-qualified limit require a quick bank-statement verification.</p>';
  echo '</div>';
  echo '<input type="hidden" name="requested_amount" id="f_amt" value="'.$aAmt.'">';
  echo '<input type="hidden" name="tenure_months" id="f_ten" value="'.$tenure.'">';
  echo '<input type="hidden" name="roi" id="f_roi" value="'.$aRoi.'">';
  echo '<input type="hidden" name="emi" id="f_emi" value="'.$aEmi.'">';
  echo '<button class="btn" style="margin-top:16px">Continue</button></form>';
  echo '<script>(function(){var cb=document.getElementById("wantHigher"),box=document.getElementById("higherBox"),'
      .'tab=document.getElementById("offBody"),amt=document.getElementById("amt"),ten=document.getElementById("ten");'
      .'var fa=document.getElementById("f_amt"),ft=document.getElementById("f_ten"),fr=document.getElementById("f_roi"),fe=document.getElementById("f_emi");'
      .'var defAmt='.$aAmt.',defTen='.$tenure.',defRoi='.$aRoi.',defEmi='.$aEmi.';'
      .'function roiFor(a){a=+a;if(a<=100000)return 15.0;if(a<=300000)return 13.5;if(a<=500000)return 12.0;return 11.0;}'
      .'function emiFor(p,ann,n){p=+p;n=+n;if(n<=0)return 0;var r=ann/1200;if(r<=0)return Math.round(p/n);var f=Math.pow(1+r,n);return Math.round(p*r*f/(f-1));}'
      .'function inr(x){return "₹"+Math.round(x).toLocaleString("en-IN");}'
      .'function updHigher(){var a=+amt.value,n=+ten.value,roi=roiFor(a),emi=emiFor(a,roi,n);'
      .'document.getElementById("amtOut").textContent=inr(a);document.getElementById("tenOut").textContent=n+" months";'
      .'document.getElementById("roiOut").textContent=roi.toFixed(1)+"% p.a.";document.getElementById("emiOut").textContent=inr(emi)+" / mo";'
      .'fa.value=a;ft.value=n;fr.value=roi;fe.value=emi;}'
      .'function sync(){if(cb.checked){box.classList.add("on");tab.classList.add("dim");updHigher();}'
      .'else{box.classList.remove("on");tab.classList.remove("dim");fa.value=defAmt;ft.value=defTen;fr.value=defRoi;fe.value=defEmi;}}'
      .'cb.addEventListener("change",sync);amt.addEventListener("input",updHigher);ten.addEventListener("input",updHigher);sync();'
      .'})();</script>';
  celebration_js();
}

elseif ($step === 7) {   // bank details (more path)
  $s = $_GET['s'] ?? 'company';
  if ($s === 'company') {
      card_lead('Is this your company name as per your payslip?');
      $co = h($_SESSION['company'] ?? '');
      echo '<form method="post"><label>Company / Employer Name<input name="company_name" value="'.$co.'" required></label>';
      echo '<p class="field-hint">If it differs from your payslip, edit it here.</p>';
      echo '<button class="btn">Yes, Continue</button></form>';
  } elseif ($s === 'bank') {
      card_lead('Choose the bank account we should verify.');
      bank_search_ui(los('banks',[])['banks'] ?? []);
  } elseif ($s === 'acct') {
      echo '<div class="chosen-bank">Selected bank: <b>'.h($_SESSION['sel_bank_name']??'').'</b> <a href="/apply.php?step=7&s=bank" class="chg">Change</a></div>';
      card_lead('Enter your account number for this bank.');
      echo '<form method="post"><label>Account Number<input name="account_no" inputmode="numeric" required></label><button class="btn">Continue</button></form>';
  } elseif ($s === 'otp') {
      if (!empty($_SESSION['s7otp'])) {
          card_lead('Enter the OTP sent by your bank to approve the statement-sharing consent.');
          echo '<form method="post"><label>Consent OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Approve &amp; Fetch</button></form>';
      } else {
          echo '<div class="chosen-bank">Verifying with <b>'.h($_SESSION['sel_bank_name']??'').'</b> · A/C ending '.h(substr($_SESSION['acct']??'',-4)).'</div>';
          card_lead('We will fetch your bank statement securely via the Account Aggregator.');
          echo '<form method="post"><button class="btn" name="send" value="1">Send Consent OTP</button></form>';
      }
  }
}

elseif ($step === 8) {
  $o = los('final-offer', ['reference_no'=>$ref]);
  echo '<div class="offer">Final approved amount <b>&#8377;'.number_format((float)($o['final_offer']??0)).'</b></div>';
  echo '<div class="loan-summary"><div class="ls-item"><span>Interest Rate</span><b>'.number_format((float)($o['roi']??0),1).'% p.a.</b></div>';
  echo '<div class="ls-item"><span>Tenure</span><b>'.(int)($o['tenure_months']??0).' months</b></div>';
  echo '<div class="ls-item"><span>Monthly EMI</span><b>&#8377;'.number_format((float)($o['emi']??0)).'</b></div></div>';
  echo '<form method="post"><button class="btn">Accept Offer</button></form>';
}

elseif ($step === 9) {
  $sub = $_SESSION['s9'] ?? '';
  if ($sub === 'otp') {
    card_lead('Enter the OTP sent to your Aadhaar-linked mobile number.');
    echo '<form method="post"><label>Aadhaar OTP<input name="otp" pattern="[0-9]{6}" required></label><button class="btn">Verify KYC</button></form>';
  } else {
    card_lead('Complete your KYC via Aadhaar e-KYC (DigiLocker).');
    echo '<form method="post"><label>Aadhaar Number<input name="aadhaar" pattern="[0-9]{12}" placeholder="12-digit Aadhaar" required></label><button class="btn" name="send" value="1">Send OTP</button></form>';
  }
}

elseif ($step === 10) {
  card_lead('Upload a clear, front-facing selfie for identity verification.');
  echo '<form method="post" enctype="multipart/form-data"><label>Upload Selfie<input type="file" name="selfie" accept="image/*" required></label><button class="btn">Continue</button></form>';
}

elseif ($step === 11) {
  $mb = los('my-bank', ['reference_no'=>$ref]);
  $real = $_SESSION['acct'] ?? ($mb['account_no'] ?? '');
  $mask = strlen($real) > 4 ? str_repeat('X', strlen($real)-4).substr($real,-4) : $real;
  $bankName = $_SESSION['sel_bank_name'] ?? ($mb['bank_name'] ?? '');
  echo '<div class="chosen-bank">Disbursal to <b>'.h($bankName).'</b></div>';
  card_lead('Verify your bank account to finish. Re-enter your full account number to confirm.');
  echo '<form method="post" class="grid2">';
  echo '<label class="full">Account Number<input value="'.h($mask).'" disabled></label>';
  echo '<label class="full">Full Account Number<input name="full_account" inputmode="numeric" placeholder="Re-enter full account number" required></label>';
  echo '<label class="check full"><input type="checkbox" required> I authorise the e-Mandate and e-Sign the loan agreement.</label>';
  echo '<button class="btn full">Verify &amp; Submit</button></form>';
}

afoot();
