<?php
require __DIR__ . '/layout.php';
$ref = trim($_GET['ref'] ?? ($_POST['ref'] ?? ''));
$res = null;
if ($ref) $res = los('get-status', ['reference_no' => $ref]);
phead('Track Application');
?>
<h2 class="pane-h">Track your application</h2>
<form method="get" action="/status.php">
  <label>Application reference number<input name="ref" value="<?= h($ref) ?>" placeholder="FC26XXXXXX" required></label>
  <button class="btn">Check Status</button>
</form>
<?php if ($ref && $res && !empty($res['found'])):
  $st = $res['status'];
  $map = ['PENDING'=>['Under review','#b45309','#fef3c7'],'APPROVED'=>['Approved','#1e40af','#dbeafe'],
          'DISBURSED'=>['Disbursed','#15803d','#dcfce7'],'REJECTED'=>['Not approved','#b91c1c','#fee2e2'],
          'DRAFT'=>['Incomplete','#64748b','#eef1f6']];
  $m = $map[$st] ?? $map['DRAFT'];
?>
  <div style="margin-top:22px;border:1px solid var(--line);border-radius:12px;padding:20px">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <div><div class="muted" style="font-size:13px">Reference</div><b><?= h($res['reference_no']) ?></b></div>
      <span style="background:<?= $m[2] ?>;color:<?= $m[1] ?>;padding:6px 14px;border-radius:20px;font-weight:600;font-size:13px"><?= h($m[0]) ?></span>
    </div>
    <div class="kv" style="display:flex;justify-content:space-between;margin-top:14px"><span class="muted">Applicant</span><b><?= h($res['full_name']) ?></b></div>
    <?php if ($st === 'APPROVED' || $st === 'DISBURSED'): ?>
      <div class="kv" style="display:flex;justify-content:space-between"><span class="muted">Approved amount</span><b>&#8377;<?= number_format((float)$res['final_offer']) ?></b></div>
    <?php endif; ?>
    <?php if ($st === 'REJECTED' && !empty($res['reason'])): ?>
      <div class="kv" style="margin-top:6px"><span class="muted">Reason:</span> <?= h($res['reason']) ?></div>
    <?php endif; ?>
  </div>
<?php elseif ($ref): ?>
  <p class="muted" style="margin-top:16px">No application found for that reference number.</p>
<?php endif;
pfoot();
