<?php
// NSDL node DB (SQLite) — PAN registry. LAB / isolated range only.
// PAN is the shared identifier across the lab: the SAME PANs here will have
// credit profiles on the Bank Server node (keyed by PAN).

function ndb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/nsdl.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS pan_records(
            pan TEXT PRIMARY KEY,
            full_name TEXT,
            dob TEXT,
            status TEXT DEFAULT 'VALID'   -- VALID / INACTIVE
        )");
        seed($pdo);
    }
    return $pdo;
}

function seed($pdo) {
    $n = (int)$pdo->query("SELECT COUNT(*) c FROM pan_records")->fetch()['c'];
    if ($n > 0) return;
    // Demo PAN holders. These SAME PANs get credit profiles on Bank Server.
    $rows = [
        ['ABCDE1234F', 'Rajesh Kumar',  '1988-05-12', 'VALID'],
        ['PQRSX5678L', 'Priya Sharma',  '1992-09-03', 'VALID'],
        ['LMNOP9012Q', 'Amit Verma',    '1985-01-25', 'VALID'],
        ['FGHIJ3456M', 'Sneha Patel',   '1990-11-18', 'VALID'],
        ['TUVWX7890R', 'Vikram Singh',  '1983-07-30', 'VALID'],
        ['ZZZZZ0000Z', 'Inactive Test', '1979-02-02', 'INACTIVE'],
    ];
    $st = $pdo->prepare("INSERT INTO pan_records(pan, full_name, dob, status) VALUES(?,?,?,?)");
    foreach ($rows as $r) { $st->execute($r); }
}
