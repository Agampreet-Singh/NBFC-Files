<?php
require __DIR__ . '/lib.php';
require_login();
shell_head('services', 'Connected Services');
?>
<div class="panel">
  <div class="panel-h"><h2>Connected services</h2><a class="link" href="/services.php">Refresh</a></div>
  <p class="muted">LOS orchestrates every verification through these nodes.</p>
  <table class="tbl">
    <tr><th>Service</th><th>Status</th></tr>
    <?php foreach (svc_list() as $s): $up = svc_up($s['url']); ?>
    <tr>
      <td><?= h($s['name']) ?></td>
      <td><?= $up ? '<span class="ok">&#9679; Reachable</span>' : '<span class="no">&#9679; Unreachable</span>' ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php shell_foot();
