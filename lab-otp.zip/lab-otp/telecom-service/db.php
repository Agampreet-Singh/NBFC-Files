<?php
// Telecom Service DB (SQLite) — OTP + simulated SMS inbox. LAB / isolated range only.
function tdb() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/telecom.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec("CREATE TABLE IF NOT EXISTS otps(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mobile TEXT, otp TEXT, created_at TEXT, expires_at TEXT, used INTEGER DEFAULT 0)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mobile TEXT, sender TEXT, body TEXT, created_at TEXT)");
    }
    return $pdo;
}
