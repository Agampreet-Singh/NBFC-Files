<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$rows = $pdo->query("SELECT borrower, COUNT(*) loans, SUM(principal) principal, SUM(outstanding) outstanding,
    MAX(dpd) maxdpd, branch FROM loans GROUP BY borrower ORDER BY outstanding DESC LIMIT 200")->fetchAll();
shell_head('borrowers', 'Borrowers');
?>
<div class="panel"><div class="panel-h"><h2>Borrowers</h2><span class="muted"><?= count($rows) ?> shown</span></div>
<table class="tbl">
  <tr><th>Borrower</th><th>Branch</th><th>Loans</th><th>Principal</th><th>Outstanding</th><th>Max DPD</th></tr>
  <?php foreach ($rows as $b): ?>
  <tr><td><?= h($b['borrower']) ?></td><td><?= h($b['branch']) ?></td><td><?= (int)$b['loans'] ?></td>
  <td><?= inr($b['principal']) ?></td><td><?= inr($b['outstanding']) ?></td>
  <td><?= (int)$b['maxdpd'] ?><?= $b['maxdpd']>90?' <span class="no">NPA</span>':'' ?></td></tr>
  <?php endforeach; ?>
</table></div>
<?php shell_foot();
