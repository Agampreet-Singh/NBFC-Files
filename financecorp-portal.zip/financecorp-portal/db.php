<?php
// db.php — SQLite connection + schema for FinanceCorp loan portal
// LAB / ISOLATED RANGE ONLY. Not for production use.

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $dir = __DIR__ . '/data';
        if (!is_dir($dir)) { mkdir($dir, 0775, true); }
        $pdo = new PDO('sqlite:' . $dir . '/financecorp.db');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        init_schema($pdo);
    }
    return $pdo;
}

function init_schema($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reference_no TEXT UNIQUE,
        full_name TEXT,
        dob TEXT,
        mobile TEXT,
        email TEXT,
        employment_type TEXT,
        monthly_income REAL,
        loan_amount REAL,
        pan TEXT,
        aadhaar_last4 TEXT,
        bank_name TEXT,
        beneficiary_account TEXT,
        beneficiary_ifsc TEXT,
        kyc_doc TEXT,
        income_doc TEXT,
        tenure_months INTEGER,
        emi REAL,
        status TEXT DEFAULT 'PENDING',          -- PENDING -> APPROVED -> DISBURSED
        created_at TEXT DEFAULT (datetime('now'))
    )");
}
