<?php
session_start();
require __DIR__ . '/db.php';
require __DIR__ . '/config.php';
require __DIR__ . '/layout.php';

$m = $_SESSION['pan_verified_mobile'] ?? '';
if (!$m) { header('Location: /index.php'); exit; }

$pdo = ndb();
$st = $pdo->prepare("SELECT * FROM pan_records WHERE mobile = ?");
$st->execute([$m]);
$rec = $st->fetch();
if (!$rec) { header('Location: /index.php'); exit; }

$dob = $rec['dob'] ? date('d/m/Y', strtotime($rec['dob'])) : '';

nhead('Your e-PAN');
?>
<div class="gov-card">
  <h3>Your e-PAN</h3>
  <p class="gov-note">Verified for mobile <b><?= nh($m) ?></b>. Status:
    <b><?= nh($rec['status']) ?></b>. You can download or print your e-PAN below.</p>

  <!-- e-PAN card (fictional authority; SPECIMEN watermark — training artifact) -->
  <div class="pan-card" id="panCard">
    <div class="pan-wm">SPECIMEN</div>
    <div class="pan-head">
      <div class="pan-dept">
        <div class="pan-dept-in">REVENUE SERVICES DEPARTMENT</div>
        <div class="pan-dept-sub">e-PAN &middot; Permanent Account Number</div>
      </div>
      <div class="pan-seal">&#9733;</div>
    </div>
    <div class="pan-body">
      <div class="pan-fields">
        <div class="pan-f"><span>Name</span><b><?= nh(strtoupper($rec['full_name'])) ?></b></div>
        <div class="pan-f"><span>Father's Name</span><b><?= nh(strtoupper($rec['father_name'])) ?></b></div>
        <div class="pan-f"><span>Date of Birth</span><b><?= nh($dob) ?></b></div>
        <div class="pan-f"><span>Permanent Account Number</span><b class="pan-no"><?= nh($rec['pan']) ?></b></div>
        <div class="pan-sign"><span>Signature</span><i><?= nh($rec['full_name']) ?></i></div>
      </div>
      <div class="pan-photo">PHOTO</div>
    </div>
  </div>

  <div style="margin-top:18px">
    <button class="gov-btn" onclick="window.print()">Download / Print e-PAN</button>
    <a class="gov-link" href="/index.php">Done</a>
  </div>
</div>
<?php nfoot();
