<?php
require __DIR__ . '/layout.php';
render_head('Instant Personal Loans');
?>
<section class="hero">
  <div class="hero-text">
    <h1>Instant Personal Loans up to &#8377;5,00,000</h1>
    <p>Paperless application. Approval in minutes. Money straight to your bank account.</p>
    <a class="btn" href="/apply.php?step=1">Apply Now</a>
    <ul class="ticks">
      <li>100% online process</li>
      <li>Minimal documents — KYC &amp; income proof</li>
      <li>Flexible tenure up to 36 months</li>
    </ul>
  </div>
  <div class="hero-card">
    <h3>Why FinanceCorp?</h3>
    <div class="stat"><b>10 min</b><span>Average approval time</span></div>
    <div class="stat"><b>&#8377;5L</b><span>Maximum loan amount</span></div>
    <div class="stat"><b>19%</b><span>Interest from (p.a.)</span></div>
  </div>
</section>

<section class="steps-info">
  <h2>How it works</h2>
  <div class="cards">
    <div class="card"><span class="num">1</span><h4>Personal Details</h4><p>Tell us about yourself, your employment and the amount you need.</p></div>
    <div class="card"><span class="num">2</span><h4>Banking &amp; KYC</h4><p>Complete KYC, add your bank account and upload your documents.</p></div>
    <div class="card"><span class="num">3</span><h4>Repayment &amp; e-Sign</h4><p>Review your EMI plan and e-sign the loan agreement.</p></div>
  </div>
</section>
<?php render_foot();
