<?php
require __DIR__ . '/db.php';
require __DIR__ . '/layout.php';
$ref = $_GET['ref'] ?? '';
$row = null;
if ($ref) {
    $stmt = db()->prepare("SELECT * FROM applications WHERE reference_no = ?");
    $stmt->execute([$ref]);
    $row = $stmt->fetch();
}
render_head('Application Submitted');
if ($row): ?>
  <div class="panel center">
    <div class="tick-big">&#10003;</div>
    <h2>Application submitted</h2>
    <p>Your loan application has been received and is now <b><?= h($row['status']) ?></b> review.</p>
    <p class="refbox">Reference number: <b><?= h($row['reference_no']) ?></b></p>
    <p class="muted">Loan amount &#8377;<?= number_format((float)$row['loan_amount']) ?> &middot; Indicative EMI &#8377;<?= number_format((float)$row['emi']) ?>/month for <?= (int)$row['tenure_months'] ?> months.</p>
    <a class="btn" href="/status.php?ref=<?= urlencode($row['reference_no']) ?>">Track this application</a>
  </div>
<?php else: ?>
  <div class="panel center"><h2>Application not found</h2><a class="btn" href="/apply.php?step=1">Start a new application</a></div>
<?php endif;
render_foot();
