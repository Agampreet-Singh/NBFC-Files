<?php
require __DIR__ . '/lib.php';
require_login();
$pdo = ldb();
$apps = $pdo->query("SELECT reference_no, full_name, status, updated_at FROM applications ORDER BY updated_at DESC LIMIT 30")->fetchAll();
shell_head('audit', 'Audit Trail');
?>
<div class="panel"><div class="panel-h"><h2>Audit Trail</h2><span class="muted">Recent application events</span></div>
<table class="tbl">
  <tr><th>Time</th><th>Reference</th><th>Applicant</th><th>Event</th></tr>
  <?php foreach ($apps as $a): ?>
  <tr><td><?= h($a['updated_at']) ?></td><td><?= h($a['reference_no']) ?></td><td><?= h($a['full_name']) ?></td>
  <td>Status &rarr; <?= badge($a['status']) ?></td></tr>
  <?php endforeach; ?>
  <?php if(!$apps): ?><tr><td colspan="4" class="muted">No events.</td></tr><?php endif; ?>
</table></div>
<?php shell_foot();
